The hopkins155 dataset can be downloaded from http://vision.jhu.edu/data/fetchdata.php?id=1

The codes implement the SMR algorithm presented in the following paper:

@inproceedings{CVPR14/HuLFZ,
  author    = {Han Hu and Zhouchen Lin
               Jianjiang Feng and
               Jie Zhou},
  title     = {Smooth Representation Clustering},
  booktitle = {CVPR},
  year      = {2014}
}