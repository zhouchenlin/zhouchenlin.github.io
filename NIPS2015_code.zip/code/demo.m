% Before you run this example, make sure that you have run install.m to add the path and mex C files
% Parts of the code are from http://www.public.asu.edu/yje02/Software/GIST
% in paper "A general iterative shrinkage and thresholding algorithm
%for nonconvex regularized optimization problems".
clear;
clc;
close all;

load ('.\data\real-sim.mat');

n = size(Data,1);
d = randperm(n);
Data = Data(d,:);
label = label(d,:);

dd = round(n*0.9);
y = label(1:dd);
y_test = label(dd+1:end);
X = Data(1:dd,:);
X_test = Data(dd+1:end,:);

clear Data

[n,d] = size(X);

w1 = APG_logist(X,y);
%ac1 = f_test(X_test,y_test,w1)
w2 = nonAPG_logist(X,y);
%ac2 = f_test(X_test,y_test,w2)