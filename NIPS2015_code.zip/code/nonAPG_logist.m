function [w] = nonAPG_logist(X,y)
tic

[n,d] = size(X); 
w = zeros(d,1);
maxiter = 200;
sigma = 1e-5;
lambda = 1e-3;
theta = 1e-1*lambda;
regtype = 1;

t = 1;
tmin = 1e-20;
tmax = 1e20;

eta = 2;
maxinneriter = 20;

fun = zeros(maxiter+1,1); 
fun1 = zeros(maxiter+1,1);
fun2 = zeros(maxiter+1,1);
time = fun;
% Initial function value
Z = sparse(1:n,1:n,y,n,n)*X;
[fun(1),grad] = funandgrad(Z, w, n, d, lambda, theta, regtype);
time(1) = 0;

change=zeros(maxiter,1);
change1=zeros(maxiter,1);

innercountPG = 0;
innercountAPG = 0;

wy = w;
grady = grad;
wypre = w;
gradypre = grad;
funy = fun(1);
apgtheta = 1;
ty=1;

Q = 1;
C = fun(1);

for iter = 1:200%maxiter
    tic;
    
    % APG step
    if iter>1
        % BB rule for APG
        st = wy - wypre;
        rt = grady - gradypre;
        if norm(st)/d < 1e-12 || norm(rt)/d < 1e-12
           disp('norm stop');
           %break;
        end
        ty = st'*rt/(st'*st);
    end
    ty = min(max(ty,tmin),tmax);        
    for inneriter = 1:maxinneriter
        wz = proximalRegC(wy - grady/ty, d, lambda/ty, theta,regtype);
        dw = wz - wy; 
        logistz = zeros(n,1);
        Zwz = -Z*wz; posindz = (Zwz > 0);
        logistz(posindz) = 1 + exp(-Zwz(posindz));
        logistz(~posindz) = 1 + exp(Zwz(~posindz));
        
        funz1 = (sum(log(logistz(~posindz))) + sum(Zwz(posindz) + log(logistz(posindz))))/n;
        funz2 = funRegC(wz,d,lambda,theta,regtype);
        funz = funz1+funz2;
        
        if funz <= funy - 0.5*sigma*t*norm(dw)^2 || funz <= C - 0.5*sigma*t*norm(dw)^2
            break;
        else
            ty = ty*2;
        end
    end
    innercountAPG = innercountAPG+inneriter;
    
    wpre = w;
    
    if funz <= C - 0.5*sigma*t*norm(dw)^2
        w = wz;
        fun(iter+1) = funz;
        fun1(iter+1) = funz1;
        fun2(iter+1) = funz2;
        change(iter) = 1;
        change1(iter) = 1;
    else
        % PG step
        logist = zeros(n,1);
        Zw = -Z*w; posind = (Zw > 0);
        logist(posind) = 1 + exp(-Zw(posind));
        logist(~posind) = 1 + exp(Zw(~posind));
        
        temp = logist;
        temp(posind) = 1./logist(posind);
        temp(~posind) = (logist(~posind)-1)./logist(~posind);
        grad =  -Z'*temp/n;
        
        if iter>1
            % BB rule for PG
            st = w - wypre;
            rt = grad - gradypre;
            if norm(st)/d < 1e-12 || norm(rt)/d < 1e-12
                disp('norm stop');
                %break;
            end
            t = st'*rt/(st'*st);
        end
        t = min(max(t,tmin),tmax);
        % line search 
        for inneriter = 1:maxinneriter
            wv = proximalRegC(w - grad/t, d, lambda/t, theta,regtype);
            dw = wv - w; 
            logistv = zeros(n,1);
            Zwv = -Z*wv; posindv = (Zwv > 0);
            logistv(posindv) = 1 + exp(-Zwv(posindv));
            logistv(~posindv) = 1 + exp(Zwv(~posindv));
            
            funv1 = (sum(log(logistv(~posindv))) + sum(Zwv(posindv) + log(logistv(posindv))))/n;
            funv2 = funRegC(wv,d,lambda,theta,regtype);
            funv = funv1+funv2;
            
            if funv <= C - 0.5*sigma*t*norm(dw)^2    
                break;
            else
                t = t*eta;
            end
        end
        innercountPG = innercountPG+inneriter;
       
        % select APG or PG
        if funz <= funv 
            w = wz;
            fun(iter+1) = funz;
            fun1(iter+1) = funz1;
            fun2(iter+1) = funz2;
            change(iter) = 1;
        else
            w = wv;
            fun(iter+1) = funv;
            fun1(iter+1) = funv1;
            fun2(iter+1) = funv2;
        end
    end
     
    % update APG parameter
    apgtheta_pre=apgtheta;
    apgtheta=(sqrt(4*apgtheta^2+1)+1)/2;
    
    wypre = wy;
    gradypre = grady;
    wy=w+apgtheta_pre/apgtheta*(wz-w)+(apgtheta_pre-1)/apgtheta*(w-wpre);
    [funy,grady] = funandgrad(Z, wy, n, d, lambda, theta, regtype);
    
    Q_pre = Q;
    Q = 0.8*Q_pre+1;
    C = ( 0.8*Q_pre*C+fun(iter+1) )/Q;
    
    time(iter+1) = time(iter) + toc; 
    
end
fun = fun(1: min(maxiter,iter)+1);
time = time(1: min(maxiter,iter)+1);

%[norm(w-wpre)/norm(w),abs(fun(iter) - fun(iter+1))/fun(iter+1),innercountPG/(iter+1),innercountAPG/(iter+1)]
%[iter,fun(iter+1),fun1(iter+1),fun2(iter+1),time(iter+1)]
change = change(1:iter);
change1 = change1(1:iter);
%[change';change1']
figure(1);
hold on;
plot(1:iter+1,log10(fun(1:iter+1)),'k');
figure(2);
hold on;
plot(time(1:iter),log10(fun(1:iter)),'k');


function [f,g] = funandgrad(Z, w, n, d, lambda, theta, regtype)
logist = zeros(n,1);
Zw = -Z*w; posind = (Zw > 0);
logist(posind) = 1 + exp(-Zw(posind));
logist(~posind) = 1 + exp(Zw(~posind));

temp = logist;
temp(posind) = 1./logist(posind);
temp(~posind) = (logist(~posind)-1)./logist(~posind);
g =  -Z'*temp/n;

f = (sum(log(logist(~posind))) + sum(Zw(posind) + log(logist(posind))))/n + funRegC(w,d,lambda,theta,regtype);