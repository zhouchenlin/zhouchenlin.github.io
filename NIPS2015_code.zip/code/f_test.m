function [ accu ] = f_test( Data_test,label_test,w)

m=length(label_test);
label=Data_test*w;    
label(label>0)=1;label(label<=0)=-1;
accu=sum(label_test==label)/m;
accu=1-accu;
end

