function [w] = APG_logist(X,y)
tic

[n,d] = size(X); 
w = zeros(d,1);
maxiter = 200;
sigma = 1e-5;
lambda = 1e-3;
theta = 1e-1*lambda;
regtype = 1;

t = 1;
tmin = 1e-20;
tmax = 1e20;

eta = 2;
maxinneriter = 20;

fun = zeros(maxiter+1,1); 
fun1 = zeros(maxiter+1,1);
fun2 = zeros(maxiter+1,1);
time = fun;
% Initial function value
Z = sparse(1:n,1:n,y,n,n)*X;
[fun(1),grad] = funandgrad(Z, w, n, d, lambda, theta, regtype);
time(1) = 0;

change=zeros(maxiter,1);
wy = w;
grady = grad;
funy = fun(1);
apgtheta = 1;
ty=1;

innercountPG = 0;
innercountAPG = 0;
for iter = 1:maxiter
    tic;

    % APG step
    ty = min(max(ty,tmin),tmax);
    for inneriter = 1:maxinneriter
        wz = proximalRegC(wy - grady/ty, d, lambda/ty, theta,regtype);
        dw = wz - wy; 
        logistz = zeros(n,1);
        Zwz = -Z*wz; posindz = (Zwz > 0);
        logistz(posindz) = 1 + exp(-Zwz(posindz));
        logistz(~posindz) = 1 + exp(Zwz(~posindz));
        funz1 = (sum(log(logistz(~posindz))) + sum(Zwz(posindz) + log(logistz(posindz))))/n;
        funz2 = funRegC(wz,d,lambda,theta,regtype);
        funz = funz1+funz2;
        
        if funz <= funy - 0.5*sigma*t*norm(dw)^2
            break;
        else
            ty = ty*2;
        end
    end
    
    innercountAPG = innercountAPG+inneriter;
    
    % PG step
    t = min(max(t,tmin),tmax);
    % line search 
    for inneriter = 1:maxinneriter
        wv = proximalRegC(w - grad/t, d, lambda/t, theta,regtype);
        dw = wv - w;
        logistv = zeros(n,1);
        Zwv = -Z*wv; posindv = (Zwv > 0);
        logistv(posindv) = 1 + exp(-Zwv(posindv));
        logistv(~posindv) = 1 + exp(Zwv(~posindv));
        funv1 = (sum(log(logistv(~posindv))) + sum(Zwv(posindv) + log(logistv(posindv))))/n;
        funv2 = funRegC(wv,d,lambda,theta,regtype);
        funv = funv1+funv2;
        
        if funv <= fun(iter) - 0.5*sigma*t*norm(dw)^2    
            break;
        else
            t = t*eta;
        end
    end
    innercountPG = innercountPG+inneriter;
    
    % select APG or PG
    wpre = w;
    gradpre = grad;
    if funz <= funv
        w = wz;
        fun(iter+1) = funz;
        fun1(iter+1) = funz1;
        fun2(iter+1) = funz2;
        
        tempz = logistz;
        tempz(posindz) = 1./logistz(posindz);
        tempz(~posindz) = (logistz(~posindz)-1)./logistz(~posindz);
        gradz =  -Z'*tempz/n;
        
        tempv = logistv;
        tempv(posindv) = 1./logistv(posindv);
        tempv(~posindv) = (logistv(~posindv)-1)./logistv(~posindv);
        gradv =  -Z'*tempv/n;
        
        grad = gradz;
        change(iter) = 1;
    else
        w = wv;
        fun(iter+1) = funv;
        fun1(iter+1) = funv1;
        fun2(iter+1) = funv2;
        
        tempz = logistz;
        tempz(posindz) = 1./logistz(posindz);
        tempz(~posindz) = (logistz(~posindz)-1)./logistz(~posindz);
        gradz =  -Z'*tempz/n;
        
        tempv = logistv;
        tempv(posindv) = 1./logistv(posindv);
        tempv(~posindv) = (logistv(~posindv)-1)./logistv(~posindv);
        gradv =  -Z'*tempv/n;
        
        grad = gradv;
    end
    
    % update APG parameter
    apgtheta_pre=apgtheta;
    apgtheta=(sqrt(4*apgtheta^2+1)+1)/2;

    % BB rule for APG
    st = wz - wy;
    rt = gradz - grady;
    if norm(st)/d < 1e-12 || norm(rt)/d < 1e-12
        disp('norm stop');
        break;
    end
    ty = st'*rt/(st'*st);
    
    % BB rule for PG
    st = wv - wpre;
    rt = gradv - gradpre;
    if norm(st)/d < 1e-12 || norm(rt)/d < 1e-12
        disp('norm stop');
        break;
    end
    t = st'*rt/(st'*st);
    
    wy=w+apgtheta_pre/apgtheta*(wz-w)+(apgtheta_pre-1)/apgtheta*(w-wpre);
    [funy,grady] = funandgrad(Z, wy, n, d, lambda, theta, regtype);
    
    time(iter+1) = time(iter) + toc; 
    
end
fun = fun(1: min(maxiter,iter)+1);
time = time(1: min(maxiter,iter)+1);

%[norm(w-wpre)/norm(w),abs(fun(iter) - fun(iter+1))/fun(iter+1),innercountPG/(iter+1),innercountAPG/(iter+1)]
%[iter,fun(iter+1),fun1(iter+1),fun2(iter+1),time(iter+1)]
change = change(1:iter);
%change'
figure(1);
hold on;
plot(1:iter+1,log10(fun(1:iter+1)),'r');
figure(2);
hold on;
plot(time(1:iter),log10(fun(1:iter)),'r');


function [f,g] = funandgrad(Z, w, n, d, lambda, theta, regtype)
logist = zeros(n,1);
Zw = -Z*w; posind = (Zw > 0);
logist(posind) = 1 + exp(-Zw(posind));
logist(~posind) = 1 + exp(Zw(~posind));

temp = logist;
temp(posind) = 1./logist(posind);
temp(~posind) = (logist(~posind)-1)./logist(~posind);
g =  -Z'*temp/n;

f = (sum(log(logist(~posind))) + sum(Zw(posind) + log(logist(posind))))/n + funRegC(w,d,lambda,theta,regtype);