clear
clc

currentpath = cd;

addpath(genpath([currentpath,'/GIST']));

cd ./CFile

mex proximalRegC.c
mex funRegC.c

cd .
cd .

