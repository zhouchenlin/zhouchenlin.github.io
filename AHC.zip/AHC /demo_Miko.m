   clear;
   
    getQ;    % get provided true transdformations from the dataset
    j=0;dtext=cell(40,7);                                                      
    dirT={'bark','bikes','boat','graf','leuven','trees','ubc','wall'};
 
 %% Match each image in the MIKOLAJCZYK AND SCHMID dataset
 for d=1:8         %1:8                                    
     dirname=char(dirT(d));                                                                                                                % get all the directory file for detecting
     for k=2:6         %2:6                    
        ff=strcat(dirname,'/img',num2str(k),'.ppm');
        %##############################################
        load(strcat('./Asift_keys86/',dirname,'_img',num2str(k),'.mat'));
        n=size(X,1);
        M=[X ones(n,1)]';N=[Y ones(n,1)]';
       %%  
       if ~isempty(M) && ~isempty(N) 
          Q=eval(strcat('Q_',dirname)); 
          Q=Q(:,(3*(k-1)-2):(3*(k-1)));
          QM=Q*M; QM(1:2,:)=QM(1:2,:)./repmat(QM(3,:),2,1);QM(3,:)=1;
          V=N-QM;                                                                       
          Dx=V(1,:).^2+V(2,:).^2;                                             
          TrueInd=sort(find(Dx<=25));
       else
          TrueInd=[];
       end
          FalseInd=setdiff(1:n,TrueInd);                                               
%%  Run AHC
         tic;
         TrueInd_quadet=AHC(M,N,5); 
         TimeCost=toc;
%%  Compute the precision and recall of our method
          P=length(intersect(TrueInd,TrueInd_quadet))./length(TrueInd_quadet);if isnan(P);P=0;end
          R=length(intersect(TrueInd,TrueInd_quadet))./length(TrueInd);if isnan(R);R=0;end
          F=2*(P*R)/(P+R);if P+R==0;F=0;end
          Ratio=length(TrueInd)/n;
        %%  display
          j=j+1;                                                                           
          dtext(j,:)={ff,n,Ratio,P,R,F,TimeCost};
     end
 end
          disp(['  Average n:' num2str(mean(cell2mat(dtext(:,2)))) ' Ratio:' num2str(mean(cell2mat(dtext(:,3)))) ' P:' num2str(mean(cell2mat(dtext(:,4)))) ' R:' num2str(mean(cell2mat(dtext(:,5)))) ' F:' num2str(mean(cell2mat(dtext(:,6)))) ' Time:' num2str(mean(cell2mat(dtext(:,7))))]);

