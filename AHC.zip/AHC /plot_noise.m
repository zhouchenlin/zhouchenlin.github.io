title('Comparison at Different Levels of Noises(85% of data)');
legend('AHC','SIM','SparseVFC','L1GGC','RANSAC','ICF')
ylabel('Average F-score');xlabel('Standard deviation of strong Gaussian noises under affine');

axis([1,5,0.2,1]);
set(gca,'xtick',1:1:5);
set(gca,'xticklabel',{'1','2','3','4','5'});

jj=1;
grid on;
i=1:5;
hold on;
plot(i,AHC_avgF(jj,i),'Marker','o','Color','r');
hold on;
plot(i,sim_avgF(jj,i),'Marker','*','Color','g');
hold on;
plot(i,svfc_avgF(jj,i),'Marker','d','Color','b');
hold on;
plot(i,L1GGC_avgF(jj,i),'Marker','<','Color','k');
hold on;
plot(i,RANSAC_avgF(jj,i),'Marker','>','Color','y');
hold on;
plot(i,icf_avgF(jj,i),'Marker','p','Color','m');

legend('AHC','SIM','SparseVFC','L1GGC','RANSAC','LPM')
hold off;
   