Usage:
AHC.m is the core function that contains the algorithm in the paper.
You can run demo_Miko.m/demo_synthesized_outlier_affine.m/demo_synthesized_outlier_affine.m to get the experiment results on MIKOLAJCZYK AND SCHMID dataset and synthesized dataset respectively.