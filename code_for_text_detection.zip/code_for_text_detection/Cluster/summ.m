function ceng3=summ(p)
%summ matrix
[n,m,q]=size(p);
ceng1=zeros(n,m,q);
ceng2=zeros(n,m,q);
ceng3=zeros(n,m,q);
for i=1:n
    for j=1:m
        for k=1:q
            if (k==1)
                ceng1(i,j,k)=p(i,j,k);
            else
                ceng1(i,j,k)=ceng1(i,j,k-1)+p(i,j,k);                
            end       
        end
    end
end
for i=1:n
    for j=1:m
        for k=1:q
            if (j==1)
                ceng2(i,j,k)=ceng1(i,j,k);
            else
                ceng2(i,j,k)=ceng2(i,j-1,k)+ceng1(i,j,k);                
            end       
        end
    end
end
for i=1:n
    for j=1:m
        for k=1:q
            if (i==1)
                ceng3(i,j,k)=ceng2(i,j,k);
            else
                ceng3(i,j,k)=ceng3(i-1,j,k)+ceng2(i,j,k);                
            end       
        end
    end
end