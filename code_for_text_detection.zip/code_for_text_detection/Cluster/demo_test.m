clear all
close all
clc
%%��ȡ
InImage = dir('D:\fangcong\study\textdetection\�ҵĴ���\ICDAR2011\trainsample\data\train\ICDAR2005\ORI\*.jpg');
for s=185:185
    imgori_path=['D:\fangcong\study\textdetection\�ҵĴ���\ICDAR2011\trainsample\data\train\ICDAR2005\ORI\' InImage(s).name];
    imgORI=imread(imgori_path);
    M_ori=size(imgORI,1);
    N_ori=size(imgORI,2);
    load(['D:\fangcong\study\textdetection\�ҵĴ���\ICDAR2011\����\Cluster\' InImage(s).name(1:length(InImage(s).name)-4) '.mat']);
    RegionCC={};%%%
    RegionTangle={};
    for i=1:length(myregion)
        X(1)=max(1,myregion{i}.data(2));
        X(2)=min(M_ori,myregion{i}.data(2)+myregion{i}.data(4));
        X(3)=max(1,myregion{i}.data(1));
        X(4)=min(N_ori,myregion{i}.data(1)+myregion{i}.data(3));
        I_rgb=imgORI(X(1):X(2),X(3):X(4),:);
        [RegionCCTemp,RegionTangleTemp]=BW_Cluster(I_rgb,X);
        RegionCC=[RegionCC RegionCCTemp];
        RegionTangle=[RegionTangle RegionTangleTemp];
    end
    figure;
    imshow(imgORI);
    hold on
    for i=1:length(RegionCC)
        X1=RegionCC{i}.BoundingBox(2);
        X2=RegionCC{i}.BoundingBox(2)+RegionCC{i}.BoundingBox(4);
        Y1=RegionCC{i}.BoundingBox(1);
        Y2=RegionCC{i}.BoundingBox(1)+RegionCC{i}.BoundingBox(3);
        YY2=[X1 X1 X2 X2 X1];
        XX2=[Y1 Y2 Y2 Y1 Y1];
        plot(XX2, YY2, 'g-');
         hold on, text(Y1, X1, num2str(i), 'EdgeColor','blue');
    end
   figure;imshow(imgORI);hold on
   cont=0;
   Newregion={};
   for k=1:length(RegionTangle)
       X(1)=max(1,RegionTangle{k}.data(2));
       X(2)=min(M_ori,RegionTangle{k}.data(2)+RegionTangle{k}.data(4));
       X(3)=max(1,RegionTangle{k}.data(1));
       X(4)=min(N_ori,RegionTangle{k}.data(1)+RegionTangle{k}.data(3));
       if  (X(1)-X(2))*(X(3)-X(4))>100&&(X(2)-X(1))>5&&(X(4)-X(3))>10&&(X(2)-X(1))/(X(4)-X(3))<1
           cont=cont+1;
           Newregion{cont}.img=imgORI(X(1):X(2),X(3):X(4),:);
           Newregion{cont}.data=[X(3),X(1),X(4)-X(3),X(2)-X(1)];
           Newregion{cont}.component=RegionTangle{k}.component;
           YY2=[X(1) X(1) X(2) X(2) X(1)];
           XX2=[X(3) X(4) X(4) X(3) X(3)];
           plot(XX2, YY2, 'g-');
           hold on, text(XX2(1), YY2(1), num2str(cont), 'EdgeColor','blue');
       end
   end
   close all
end