function [Region,RegionTangle]=BW_Cluster(img,X,MLearners,MWeights,A0)
warning('off');
%img is the small region
%X is the coordinate for img in oriimage
tmp=rgb2gray(img);


global imgtemp;
imgtemp=double(img);

% load('D:\data\text\ICDAR2013\code_FCPARFOR\Cluster\MLearners.mat');
% load('D:\data\text\ICDAR2013\code_FCPARFOR\Cluster\MWeights.mat');

cont=0;
Region={};
RegionTangle={};
tempBW= im2bw(tmp,graythresh(tmp));
box=regionprops(tempBW, 'PixelList','BoundingBox','EquivDiameter','Area');
    myregiontemp={};
	cont1=0;
	for j=1:length(box)
        % if box(j).BoundingBox(3)<N/2&&box(j).BoundingBox(3)<M/2&&box(j).BoundingBox(3)>2&&box(j).BoundingBox(3)>2
        if box(j).Area<40000&&box(j).Area>20&&box(j).BoundingBox(3)/box(j).BoundingBox(4)<4&&box(j).BoundingBox(3)/box(j).BoundingBox(4)>1/8
            cont1=cont1+1;
            Pixel=box(j).PixelList;
            BoundingBox=box(j).BoundingBox;
            myregiontemp{cont1}.Pixel=Pixel;
            myregiontemp{cont1}.BoundingBox=BoundingBox;
            myregiontemp{cont1}.EquivDiameter=box(j).EquivDiameter;
            myregiontemp{cont1}.Area=box(j).Area;
            color=zeros(1,3);
            for idpixel=1:size(box(j).PixelList,1)
                tempcolor=[img(box(j).PixelList(idpixel,2),box(j).PixelList(idpixel,1),1) ...
                    img(box(j).PixelList(idpixel,2),box(j).PixelList(idpixel,1),2) ...
                    img(box(j).PixelList(idpixel,2),box(j).PixelList(idpixel,1),3)];
                color=color...
                    +double(tempcolor)/size(box(j).PixelList,1);
            end
            myregiontemp{cont1}.Color=color;
            
            %compute CC feature and compute the confidence value
            myregiontemp{cont1}=genesinccfeature(myregiontemp{cont1});
                    testData= myregiontemp{cont1}.ccfeature';
        testData(find(isnan(testData)==1)) = 0; 
        P=Classify(MLearners, MWeights, testData');
        P1=exp(P);
       myregiontemp{cont1}.score=P1./(P1+ones(1,length(P1)));
        end
    end

	
    
	A1=cont;
    for j=1:length(myregiontemp)
        if myregiontemp{j}.score>0.1
            cont=cont+1;
            Pixel=myregiontemp{j}.Pixel+repmat([X(3)-1 X(1)-1],size(myregiontemp{j}.Pixel,1),1);
            BoundingBox=myregiontemp{j}.BoundingBox+[X(3)-1 X(1)-1 0 0];
            Region{cont}.Pixel=Pixel;
            Region{cont}.BoundingBox=BoundingBox;
            Region{cont}.EquivDiameter=myregiontemp{j}.EquivDiameter;
            Region{cont}.Area=myregiontemp{j}.Area;
            Region{cont}.score=myregiontemp{j}.score;
            color=zeros(1,3);
            for idpixel=1:size(myregiontemp{j}.Pixel,1)
                tempcolor=[img(myregiontemp{j}.Pixel(idpixel,2),myregiontemp{j}.Pixel(idpixel,1),1) ...
                    img(myregiontemp{j}.Pixel(idpixel,2),myregiontemp{j}.Pixel(idpixel,1),2) ...
                    img(myregiontemp{j}.Pixel(idpixel,2),myregiontemp{j}.Pixel(idpixel,1),3)];
                color=color...
                    +double(tempcolor)/size(myregiontemp{j}.Pixel,1);
            end
            Region{cont}.Color=color;
        end
    end
    para_region=[3 1/4 50 3 0.6 0.6];
    RegionTemp=cluster_region(Region(A1+1:cont),para_region,A1+A0);
	RegionTangle=[RegionTangle RegionTemp];




tempBW=im2bw(1-tempBW);
box=regionprops(tempBW, 'PixelList','BoundingBox','EquivDiameter','Area');
    myregiontemp={};
	cont1=0;
	for j=1:length(box)
        % if box(j).BoundingBox(3)<N/2&&box(j).BoundingBox(3)<M/2&&box(j).BoundingBox(3)>2&&box(j).BoundingBox(3)>2
        if box(j).Area<40000&&box(j).Area>20&&box(j).BoundingBox(3)/box(j).BoundingBox(4)<4&&box(j).BoundingBox(3)/box(j).BoundingBox(4)>1/8
            cont1=cont1+1;
            Pixel=box(j).PixelList;
            BoundingBox=box(j).BoundingBox;
            myregiontemp{cont1}.Pixel=Pixel;
            myregiontemp{cont1}.BoundingBox=BoundingBox;
            myregiontemp{cont1}.EquivDiameter=box(j).EquivDiameter;
            myregiontemp{cont1}.Area=box(j).Area;
            color=zeros(1,3);
            for idpixel=1:size(box(j).PixelList,1)
                tempcolor=[img(box(j).PixelList(idpixel,2),box(j).PixelList(idpixel,1),1) ...
                    img(box(j).PixelList(idpixel,2),box(j).PixelList(idpixel,1),2) ...
                    img(box(j).PixelList(idpixel,2),box(j).PixelList(idpixel,1),3)];
                color=color...
                    +double(tempcolor)/size(box(j).PixelList,1);
            end
            myregiontemp{cont1}.Color=color;
            
            %compute CC feature and compute the confidence value
            myregiontemp{cont1}=genesinccfeature(myregiontemp{cont1});
                    testData= myregiontemp{cont1}.ccfeature';
        testData(find(isnan(testData)==1)) = 0; 
        P=Classify(MLearners, MWeights, testData');
        P1=exp(P);
       myregiontemp{cont1}.score=P1./(P1+ones(1,length(P1)));
        end
    end

	
    
	A1=cont;
    for j=1:length(myregiontemp)
        if myregiontemp{j}.score>0.1
            cont=cont+1;
            Pixel=myregiontemp{j}.Pixel+repmat([X(3)-1 X(1)-1],size(myregiontemp{j}.Pixel,1),1);
            BoundingBox=myregiontemp{j}.BoundingBox+[X(3)-1 X(1)-1 0 0];
            Region{cont}.Pixel=Pixel;
            Region{cont}.BoundingBox=BoundingBox;
            Region{cont}.EquivDiameter=myregiontemp{j}.EquivDiameter;
            Region{cont}.Area=myregiontemp{j}.Area;
            Region{cont}.score=myregiontemp{j}.score;
            color=zeros(1,3);
            for idpixel=1:size(myregiontemp{j}.Pixel,1)
                tempcolor=[img(myregiontemp{j}.Pixel(idpixel,2),myregiontemp{j}.Pixel(idpixel,1),1) ...
                    img(myregiontemp{j}.Pixel(idpixel,2),myregiontemp{j}.Pixel(idpixel,1),2) ...
                    img(myregiontemp{j}.Pixel(idpixel,2),myregiontemp{j}.Pixel(idpixel,1),3)];
                color=color...
                    +double(tempcolor)/size(myregiontemp{j}.Pixel,1);
            end
            Region{cont}.Color=color;
        end
    end
    para_region=[3 1/4 50 3 0.6 0.6];
    RegionTemp=cluster_region(Region(A1+1:cont),para_region,A1+A0);
	RegionTangle=[RegionTangle RegionTemp];