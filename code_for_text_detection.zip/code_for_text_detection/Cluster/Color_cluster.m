function [Region,RegionTangle]=Color_cluster(img,X,MLearners,MWeights,A0)
%img is the small region
%X is the coordinate for img in oriimage

global imgtemp;
imgtemp=double(img);

% load('D:\fangcong\study\textdetection\�ҵĴ���\ICDAR2003\code_single\Cluster\MLearners.mat');
% load('D:\fangcong\study\textdetection\�ҵĴ���\ICDAR2003\code_single\Cluster\MWeights.mat');

cont=0;
Region={};
RegionTangle={};
imggray=rgb2gray(img);
edgeimg= edge(imggray,'canny');
[m,n,~]=size(img);
% figure;
% imshow(img);
conn=0;
his=zeros(64,64,64);
for i=1:m;
    for j=1:n
        if(edgeimg(i,j)==0)
            his(ceil(double(img(i,j,1)+1)/4),ceil(double(img(i,j,2)+1)/4),ceil(double(img(i,j,3)+1)/4))=  his(ceil(double(img(i,j,1)+1)/4),ceil(double(img(i,j,2)+1)/4),ceil(double(img(i,j,3)+1)/4))+1;
            conn=conn+1;
        end
    end
end

%initial
qq=[32/4,96/4,160/4,224/4];
point=zeros(64,3);
for i=1:4
    for j=1:4
        for k=1:4
            point((i-1)*16+(j-1)*4+k,1)=qq(i);
            point((i-1)*16+(j-1)*4+k,2)=qq(j);
            point((i-1)*16+(j-1)*4+k,3)=qq(k);
        end
    end
end

%initial sum
global pos;
pos=summ(his);
w1=zeros(64,64,64);
w2=zeros(64,64,64);
w3=zeros(64,64,64);
for i=1:64
    w1(i,:,:)=his(i,:,:)*i;
end
for i=1:64
    w2(:,i,:)=his(:,i,:)*i;
end
for i=1:64
    w3(:,:,i)=his(:,:,i)*i;
end
global wpo1;
global wpo2;
global wpo3;
wpo1=summ(w1);
wpo2=summ(w2);
wpo3=summ(w3);
zz=64;
h=32/4;
ll=zeros(3,2);
for k=1:500
    pointnext=point;
    uu=[];
    [zz,~]=size(point);
    for j=1:zz
        
        ll(:,1)=point(j,:)'-h;
        ll(:,2)=point(j,:)+h;
        for i=1:3
            if ll(i,1)<=1
                ll(i,1)=0;
            else
                ll(i,1)=ceil(ll(i,1))-1;
            end
            
            if ll(i,2)>256/4
                ll(i,2)=256/4;
            end
            ll(i,2)=floor(ll(i,2));
        end
        po=getu(1,ll(1,2),ll(2,2),ll(3,2))-getu(1,ll(1,1),ll(2,2),ll(3,2))-getu(1,ll(1,2),ll(2,1),ll(3,2))-getu(1,ll(1,2),ll(2,2),ll(3,1))+getu(1,ll(1,1),ll(2,1),ll(3,2))+getu(1,ll(1,1),ll(2,2),ll(3,1))+getu(1,ll(1,2),ll(2,1),ll(3,1))-getu(1,ll(1,1),ll(2,1),ll(3,1));
        if(po>0)
            pointnext(j,1)=(getu(2,ll(1,2),ll(2,2),ll(3,2))-getu(2,ll(1,1),ll(2,2),ll(3,2))-getu(2,ll(1,2),ll(2,1),ll(3,2))-getu(2,ll(1,2),ll(2,2),ll(3,1))+getu(2,ll(1,1),ll(2,1),ll(3,2))+getu(2,ll(1,1),ll(2,2),ll(3,1))+getu(2,ll(1,2),ll(2,1),ll(3,1))-getu(2,ll(1,1),ll(2,1),ll(3,1)))/po;
            pointnext(j,2)=(getu(3,ll(1,2),ll(2,2),ll(3,2))-getu(3,ll(1,1),ll(2,2),ll(3,2))-getu(3,ll(1,2),ll(2,1),ll(3,2))-getu(3,ll(1,2),ll(2,2),ll(3,1))+getu(3,ll(1,1),ll(2,1),ll(3,2))+getu(3,ll(1,1),ll(2,2),ll(3,1))+getu(3,ll(1,2),ll(2,1),ll(3,1))-getu(3,ll(1,1),ll(2,1),ll(3,1)))/po;
            pointnext(j,3)=(getu(4,ll(1,2),ll(2,2),ll(3,2))-getu(4,ll(1,1),ll(2,2),ll(3,2))-getu(4,ll(1,2),ll(2,1),ll(3,2))-getu(4,ll(1,2),ll(2,2),ll(3,1))+getu(4,ll(1,1),ll(2,1),ll(3,2))+getu(4,ll(1,1),ll(2,2),ll(3,1))+getu(4,ll(1,2),ll(2,1),ll(3,1))-getu(4,ll(1,1),ll(2,1),ll(3,1)))/po;
        else
            uu=[uu;j];
        end
    end
    
    if norm(pointnext-point)<1e-3
        %disp('break')
        break;
        
    end
    for i=1:length(uu)
        j=uu(i,1);
        pointnext(j+1-i,:)=[];
    end
    
    point=pointnext;
end
CC=zeros(zz,zz);
for i=1:zz
    for j=i+1:zz
        if max(abs(pointnext(i,:)-pointnext(j,:)))<5
            CC(i,j)=1;
        end
    end
end
CC=CC+CC'+diag(ones(zz,1));
CC=components(sparse(CC));
con=max(CC);
for i=1:con
    loww=[0;0;0];upp=[255;255;255];
    for j=1:zz
        if CC(j,1)==i
            loww(1,1)=max(loww(1,1),round(pointnext(j,1)*4)-4*h-1);
            loww(2,1)=max(loww(2,1),round(pointnext(j,2)*4)-4*h-1);
            loww(3,1)=max(loww(3,1),round(pointnext(j,3)*4)-4*h-1);
            
            upp(1,1)=min(upp(1,1),round(pointnext(j,1)*4)+4*h+1);
            upp(2,1)=min(upp(2,1),round(pointnext(j,2)*4)+4*h+1);
            upp(3,1)=min(upp(3,1),round(pointnext(j,3)*4)+4*h+1);
        end
    end
    temp=zeros(m,n);
    r=[];g=[];b=[];
    for j=1:m
        for k=1:n 
            if img(j,k,1)>=loww(1,1)&&img(j,k,2)>=loww(2,1)&&img(j,k,3)>=loww(3,1)&&img(j,k,1)<=upp(1,1)&&img(j,k,2)<=upp(2,1)&&img(j,k,3)<=upp(3,1)
                if(edgeimg(j,k)==0)
                    temp(j,k)=255;
                    r=[r;img(j,k,1)];
                    g=[g;img(j,k,2)];
                    b=[b;img(j,k,3)];
                end
            end
        end
    end
    rr=mean(r);gg=mean(g);bb=mean(b);
    temp=bfs(temp,rr,gg,bb);
    tempBW= im2bw(temp);
%     figure
%      imshow(tempBW);
    
    box=regionprops(tempBW, 'PixelList','BoundingBox','EquivDiameter','Area');
    myregiontemp={};
	cont1=0;
	for j=1:length(box)
        % if box(j).BoundingBox(3)<N/2&&box(j).BoundingBox(3)<M/2&&box(j).BoundingBox(3)>2&&box(j).BoundingBox(3)>2
        if box(j).Area<40000&&box(j).Area>20&&box(j).BoundingBox(3)/box(j).BoundingBox(4)<4&&box(j).BoundingBox(3)/box(j).BoundingBox(4)>1/8
            cont1=cont1+1;
            Pixel=box(j).PixelList;
            BoundingBox=box(j).BoundingBox;
            myregiontemp{cont1}.Pixel=Pixel;
            myregiontemp{cont1}.BoundingBox=BoundingBox;
            myregiontemp{cont1}.EquivDiameter=box(j).EquivDiameter;
            myregiontemp{cont1}.Area=box(j).Area;
            color=zeros(1,3);
            for idpixel=1:size(box(j).PixelList,1)
                tempcolor=[img(box(j).PixelList(idpixel,2),box(j).PixelList(idpixel,1),1) ...
                    img(box(j).PixelList(idpixel,2),box(j).PixelList(idpixel,1),2) ...
                    img(box(j).PixelList(idpixel,2),box(j).PixelList(idpixel,1),3)];
                color=color...
                    +double(tempcolor)/size(box(j).PixelList,1);
            end
            myregiontemp{cont1}.Color=color;
            
            %compute CC feature and compute the confidence value
            myregiontemp{cont1}=genesinccfeature(myregiontemp{cont1});
                    testData= myregiontemp{cont1}.ccfeature';
        testData(find(isnan(testData)==1)) = 0; 
        P=Classify(MLearners, MWeights, testData');
        P1=exp(P);
       myregiontemp{cont1}.score=P1./(P1+ones(1,length(P1)));
        end
    end

	
    
	A1=cont;
    for j=1:length(myregiontemp)
        if myregiontemp{j}.score>0.1
            cont=cont+1;
            Pixel=myregiontemp{j}.Pixel+repmat([X(3)-1 X(1)-1],size(myregiontemp{j}.Pixel,1),1);
            BoundingBox=myregiontemp{j}.BoundingBox+[X(3)-1 X(1)-1 0 0];
            Region{cont}.Pixel=Pixel;
            Region{cont}.BoundingBox=BoundingBox;
            Region{cont}.EquivDiameter=myregiontemp{j}.EquivDiameter;
            Region{cont}.Area=myregiontemp{j}.Area;
            Region{cont}.score=myregiontemp{j}.score;
            color=zeros(1,3);
            for idpixel=1:size(myregiontemp{j}.Pixel,1)
                tempcolor=[img(myregiontemp{j}.Pixel(idpixel,2),myregiontemp{j}.Pixel(idpixel,1),1) ...
                    img(myregiontemp{j}.Pixel(idpixel,2),myregiontemp{j}.Pixel(idpixel,1),2) ...
                    img(myregiontemp{j}.Pixel(idpixel,2),myregiontemp{j}.Pixel(idpixel,1),3)];
                color=color...
                    +double(tempcolor)/size(myregiontemp{j}.Pixel,1);
            end
            Region{cont}.Color=color;
        end
    end
    para_region=[3 1/4 50 3 0.6 0.6];
    RegionTemp=cluster_region(Region(A1+1:cont),para_region,A1+A0);
	RegionTangle=[RegionTangle RegionTemp];
end