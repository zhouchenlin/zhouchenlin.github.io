function [myregion]=genesinccfeature(myregion)
% myregion.ccfeature  is an vector present the character c(8,2)+8+3
%myrgion is the CC with nn ,img is the original pix;
% m=173;
% n=166;
% file1 = ['D:\fangcong\study\PDE\dataall\data\' 'rotation'];
% te=load(file1)
% pixli=te.pixli;



global imgtemp;

pixx=ceil(myregion.Pixel);
ymax=max(pixx(:,1));
xmax=max(pixx(:,2));
ymin=min(pixx(:,1));
xmin=min(pixx(:,2));
n=ymax-ymin+1;
m=xmax-xmin+1;
cha=zeros(m,n,3);
ord=zeros(size(pixx,1),2);
for i=1:size(pixx,1)
   temp1=pixx(i,1)-ymin+1;
   temp2=pixx(i,2)-xmin+1; 
    ord(i,1)=temp2;ord(i,2)=temp1;
    cha(temp2,temp1,1)=double(imgtemp(pixx(i,2),pixx(i,1),1));
    cha(temp2,temp1,2)=double(imgtemp(pixx(i,2),pixx(i,1),1));
    cha(temp2,temp1,3)=double(imgtemp(pixx(i,2),pixx(i,1),1));
end
% figure;
% imshow(uint8(cha));
pan=zeros(m,n);
zo =size(ord,1);
for i=1:zo
    pan(ord(i,1),ord(i,2))=1;
end
gra = rgb2gray(uint8(cha));
gra=double(gra);
cha=double(cha);
cha=cha+1;
gra=gra+1;
gramax=max(max(gra));
chamax1=max(max(cha(:,:,1)));
chamax2=max(max(cha(:,:,2)));
chamax3=max(max(cha(:,:,3)));
outpoint=zeros(8,8);
temp=zeros(8,1);
[swt,dis]= geneswt(pan);
swt=swt+1;
swtmax=max(max(swt));
mest=0;
aver=zeros(8,1);
for i=1:zo
   aa=ord(i,1);bb=ord(i,2);
   aver(1,1)=aver(1,1)+double((aa))/(m);
  aver(2,1)=aver(2,1)+double((bb))/(n);
   aver(3,1)=aver(3,1)+gra(aa,bb)/gramax;
  aver(4,1)=aver(4,1)+cha(aa,bb,1)/chamax1;
  aver(5,1)=aver(5,1)+cha(aa,bb,2)/chamax2;
    aver(6,1)=aver(6,1)+cha(aa,bb,3)/chamax3;
   aver(7,1)=aver(7,1)+swt(aa,bb)/swtmax;
    if(dis(aa,bb)<3)
     aver(8,1)=aver(8,1)+0;
    else
       aver(8,1)=aver(8,1)+1;
    end
end
for i=1:8
    aver(i,1)=aver(i,1)/zo;
end
for i=1:zo
   aa=ord(i,1);bb=ord(i,2);
   temp(1,1)=double((aa))/(m)-aver(1,1);
   temp(2,1)=double((bb))/(n)-aver(2,1);
   temp(3,1)=gra(aa,bb)/gramax-aver(3,1);
   temp(4,1)=cha(aa,bb,1)/chamax1-aver(4,1);
  temp(5,1)=cha(aa,bb,2)/chamax2-aver(5,1);
    temp(6,1)=cha(aa,bb,3)/chamax3-aver(6,1);
    temp(7,1)=swt(aa,bb)/swtmax-aver(7,1);
    mest=mest+swt(aa,bb);
    if(dis(aa,bb)<3)
     temp(8,1)=0-aver(8,1);
    else temp(8,1)=1-aver(8,1);
    end
    outpoint=outpoint+temp*temp';
end
outpoint=outpoint/(zo-1);
out=zeros(39,1);
tt=1;
for i=1:8
    for j=i:8
out(tt,1)=outpoint(i,j);
tt=tt+1;
    end
end
if m>n
    out(tt,1)=n/m;
else
    out(tt,1)=m/n;
end
tt=tt+1;
out(tt,1)=zo/(m*n);
tt=tt+1;
out(tt)=max(m,n)*zo/mest;
myregion.ccfeature=out;

