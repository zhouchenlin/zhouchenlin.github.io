function q=getu(d,a,b,c)
global pos;
global wpo1;
global wpo2;
global wpo3;
if d==1
    if a<=0||b<=0||c<=0
        q=0;
    else 
        q=pos(a,b,c);
    end
end
if d==2
    if a<=0||b<=0||c<=0
        q=0;
    else 
        q=wpo1(a,b,c);
    end
end
if d==3
    if a<=0||b<=0||c<=0
        q=0;
    else 
        q=wpo2(a,b,c);
    end
end
if d==4
    if a<=0||b<=0||c<=0
        q=0;
    else 
        q=wpo3(a,b,c);
    end
end