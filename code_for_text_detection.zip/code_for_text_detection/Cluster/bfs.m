function [pan]= bfs(temp,rr,gg,bb)
global imgtemp;

[m,n,~]=size(imgtemp);
pan=zeros(m,n);
que=zeros(m*n,2);
star=1;endd=1;
for i=1:m
    for j=1:n
        if (temp(i,j)~=0)
            que(endd,1)=i;
            que(endd,2)=j;
            endd=endd+1;
            pan(i,j)=1;
        end
    end
end
while(star<endd)
    q=que(star,1);
    w=que(star,2);
    if(pan(q,w)>10)
        break;
    end
    star=star+1;
    for con1=-1:1
        for con2=-1:1
            xx=q+con1;yy=w+con2;
            if xx>0&&xx<=m&&yy>0&&yy<=n
                if   pan(xx,yy)==0
                    if abs(imgtemp(xx,yy,1)-imgtemp(q,w,1))<30&&abs(imgtemp(xx,yy,2)-imgtemp(q,w,2))<30&&abs(imgtemp(xx,yy,3)-imgtemp(q,w,3))<30
                        if abs(imgtemp(xx,yy,1)-rr)<50&&abs(imgtemp(xx,yy,2)-gg)<50&&abs(imgtemp(xx,yy,3)-bb)<50
                        que(endd,1)=xx;
                        que(endd,2)=yy;
                        pan(xx,yy)=1+pan(q,w);
                        endd=endd+1;
                        end
                    end
                end
            end
        end
    end
end
pan(find(pan>0))=255;



       