clear all
close all
clc

%  InImage = dir('C:\Users\dwightzy\Desktop\�½��ļ��� (3)\Result\*.mat');
% precision=zeros(length(InImage),1);
% recall=zeros(length(InImage),1);
% 
% 
% for s=1:length(InImage)
%      load(['C:\Users\dwightzy\Desktop\�½��ļ��� (3)\Result\' InImage(s).name(1:length(InImage(s).name)-4) '.mat']);
% %      cont=0;
% %      for i=1:length(SecondRegion)
% %          if SecondRegion{i}.score>0.5
% %              cont=cont+1;
% %              tangle=[SecondRegion{1,i}.data(3) SecondRegion{1,i}.data(1);
% %                  SecondRegion{1,i}.data(3) SecondRegion{1,i}.data(2);
% %                  SecondRegion{1,i}.data(4) SecondRegion{1,i}.data(2);
% %                  SecondRegion{1,i}.data(4) SecondRegion{1,i}.data(1)];
% %              region{cont}.tangle=tangle;
% %          end
% %      end
% region={};
%      for i=1:length(SecondRegion)
%         tangle=[SecondRegion{i}.data(1) SecondRegion{i}.data(2);
%             SecondRegion{i}.data(1) SecondRegion{i}.data(2)+SecondRegion{i}.data(4);
%             SecondRegion{i}.data(1)+SecondRegion{i}.data(3) SecondRegion{i}.data(2)+SecondRegion{i}.data(4);
%             SecondRegion{i}.data(1)+SecondRegion{i}.data(3) SecondRegion{i}.data(2)];
%         region{i}.tangle=tangle;
%     end
%      Im_filename = ['D:\data\text\ICDAR2003\dataRename\Orisize\test\' InImage(s).name(1:length(InImage(s).name)-4) '.jpg'];
%     img=imread(Im_filename);
%    [m,n,~]=size(img);
%    gt=load(['D:\data\text\ICDAR2003\dataRename\Orisize\GT_mat1\' InImage(s).name(1:length(InImage(s).name)-4) '.mat']);
%     
%    
%    
%    [precision(s,1),recall(s,1)]=computeprecisionandrecall(region,gt.GT,m,n,img);
%     
% 
% end
% precision(find(isnan(precision)==1)) = 1;
% p=mean(precision);
% r=mean(recall);
% % ples=[];
% % pmore=[];
% % rles=[];
% % rmore=[];
% %save precision precision
% %save recall recall
% for s=1:length(InImage)
%     
%     Im_filename = ['D:\data\text\ICDAR2003\dataRename\Orisize\test\' InImage(s).name(1:length(InImage(s).name)-4) '.jpg'];
%     img=imread(Im_filename);
%     load(['C:\Users\dwightzy\Desktop\�½��ļ��� (3)\Result\' InImage(s).name(1:length(InImage(s).name)-4) '.mat']);
%     load(['D:\data\text\ICDAR2003\dataRename\Orisize\GT_mat1\' InImage(s).name(1:length(InImage(s).name)-4) '.mat']);
%     figure('Visible','off');
%     imshow(img);
%     hold on
%     for i=1:length(GT)
%         YY2=[GT{i}.data(2) GT{i}.data(2) GT{i}.data(2)+GT{i}.data(4)...
%             GT{i}.data(2)+GT{i}.data(4) GT{i}.data(2)];
%         XX2=[GT{i}.data(1) GT{i}.data(1)+GT{i}.data(3) GT{i}.data(1)+GT{i}.data(3)...
%             GT{i}.data(1) GT{i}.data(1)];
%         plot(XX2, YY2, 'y-');
%     end
%     for k=1:length(SecondRegion)
%         if  SecondRegion{k}.score>0.5
%         tangle=[SecondRegion{k}.data(1) SecondRegion{k}.data(2);
%             SecondRegion{k}.data(1) SecondRegion{k}.data(2)+SecondRegion{k}.data(4);
%             SecondRegion{k}.data(1)+SecondRegion{k}.data(3) SecondRegion{k}.data(2)+SecondRegion{k}.data(4);
%             SecondRegion{k}.data(1)+SecondRegion{k}.data(3) SecondRegion{k}.data(2)];
%             YY2=[tangle(1,1) tangle(2,1) tangle(3,1)...
%                 tangle(4,1) tangle(1,1)];
%             XX2=[tangle(1,2) tangle(2,2) tangle(3,2)...
%                 tangle(4,2) tangle(1,2)];
%             plot(YY2, XX2, 'g-');
%         end
%         %                 tangle=[SecondRegion{1,k}.data(3) SecondRegion{1,k}.data(1);
%         %             SecondRegion{1,k}.data(3) SecondRegion{1,k}.data(2);
%         %             SecondRegion{1,k}.data(4) SecondRegion{1,k}.data(2);
%         %             SecondRegion{1,k}.data(4) SecondRegion{1,k}.data(1)];
%         %         YY2=[tangle(1,1) tangle(2,1) tangle(3,1)...
%         %             tangle(4,1) tangle(1,1)];
%         %         XX2=[tangle(1,2) tangle(2,2) tangle(3,2)...
%         %             tangle(4,2) tangle(1,2)];
%         %         plot(YY2, XX2, 'g-');
%     end
%     title([num2str(precision(s,1)) '   ' num2str(recall(s,1))]);
%     tempresult_path = ['D:\data\text\ICDAR2003\code\PreRec\anns2\'...
%         InImage(s).name(1:length(InImage(s).name)-4)  '.jpg'];
%     saveas(gcf,tempresult_path,'jpg');
%     close all
%     % if length(OriRegion)>9
%     %     pmore=[pmore;precision(s,1)];
%     %     rmore=[rmore;recall(s,1)];
%     % else
%     %     ples=[ples;precision(s,1)];
%     %     rles=[rles;recall(s,1)];
%     % end
% end




InImage = dir('D:\data\text\ICDAR2003\code\dataRename\Resize\postsplit\*.mat');
precision=zeros(length(InImage),1);
recall=zeros(length(InImage),1);


for s=1:length(InImage)
     load(['D:\data\text\ICDAR2003\code\dataRename\Resize\postsplit\' InImage(s).name(1:length(InImage(s).name)-4) '.mat']);
     region={};
     k=0;
     for i=1:length(Newregion)
         if isempty(Newregion{i})<1
             tangle=[Newregion{i}.data(1) Newregion{i}.data(2);
                 Newregion{i}.data(1) Newregion{i}.data(2)+Newregion{i}.data(4);
                 Newregion{i}.data(1)+Newregion{i}.data(3) Newregion{i}.data(2)+Newregion{i}.data(4);
                 Newregion{i}.data(1)+Newregion{i}.data(3) Newregion{i}.data(2)];
             k=k+1;
             region{k}.tangle=tangle;
         end
     end
     Im_filename = ['D:\data\text\ICDAR2003\dataRename\Orisize\test\' InImage(s).name(1:length(InImage(s).name)-4) '.jpg'];
    img=imread(Im_filename);
   [m,n,~]=size(img);
   gt=load(['D:\data\text\ICDAR2003\dataRename\Orisize\GT_mat1\' InImage(s).name(1:length(InImage(s).name)-4) '.mat']);
    
   
   
   [precision(s,1),recall(s,1)]=computeprecisionandrecall(region,gt.GT,m,n,img);
    if precision(s,1)==0&&recall(s,1)==0
        fmeasure(s,1)=0;
    else 
    fmeasure(s,1)=2*precision(s,1)*recall(s,1)/(precision(s,1)+recall(s,1));
    end
end
%precision(find(isnan(precision)==1)) = 1;




p=mean(precision);
r=mean(recall);
f=mean(fmeasure);
% ples=[];
% pmore=[];
% rles=[];
% rmore=[];
%save precision precision
%save recall recall
for s=1:length(InImage)
    
    Im_filename = ['D:\data\text\ICDAR2003\dataRename\Orisize\test\' InImage(s).name(1:length(InImage(s).name)-4) '.jpg'];
    img=imread(Im_filename);
    load(['D:\data\text\ICDAR2003\code\dataRename\Resize\postsplit\' InImage(s).name(1:length(InImage(s).name)-4) '.mat']);
    load(['D:\data\text\ICDAR2003\dataRename\Orisize\GT_mat1\' InImage(s).name(1:length(InImage(s).name)-4) '.mat']);
    figure('Visible','off');
    imshow(img);
    hold on
    for i=1:length(GT)
        YY2=[GT{i}.data(2) GT{i}.data(2) GT{i}.data(2)+GT{i}.data(4)...
            GT{i}.data(2)+GT{i}.data(4) GT{i}.data(2)];
        XX2=[GT{i}.data(1) GT{i}.data(1)+GT{i}.data(3) GT{i}.data(1)+GT{i}.data(3)...
            GT{i}.data(1) GT{i}.data(1)];
        plot(XX2, YY2, 'y-');
    end
    for k=1:length(Newregion)
        if isempty(Newregion{k})<1
        tangle=[Newregion{k}.data(1) Newregion{k}.data(2);
            Newregion{k}.data(1) Newregion{k}.data(2)+Newregion{k}.data(4);
            Newregion{k}.data(1)+Newregion{k}.data(3) Newregion{k}.data(2)+Newregion{k}.data(4);
            Newregion{k}.data(1)+Newregion{k}.data(3) Newregion{k}.data(2)];
            YY2=[tangle(1,1) tangle(2,1) tangle(3,1)...
                tangle(4,1) tangle(1,1)];
            XX2=[tangle(1,2) tangle(2,2) tangle(3,2)...
                tangle(4,2) tangle(1,2)];
            plot(YY2, XX2, 'g-');
        end
    end
    title([num2str(precision(s,1)) '   ' num2str(recall(s,1))]);
    tempresult_path = ['D:\data\text\ICDAR2003\code\PreRec\anns2\'...
        InImage(s).name(1:length(InImage(s).name)-4)  '.jpg'];
    saveas(gcf,tempresult_path,'jpg');
    close all
    % if length(OriRegion)>9
    %     pmore=[pmore;precision(s,1)];
    %     rmore=[rmore;recall(s,1)];
    % else
    %     ples=[ples;precision(s,1)];
    %     rles=[rles;recall(s,1)];
    % end
end