function [precision,recall]=computeprecisionandrecall(reg,gt,m,n,img)
%  load('D:\fangcong\study\textdetection\�ҵĴ���\ICDAR\aPICT0006.mat');
%  img=imread('D:\fangcong\study\textdetection\ͼƬ\MRSA\MSRA-TD500\MSRA-TD500\test\IMG_0059.jpg');
%  [m,n,~]=size(img);
% 
%  gt=GT;
%  imgtest=draw(gt{1,1}.data,m,n);
%  figure;
%  imshow(imgtest);
% l=imggray.*imgtest;
%  %imshow(l);
% load('C:\Users\Administrator\Desktop\Orignal\IMG_0059.mat');
% reg=OriRegion;

 imggray=im2double(rgb2gray(img));
precision=0;
regn=length(reg);
gtn=length(gt);
llzong=0;
if regn==0
    precision=1;
else
for i=1:length(reg)
    imgreg=zeros(m,n);
%             tangle=reg{i}.tangle;
%         YY2=[tangle(1,1) tangle(2,1) tangle(3,1)...
%             tangle(4,1) tangle(1,1)];
%         XX2=[tangle(1,2) tangle(2,2) tangle(3,2)...
%             tangle(4,2) tangle(1,2)];
%         imgreg1=roipoly(imgreg,YY2(1:4),XX2(1:4));;
   imgreg=roipoly(imgreg,round(reg{i}.tangle(:,1)'),round(reg{i}.tangle(:,2)'));
%        figure;
%       imshow(imgreg.*imggray);
      close all
    llzong=llzong+length(find(imgreg>0.1));
    ll=0;
    for j=1:gtn
    temp=draw(gt{1,j}.data,m,n);
    tempun=temp.*imgreg;

    z=length(find(tempun>0));
%     if z>0.75*length(find(imgreg>0.1))
%         z=length(find(imgreg>0.1));
%     end
    if z>ll
        ll=z;
%        figure;
%       imshow(tempun.*imggray);
    end
    end
    precision=precision+ll;  
end
precision=precision/double(llzong);
end
if gtn==0
recall=1;
else
recall=0;
llzong=0;
for i=1:gtn
   imggtn=draw(gt{1,i}.data,m,n);
%         figure;
%        imshow(imggtn.*imggray);
    llzong=llzong+length(find(imggtn>0));
    ll=0;
    for j=1:regn
        temp=zeros(m,n);
         temp=roipoly(temp,round(reg{j}.tangle(:,1)'),round(reg{j}.tangle(:,2)'));
   
    tempun=temp.*imggtn;

    z=length(find(tempun>0.1));
%     if z>0.75*length(find(imggtn>0))
%        z=length(find(imggtn>0));
%     end
    if z>ll
        ll=z;
%       figure;
%      imshow(tempun);
    end
    end
   recall=recall+ll;  
end
recall=recall/double(llzong);
end
