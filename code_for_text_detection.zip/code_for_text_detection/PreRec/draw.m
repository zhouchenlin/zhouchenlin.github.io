function img=draw(gt,m,n)
      t1(1,1)=gt(1,1);t1(1,2)=gt(1,2);
      t1(2,1)=t1(1,1)+gt(1,3);t1(2,2)=t1(1,2);
      t1(3,1)=t1(2,1);t1(3,2)=t1(2,2)+gt(1,4);
      t1(4,1)=t1(1,1);t1(4,2)=t1(1,2)+gt(1,4);
       t1x=t1(:,1);t1y=t1(:,2);
      img=zeros(m,n);
       img=roipoly(img,t1x',t1y');