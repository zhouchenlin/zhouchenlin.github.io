function [ch]=genetextcha(his)   
[tt,~]=size(his);
u=0;
for i=1:tt;
    u=u+i*his(i,1);
end
    variance=0;
    squar=0;
    entro=0;
    skew=0;
    kuro=0;
    for i=1:tt
    variance=variance+((i-u)^2)*his(i,1);
    squar = squar+(his(i,1)^2);
    if(his(i,1)>0)
    entro = entro-his(i,1)*log(his(i,1));
    end
    skew=skew+((i-u)^3)*his(i,1);
    kuro=kuro+((i-u)^4)*his(i,1);   
    end
    smooth=1-1/(1+variance/(tt*tt));
    ch=[variance/(tt*tt); squar;entro/tt;smooth;skew/(tt*tt*tt);kuro/(tt*tt*tt*tt);];
   