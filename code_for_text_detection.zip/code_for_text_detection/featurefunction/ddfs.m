function  ddfs(x,y,wide)
global swt;
global lookuptable;
cnt=1;
while(lookuptable(x,y,cnt,1)~=0)
    if(swt(lookuptable(x,y,cnt,1),lookuptable(x,y,cnt,2))<wide)
    swt(lookuptable(x,y,cnt,1),lookuptable(x,y,cnt,2))=wide;
    ddfs(lookuptable(x,y,cnt,1),lookuptable(x,y,cnt,2),wide);
    end
  cnt=cnt+1;
end