function out=generconchara(img,imggray,pixlist)
% present gray r,g,b,sdist,height,cx,cy
out=zeros(1,8);
[m,n,~]=size(img);
coimg=zeros(m+4,n+4);
[ll,~]=size(pixlist);
for i=1:ll
out(1,1)=out(1,1)+imggray(pixlist(i,2),pixlist(i,1));
out(1,2)=out(1,2)+img(pixlist(i,2),pixlist(i,1),1);
out(1,3)=out(1,3)+img(pixlist(i,2),pixlist(i,1),2);
out(1,4)=out(1,4)+img(pixlist(i,2),pixlist(i,1),3);
coimg(pixlist(i,2)+2,pixlist(i,1)+2)=1;
end
% figure;
% imshow(img);
% figure;
% imshow(coimg);

[sdist,~]=geneswt(coimg);
out(1,5)=sum(sum(sdist));
out=out/ll;
out(1,6)=(max(pixlist(:,2))-min(pixlist(:,2)))/m;
out(1,7)=mean(pixlist(:,1))/n;
out(1,8)=mean(pixlist(:,2))/m;


