function [swtt,dist]=geneswt(aa)
set(0,'RecursionLimit',2000);
[m,n]=size(aa);
pan=zeros(m,n);
star=1;endd=0;
que=zeros(m*n,2);
dist=zeros(m,n);
for i=1:m
    for j=1:n
        if(aa(i,j)==0)
            pan(i,j)=1;
             endd=endd+1;
            que(endd,1)=i;que(endd,2)=j;          
        end
    end
end
while(star<=endd)
    q=que(star,1);
           w=que(star,2);
           star=star+1;
           for con1=-1:1
               for con2=-1:1
                   if (q+con1>=1)&&(q+con1<=m)&&(w+con2>=1)&&(w+con2<=n)
                       if (pan(q+con1,w+con2)==0)
                           endd=endd+1;
                            que(endd,1)=q+con1;
                            que(endd,2)=w+con2;
                            pan(q+con1,w+con2)=1;
                            dist(q+con1,w+con2)=dist(q,w)+1;
                       end
                   end
               end
           end
 end 
global lookuptable;
lookuptable=zeros(m,n,9,2);
for i=1:m
    for j=1:n
        if(aa(i,j)==1)
            cnt=1;
            for con1=-1:1
               for con2=-1:1
                   if (i+con1>=1)&&(i+con1<=m)&&(j+con2>=1)&&(j+con2<=n)
                       if aa(i+con1,j+con2)==1&&dist(i+con1,j+con2)<dist(i,j)
                      lookuptable(i,j,cnt,1)=i+con1;
                      lookuptable(i,j,cnt,2)=j+con2;
                      cnt=cnt+1;
                       end
                   end
               end
             end
        end
    end
end
global swt;
swt=dist;
maxx = max(max(swt));
for cont=maxx:-1:1
    in=zeros(m*n,2);
    cnt=0;
    for i=1:m
        for j=1:n
            if swt(i,j)==cont
                cnt=cnt+1;
                in(cnt,1)=i;
                in(cnt,2)=j;
            end
        end
    end
 for i=1:cnt
ddfs(in(i,1),in(i,2),cont);
 end
end
 swtt=swt;
               
             
             
             