function [Eim, Oim, Aim] = spatialgabor(im, wavelength, angle, br,bthe)


    
    im = double(im);
    [rows, cols] = size(im);
    newim = zeros(rows,cols);
    
    % Construct even and odd Gabor filters
   % sigmax = wavelength*kx;
    %sigmay = 1.7*sigmax;
    sigmax=(wavelength*(2^br+1)/(2^br-1))/(pi*sqrt(2));
    sigmay = wavelength/(pi*sqrt(2)*tan(bthe/2));
    
    sze = round(3*max(sigmax,sigmay));
    [x,y] = meshgrid(-sze:sze);
    evenFilter = exp(-(x.^2/sigmax^2 + y.^2/sigmay^2)/2)...
    .*cos(2*pi*(1/wavelength)*x);
    
    oddFilter = exp(-(x.^2/sigmax^2 + y.^2/sigmay^2)/2)...
    .*sin(2*pi*(1/wavelength)*x);    


    evenFilter = imrotate(evenFilter, angle, 'bilinear');
    oddFilter = imrotate(oddFilter, angle, 'bilinear');    


    % Do the filtering
%     Eim = filter2(evenFilter,im); % Even filter result
%     Oim = filter2(oddFilter,im);  % Odd filter result
       Eim = imfilter(im,evenFilter,'replicate'); % Even filter result
    Oim = imfilter(im,oddFilter,im,'replicate');  % Odd filter result
    Aim = sqrt(Eim.^2 + Oim.^2);  % Amplitude 
    