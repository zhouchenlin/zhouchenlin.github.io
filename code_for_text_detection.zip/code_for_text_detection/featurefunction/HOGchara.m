 addpath('D:\fangcong\study\textdetection\�ҵĴ���\ColorFeaturesedge');
InImage = dir('D:\fangcong\study\textdetection\�ҵĴ���\����\regiontrain\*.mat');
for s=166:length(InImage)
    Im_filename = ['D:\fangcong\study\textdetection\�ҵĴ���\reduce\Oritrain\' InImage(s).name(1:size(InImage(s).name,2)-4) '.jpg'];
    %Im_filename = ['D:\fangcong\study\textdetection\�ҵĴ���\reduce\Ori\' InImage(s).name(1:size(InImage(s).name,2)-4) '.jpg'];
    imgori=imread(Im_filename);
    file=['D:\fangcong\study\textdetection\�ҵĴ���\����\regiontrain\' InImage(s).name];
%     figure;
%     imshow(imgori);
    load(file);
  %rec=load(file);  
  for ii=1:length(region)
  smallrec=round(region{ii}.data);
  img=imgori(smallrec(1,1):smallrec(1,2),smallrec(1,3):smallrec(1,4),:);
  chara=[];
%    figure;
%    imshow(img);

    
   %generate hog feature  78
   hogg=ImgHOGFeature(img,16,2,0.5,360,12);
    hog=(sum(hogg'))';
    temp=zeros(12,1);
    for i=1:size(hog,1)
        ll=mod(i,12);
        if ll==0
            ll=12;
        end
        temp(ll,1)=temp(ll,1)+hog(i,1);
    end
    Hog=temp;
    Hog=Hog/max(Hog);
    avHog=sum(Hog)/12;
    sq=(Hog-avHog)*(Hog-avHog)';
    for i=1:12
        for j=i:12
    chara=[chara;sq(i,j)];
        end
    end
    
    
    %generate gabor feature 6
   imggray=rgb2gray(img);
   [m,n]=size(imggray);
   %choose f "7.5, 15 and 30 cycles/image-width
   [~,~,imgabor]=spatialgabor(imggray,min(m,n)/7.5,0,1,pi/4);
   imgabor(find(imgabor>400))=400; 
   ch=sum(sum(imgabor))/((m*n)*400);
    chara=[chara;ch];
%     figure;
%     imshow(uint8(imgabor));
   [~,~,imgabor]=spatialgabor(imggray,min(m,n)/15,0,1,pi/4);
   imgabor(find(imgabor>400))=400; 
   ch=sum(sum(imgabor))/((m*n)*400);
    chara=[chara;ch];
%     figure;
%     imshow(uint8(imgabor));
   [~,~,imgabor]=spatialgabor(imggray,min(m,n)/30,0,1,pi/4);
   imgabor(find(imgabor>400))=400; 
   ch=sum(sum(imgabor))/((m*n)*400);
    chara=[chara;ch];
%     figure;
%     imshow(uint8(imgabor));
   [~,~,imgabor]=spatialgabor(imggray,min(m,n)/7.5,45,1,pi/4);
   imgabor(find(imgabor>400))=400; 
   ch=sum(sum(imgabor))/((m*n)*400);
    chara=[chara;ch];
%     figure;
%     imshow(uint8(imgabor));
  [~,~,imgabor]=spatialgabor(imggray,min(m,n)/15,45,1,pi/4);
   imgabor(find(imgabor>400))=400; 
   ch=sum(sum(imgabor))/((m*n)*400);
    chara=[chara;ch];
%     figure;
%     imshow(uint8(imgabor));
   [~,~,imgabor]=spatialgabor(imggray,min(m,n)/30,45,1,pi/4);
   imgabor(find(imgabor>400))=400; 
   ch=sum(sum(imgabor))/((m*n)*400);
    chara=[chara;ch];
%     figure;
%     imshow(uint8(imgabor));
    
    %generate texture measure 6
    his=imhist(imggray);
    his=his/(m*n);
    chara = [chara;genetextcha(his)];
    
    %generate edge chara  (6+10)*2
    sigma1=5;                                   % standard deviation gaussian derivative kernel
    sigma2=1;     % standard deviation gaussian averaging kernel
    edgeT=5;

    [edge]=color_canny(img, sigma1, sigma2, 0);
    edgeimg=zeros(m,n);
    for i=1:m
        for j=1:n
            if edge(i,j)>edgeT
                edgeimg(i,j)=1;
            end
        end
    end
%     figure;
%     imshow(edgeimg);
    ddx=(sum(edgeimg))';
    u=floor(n/10);
    dx=zeros(10,1);
    zo=sum(ddx);
    for i=1:9
    dx(i,1)=sum(ddx(1+u*(i-1):u*i,1))/zo;
    chara=[chara;dx(i,1)];
    end
        dx(10,1)=sum(ddx(1+u*9:n,1))/zo;
    chara=[chara;dx(10,1)];
    chara=[chara;genetextcha(dx)];   
    ddy=(sum(edgeimg'))';
        u=floor(m/10);
    dy=zeros(10,1);
    zo=sum(ddy);
    for i=1:9
    dy(i,1)=sum(ddy(1+u*(i-1):u*i,1))/zo;
    chara=[chara;dy(i,1)];
    end
            dy(10,1)=sum(ddy(1+u*9:m,1))/zo;
    chara=[chara;dy(10,1)];
    chara=[chara;genetextcha(dy)];  
    
    %add wavelet and dy feature 4 6
    wa=ExtractFeatureWavelet(imggray);
    wdy=ExtractFeatureDxDy(imggray);
   chara=[chara;wa;wdy];
   region{ii}.feature=chara;
  close all;
  end
      feature_filename = ['D:\fangcong\study\textdetection\�ҵĴ���\HOG\featuretrain\'...
   InImage(s).name(1:length(InImage(s).name)-4)];
      save(feature_filename,'region');
end