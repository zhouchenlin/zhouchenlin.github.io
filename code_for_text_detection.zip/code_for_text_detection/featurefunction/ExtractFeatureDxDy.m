function feature= ExtractFeatureDxDy(im)

%img=imread('IMG_0479.jpg');

[M N]=size(im);

sobelMask = fspecial('sobel');
dy = imfilter(im,sobelMask);
dx = imfilter(im,sobelMask');


xset=sum(dx');
% plot(xset);
XX=smooth(xset,0.1,'loess');
Tmean=mean(XX);
Tstd=std(XX);

DXX=diff(XX);

peakmax=fpeakmax(1:M-1,DXX,10,[2,M-2,mean(DXX)+std(DXX),inf]);

if size(peakmax,1)>2
    Xtemp1=XX(1:round((peakmax(1,1)+1)/2));
    Xtemp2=XX(round((peakmax(1,1)+1)/2):round((peakmax(1,1)+M)/2));
    Xtemp3=XX(peakmax(end,1)+1:M);
else
    Xtemp1=XX(1:round(M/4));
    Xtemp2=XX(round(M/4):round(3*M/4));
    Xtemp3=XX(round(3*M/4):M);
end
feature=[mean(Xtemp1)/Tmean std(Xtemp1)/Tstd mean(Xtemp2)/Tmean std(Xtemp2)/Tstd mean(Xtemp3)/Tmean std(Xtemp3)/Tstd]';







