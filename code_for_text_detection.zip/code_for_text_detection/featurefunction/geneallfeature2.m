 function [Newregion]=geneallfeature2(Newregion,Region,imgori)    
 maa=0;
 for ii=1:length(Newregion)
 maa=max(maa,length(Newregion{1,ii}.component));
 end
 
 M=size(imgori,1);
 N=size(imgori,2);
 
 for ii=1:length(Newregion)
      cor=round(Newregion{1,ii}.data);
      X(1)=max(1,cor(1,2));
      X(2)=min(M,cor(1,2)+cor(1,4));
      X(3)=max(1,cor(1,1));
      X(4)=min(N,cor(1,1)+cor(1,3));
      cor(find(cor<1))=1;
        img=imgori(X(1):X(2),X(3):X(4),:);
        %img=imgori(cor(1,1):cor(1,3),cor(1,2):cor(1,4),:);
        %img=Newregion{1,ii}.img;
        img=im2double(img);
        imggray=rgb2gray(img);
%         figure;
%         imshow(img);
        connectlist=Newregion{1,ii}.component;
        chara=[];
        
        %genehog
   sqq=zeros(length(connectlist),16);   
   [m,n,~]=size(img);
    for j=1:length(connectlist)
             
            pixlist=Region{1,connectlist(j)}.Pixel;
            %change cordinate
            pixlist(:,1)=pixlist(:,1)-cor(1,1)+1;
            pixlist(:,2)=pixlist(:,2)-cor(1,2)+1;
            pixlist=round(pixlist);
            pixlist(find(pixlist(:,1)>n),1)=n;
            pixlist(find(pixlist(:,2)>m),2)=m;
            pixlist(find(pixlist<1))=1;
 
coimg=zeros(m+4,n+4);
[ll,~]=size(pixlist);
for i=1:ll
coimg(pixlist(i,2)+2,pixlist(i,1)+2)=imggray(pixlist(i,2),pixlist(i,1));
end
        hogg=ImgHOGFeature(coimg,8,2,0.5,360,16);
        hog=(sum(hogg'))';
        temp=zeros(16,1);
        for i=1:size(hog,1)
            ll=mod(i,16);
            if ll==0
                ll=12;
            end
            temp(ll,1)=temp(ll,1)+hog(i,1);
        end
        Hog=temp;
        Hog=Hog/(max(Hog)+1e-9);
        sqq(j,:)=Hog; 
    end
    if length(connectlist)==1
        avHog=sqq;
    else
     avHog=mean(sqq);
    end
        sq=zeros(16,16);
         for j=1:length(connectlist)
         sq=sq+(sqq(j,:)-avHog)'*(sqq(j,:)-avHog);
         end
         sq=sq/length(connectlist);
         for i=1:16
            for j=i:16
                chara=[chara;sq(i,j)];
            end
        end
        
        
        
        %generate gabor feature 6

        [m,n]=size(imggray);
        %choose f "7.5, 15 and 30 cycles/image-width
        [~,~,imgabor]=spatialgabor(imggray,min(m,n)/7.5,0,1,pi/4);
        imgabor(find(imgabor>400))=400;
        ch=sum(sum(imgabor))/((m*n)*400);
        chara=[chara;ch];
        %     figure;
        %     imshow(uint8(imgabor));
        [~,~,imgabor]=spatialgabor(imggray,min(m,n)/15,0,1,pi/4);
        imgabor(find(imgabor>400))=400;
        ch=sum(sum(imgabor))/((m*n)*400);
        chara=[chara;ch];
        %     figure;
        %     imshow(uint8(imgabor));
        [~,~,imgabor]=spatialgabor(imggray,min(m,n)/30,0,1,pi/4);
        imgabor(find(imgabor>400))=400;
        ch=sum(sum(imgabor))/((m*n)*400);
        chara=[chara;ch];
        %     figure;
        %     imshow(uint8(imgabor));
        [~,~,imgabor]=spatialgabor(imggray,min(m,n)/7.5,45,1,pi/4);
        imgabor(find(imgabor>400))=400;
        ch=sum(sum(imgabor))/((m*n)*400);
        chara=[chara;ch];
        %     figure;
        %     imshow(uint8(imgabor));
        [~,~,imgabor]=spatialgabor(imggray,min(m,n)/15,45,1,pi/4);
        imgabor(find(imgabor>400))=400;
        ch=sum(sum(imgabor))/((m*n)*400);
        chara=[chara;ch];
        %     figure;
        %     imshow(uint8(imgabor));
        [~,~,imgabor]=spatialgabor(imggray,min(m,n)/30,45,1,pi/4);
        imgabor(find(imgabor>400))=400;
        ch=sum(sum(imgabor))/((m*n)*400);
        chara=[chara;ch];
        
        
        %generate texture measure 6
        his=imhist(imggray);
        his=his/(m*n);
        chara = [chara;genetextcha(his)];
        
        %add wavelet and dy feature 4 6
        wa=ExtractFeatureWavelet(imggray);
        wdy=ExtractFeatureDxDy(imggray);
        chara=[chara;wa;wdy];
        
        %connection  must be sort
        conchar=zeros(length(connectlist),10);
        temp=zeros(length(connectlist),8);

        so=zeros(length(connectlist),1);
        for j=1:length(connectlist)
            pixlist=Region{1,connectlist(j)}.Pixel;
            %change cordinate
            pixlist(:,1)=pixlist(:,1)-cor(1,1)+1;
            pixlist(:,2)=pixlist(:,2)-cor(1,2)+1;
            pixlist=round(pixlist);
            pixlist(find(pixlist(:,1)>n),1)=n;
            pixlist(find(pixlist(:,2)>m),2)=m;
            pixlist(find(pixlist<1))=1;
            %gray r g b sdist height cx cy  temp j*8
            temp(j,:)=generconchara(img,imggray,pixlist);
            for kk=1:8
                conchar(j,kk)=temp(j,kk);
            end
            so(j,1)=temp(j,7);
        end
        
        %sort
        [~,inst]=sort(so);
        conchar1=zeros(length(connectlist),10);
        temp1=zeros(length(connectlist),8);
        for j=1:length(connectlist)
        conchar1(j,:)=conchar(inst(j),:);
        temp1(j,:)=temp(inst(j),:);
        end
        temp=temp1;
        conchar=conchar1;
        
        
        
        conchar(:,4)=conchar(:,4)/max(conchar(:,4));
        if length(connectlist)==1
            conchar(:,9)=0;
            conchar(:,10)=0;
        else
            for j=1:length(connectlist)-1
                conchar(j,9)=(temp(j+1,7)-temp(j,7))/sqrt((temp(j+1,8)-temp(j,8))^2+(temp(j+1,7)-temp(j,7)^2));
                conchar(j,10)=temp(j+1,7)-temp(j,7);
            end
            conchar(length(connectlist),9)=conchar(length(connectlist)-1,9);
            conchar(length(connectlist),10)=conchar(length(connectlist)-1,10);
        end
        for j=1:10
            conchar(:,j)=conchar(:,j)-mean(conchar(:,j));
        end
        conn=zeros(10,10);
        for j=1:length(connectlist)
            conn=conn+ conchar(j,:)'* conchar(j,:);
        end
        %if length(connectlist)==1 how to
        conn=conn/length(connectlist);
        
        for i=1:10
            for j=i:10
                chara=[chara;conn(i,j)];
            end
        end
        chara=[chara;length(connectlist)/(maa*10)];
        Newregion{1,ii}.feature=chara;
    end
    