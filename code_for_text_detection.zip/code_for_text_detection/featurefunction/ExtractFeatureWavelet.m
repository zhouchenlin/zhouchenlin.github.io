function feature= ExtractFeatureWavelet(im)


%img=imread('IMG_0030.jpg');


[M N]=size(im);
%im=imresize(im,sqrt(3072/(M*N))*[M N]);
im=im2double(im);
[A,H,V,D] = dwt2(im,'db10');

feature=[std(A(:)) std(H(:)) std(V(:)) std(D(:))]';



