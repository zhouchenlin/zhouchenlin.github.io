﻿The code is for paper "A robust hybrid method for text detection in natural scenes
by learning-based partial differential equations" 
by Zhenyu Zhao, Cong Fang, Zhouchen Lin, Yi Wu.
To appear in Neurocomputing(2015), http://dx.doi.org/10.1016/j.neucom.2015.06.019i.
written by Zhenyu Zhao and Cong Fang
Email: dwightzzy@gmail.com,tjufangcong19911231@gmail.com
******************************************************************************************************************
The code is tested on Windows 8 with MATLAB R2013b.
******************************************************************************************************************
Usage:
>put the test images into file '\data\ORI'
>run 'demo.m'
******************************************************************************************************************
Note: We use the Adaboost software for classification 〈http://
graphics.cs.msu.ru/en/science/research/machinelearning/adaboosttoolbox〉.
and some graph functions in the Graph Analysis Toolbox (http://eslab.bu.edu/software/graphanalysis/).

