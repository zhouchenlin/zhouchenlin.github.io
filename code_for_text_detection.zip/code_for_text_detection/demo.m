clear all
close all
clc
warning('off');
%%read images
 InImage = dir('.\data\ORI\*.jpg');
%%%add functions
%%%for feature extraction
addpath('.\featurefunction\');
%%%for classification
addpath('.\GML_AdaBoost_Matlab_Toolbox_0.3\')
%%%for  graph theory toolbox
addpath('.\matlab_bgl\matlab_bgl\')
%%%for learning PDEs
addpath('.\LPDE\textdetection\')
%%%for plot Tangle
addpath('.\Tangle\');
addpath('.\ORITangle\');
%%%for clustering
addpath('.\Cluster\');
%%%Others
addpath('.\Process\');
disp('read the learnt coefficients of PDEs...')
load( '.\coef\20110116\a.mat');
load( '.\coef\20110116\b.mat');
disp('read parameters for classification...')
load( '.\coef\parameters2011\TTLearners.mat');
load( '.\coef\parameters2011\TTWeights.mat');
load( '.\coef\parameters2011\CCLearners.mat');
load( '.\coef\parameters2011\CCWeights.mat');
for s=1:length(InImage)
    disp('Read Image...')
    imgori_path=['.\data\ORI\' InImage(s).name];
    imgORI=imread(imgori_path);
    M_ori=size(imgORI,1);
    N_ori=size(imgORI,2);
    [Reg,scale]=TextDetection(imgORI,InImage(s).name,a,b,TTLearners,TTWeights,CCLearners,CCWeights);     
    for i=1:length(Reg)
        Reg{i}.data=Reg{i}.data/scale^2;
        tangle=[Reg{i}.data(1) Reg{i}.data(2);
            Reg{i}.data(1) Reg{i}.data(2)+Reg{i}.data(4);
            Reg{i}.data(1)+Reg{i}.data(3) Reg{i}.data(2)+Reg{i}.data(4);
            Reg{i}.data(1)+Reg{i}.data(3) Reg{i}.data(2)];
        Reg{i}.tangle=tangle;
    end
    figure;imshow(imgORI);hold on
    for i=1:length(Reg)
        YY2=[Reg{i}.data(2) Reg{i}.data(2) Reg{i}.data(2)+Reg{i}.data(4)...
            Reg{i}.data(2)+Reg{i}.data(4) Reg{i}.data(2)];
        XX2=[Reg{i}.data(1) Reg{i}.data(1)+Reg{i}.data(3) Reg{i}.data(1)+Reg{i}.data(3)...
            Reg{i}.data(1) Reg{i}.data(1)];
        plot(XX2, YY2, 'g-');
        hold on, text(XX2(1), YY2(1), num2str(i), 'EdgeColor','blue');
    end
end