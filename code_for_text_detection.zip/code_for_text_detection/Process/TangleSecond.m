function Reg=TangleSecond(imgORI,myregion,InImage,MLearners,MWeights,CCLearners,CCWeights,type)
warning('off');
M_ori=size(imgORI,1);
N_ori=size(imgORI,2);
mkdir(['.\data\retangle\' type]);
mkdir(['.\data\cluster\' type]);
if strcmp(type,'Color')
    disp('��ɫ����')
    RegionCC={};%%%
    RegionTangle={};
    for i=1:length(myregion)
        A0=length(RegionCC);
        X(1)=max(1,myregion{i}.data(2));
        X(2)=min(M_ori,myregion{i}.data(2)+myregion{i}.data(4));
        X(3)=max(1,myregion{i}.data(1));
        X(4)=min(N_ori,myregion{i}.data(1)+myregion{i}.data(3));
        I_rgb=imgORI(X(1):X(2),X(3):X(4),:);
        [RegionCCTemp,RegionTangleTemp]=Color_cluster(I_rgb,X,CCLearners,CCWeights,A0);
        RegionCC=[RegionCC RegionCCTemp];
        RegionTangle=[RegionTangle RegionTangleTemp];
    end
    tempresult_path = ['.\data\cluster\' type '\'...
        InImage.name(1:end-4)];
    save(tempresult_path,'RegionCC');
    cont=0;
    Newregion={};
    for k=1:length(RegionTangle)
        X(1)=max(1,RegionTangle{k}.data(2));
        X(2)=min(M_ori,RegionTangle{k}.data(2)+RegionTangle{k}.data(4));
        X(3)=max(1,RegionTangle{k}.data(1));
        X(4)=min(N_ori,RegionTangle{k}.data(1)+RegionTangle{k}.data(3));
        if  (X(1)-X(2))*(X(3)-X(4))>100&&(X(2)-X(1))>5&&(X(4)-X(3))>10&&(X(2)-X(1))/(X(4)-X(3))<1
            cont=cont+1;
            Newregion{cont}.img=imgORI(X(1):X(2),X(3):X(4),:);
            Newregion{cont}.data=[X(3),X(1),X(4)-X(3),X(2)-X(1)];
            Newregion{cont}.component=RegionTangle{k}.component;
        end
    end
    
    %%%��ȡ����
    disp('��ȡ����')
    Newregion=geneallfeature(Newregion,RegionCC,imgORI);
    %%%����
    disp('����')
    weak_learner = tree_node_w(8);
    for i=1:length(Newregion)
        testData= Newregion{i}.feature';
        testData(find(isnan(testData)==1)) = 0;
        P=Classify(MLearners, MWeights, testData');
        anns = sign(P);
        P1=exp(P);
        Newregion{i}.score1=P1./(P1+ones(1,length(P1)));
        idC=Newregion{i}.component;
        Score2=0;
        for j=1:length(idC)
            Score2=Score2+RegionCC{idC(j)}.score;
        end
        Score2=Score2/length(idC);
        Newregion{i}.score2=Score2;
        Newregion{i}.score=(Newregion{i}.score2+ 9*Newregion{i}.score1)/10;
    end
    tempresult_path = ['.\data\retangle\' type '\'...
        InImage.name(1:end-4)];
    save(tempresult_path,'Newregion');
    
    
    %%%���ڷִ�
    disp('�ִ�')
    cont=0;
    Reg={};
    for i=1:length(Newregion)
        if Newregion{i}.score>0.5
            X=Newregion{i}.data;
            Ratio=X(3)/X(4);
            idC=Newregion{i}.component;
            regiontemp=split_region(RegionCC(idC),i);
            for k=1:length(regiontemp)
                Xtemp=regiontemp{k}.data;
                if  Xtemp(3)*Xtemp(4)>100&&Xtemp(4)>5&&Xtemp(3)>10
                    if Ratio>1&&(length(Newregion{i}.component)>=2||Newregion{i}.score>0.8)
                        cont=cont+1;
                        Reg{cont}.data=regiontemp{k}.data;
                        Reg{cont}.component=Newregion{i}.component;
                        Reg{cont}.score=Newregion{i}.score;
                    end
                end
            end
        end
    end
    disp('ȥ���ظ��Ŀ�')
    Reg=RemoveChildren(Reg);
else if strcmp(type,'BW')
        disp('��ֵ������')
        RegionCC={};%%%
        RegionTangle={};
        for i=1:length(myregion)
            A0=length(RegionCC);
            X(1)=max(1,myregion{i}.data(2));
            X(2)=min(M_ori,myregion{i}.data(2)+myregion{i}.data(4));
            X(3)=max(1,myregion{i}.data(1));
            X(4)=min(N_ori,myregion{i}.data(1)+myregion{i}.data(3));
            I_rgb=imgORI(X(1):X(2),X(3):X(4),:);
            [RegionCCTemp,RegionTangleTemp]=BW_Cluster(I_rgb,X,CCLearners,CCWeights,A0);
            RegionCC=[RegionCC RegionCCTemp];
            RegionTangle=[RegionTangle RegionTangleTemp];
        end
        tempresult_path = ['.\data\cluster\' type '\'...
            InImage.name(1:end-4)];
        save(tempresult_path,'RegionCC');
        cont=0;
        Newregion={};
        for k=1:length(RegionTangle)
            X(1)=max(1,RegionTangle{k}.data(2));
            X(2)=min(M_ori,RegionTangle{k}.data(2)+RegionTangle{k}.data(4));
            X(3)=max(1,RegionTangle{k}.data(1));
            X(4)=min(N_ori,RegionTangle{k}.data(1)+RegionTangle{k}.data(3));
            if  (X(1)-X(2))*(X(3)-X(4))>100&&(X(2)-X(1))>5&&(X(4)-X(3))>10&&(X(2)-X(1))/(X(4)-X(3))<1
                cont=cont+1;
                Newregion{cont}.img=imgORI(X(1):X(2),X(3):X(4),:);
                Newregion{cont}.data=[X(3),X(1),X(4)-X(3),X(2)-X(1)];
                Newregion{cont}.component=RegionTangle{k}.component;
            end
        end
        %%%��ȡ����
        disp('��ȡ����')
        [Newregion]=geneallfeature2(Newregion,RegionCC,imgORI);
        %%%����
        disp('����')
        weak_learner = tree_node_w(8);
        for i=1:length(Newregion)
            testData= Newregion{i}.feature';
            testData(find(isnan(testData)==1)) = 0;
            P=Classify(MLearners, MWeights, testData');
            anns = sign(P);
            P1=exp(P);
            Newregion{i}.score1=P1./(P1+ones(1,length(P1)));
            idC=Newregion{i}.component;
            Score2=0;
            for j=1:length(idC)
                Score2=Score2+RegionCC{idC(j)}.score;
            end
            Score2=Score2/length(idC);
            Newregion{i}.score2=Score2;
            Newregion{i}.score=(Newregion{i}.score2+ 9*Newregion{i}.score1)/10;
        end
        tempresult_path = ['.\data\retangle\' type '\'...
            InImage.name(1:end-4)];
        save(tempresult_path,'Newregion');
        
        %%%���ڷִ�
        disp('�ִ�')
        cont=0;
        Reg={};
        for i=1:length(Newregion)
            if Newregion{i}.score>0.5
                X=Newregion{i}.data;
                Ratio=X(3)/X(4);
                idC=Newregion{i}.component;
                regiontemp=split_region(RegionCC(idC),i);
                for k=1:length(regiontemp)
                    Xtemp=regiontemp{k}.data;
                    if  Xtemp(3)*Xtemp(4)>100&&Xtemp(4)>5&&Xtemp(3)>10
                        if Ratio>1&&(length(Newregion{i}.component)>=2||Newregion{i}.score>0.8)
                            cont=cont+1;
                            Reg{cont}.data=regiontemp{k}.data;
                            Reg{cont}.component=Newregion{i}.component;
                            Reg{cont}.score=Newregion{i}.score;
                        end
                    end
                end
            end
        end
        disp('ȥ���ظ��Ŀ�')
        Reg=RemoveChildren(Reg);
    end
end


