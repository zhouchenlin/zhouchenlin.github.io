function Region=RemoveRepetition(Reg)

for i=1:length(Reg)
    XF=Reg{i}.data;
    if XF(3)/XF(4)<1.3&&Reg{i}.score<0.9
        Reg{i}.score=0;
    end
end

for i=1:length(Reg)
    for j=i+1:length(Reg)
        A=[Reg{i}.data(1) Reg{i}.data(1)+Reg{i}.data(3) Reg{i}.data(2) Reg{i}.data(2)+Reg{i}.data(4)];
        B=[Reg{j}.data(1) Reg{j}.data(1)+Reg{j}.data(3) Reg{j}.data(2) Reg{j}.data(2)+Reg{j}.data(4)];
        UN=( max(A(2),B(2))-min(A(1),B(1)) )* ( max(A(4),B(4)) - min(A(3),B(3)) );
        IN=FF(A(1:2),B(1:2)) * FF(A(3:4),B(3:4));
        Ratio=0.9*Reg{i}.data(3)*Reg{i}.data(4)/(Reg{j}.data(3)*Reg{j}.data(4));
        if IN/UN>0.5
          %  if Ratio*Reg{i}.score>Reg{j}.score
            if Reg{i}.score>=Reg{j}.score
                Reg{j}.score=0;
            else
                Reg{i}.score=0;
            end
        end
    end
end
Region={};
ii=0;
for i=1:length(Reg)
    if Reg{i}.score>0.2
        ii=ii+1;
        Region(ii)=Reg(i);
    end
end


function C=FF(A,B)
C=0;
if B(1)>=A(1)&&B(1)<=A(2)
    if A(2)<B(2)
        C=A(2)-B(1);
    else
        C=B(2)-B(1);
    end
end
if A(1)>=B(1)&&A(1)<=B(2)
    if B(2)<A(2)
        C=B(2)-A(1);
    else
        C=A(2)-A(1);
    end
end