function Region=CombineBC(RegionColor,RegionBW,M_ori,N_ori)

MaxScore1=0;
MaxScore2=0;
for i=1:length(RegionBW)
    if RegionBW{i}.score>MaxScore1
        MaxScore1=RegionBW{i}.score;
    end
end
for i=1:length(RegionColor)
    if RegionColor{i}.score>MaxScore2
        MaxScore2=RegionColor{i}.score;
    end
end

if MaxScore1<MaxScore2
    Region=RegionColor;
    for i=1:length(Region)
        Region{i}.label=1;
    end
    id=length(Region);
    for i=1:length(RegionBW)
        XB=RegionBW{i}.data;
        BC=0;
        if XB(3)*XB(4)>(M_ori*N_ori/5000)&&RegionBW{i}.score>0.8
            for j=1:length(RegionColor)
                XC=RegionColor{j}.data;
                if (min(XB(1)+XB(3),XC(1)+XC(3))-max(XB(1),XC(1)))>0&&(min(XB(2)+XB(4),XC(2)+XC(4))-max(XB(2),XC(2)))>0
                    Inter=(min(XB(1)+XB(3),XC(1)+XC(3))-max(XB(1),XC(1)))*(min(XB(2)+XB(4),XC(2)+XC(4))-max(XB(2),XC(2)));
                else
                    Inter=0;
                end
                Join=(max(XB(1)+XB(3),XC(1)+XC(3))-min(XB(1),XC(1)))*(max(XB(2)+XB(4),XC(2)+XC(4))-min(XB(2),XC(2)));
                AreaRatio=Inter/Join;
                if AreaRatio>0.75
                    if RegionBW{i}.score>RegionColor{j}.score
                        Region(j)=RegionBW(i);
                        Region{j}.label=0;
                    end
                end
                BC=BC+AreaRatio;
            end
            if BC<0.2
                id=id+1;
                Region(id)=RegionBW(i);
                Region{id}.label=0;
            end
        end
    end
else
    Region=RegionBW;
    for i=1:length(Region)
        Region{i}.label=0;
    end
    id=length(Region);
    for i=1:length(RegionColor)
        XC=RegionColor{i}.data;
        BC=0;
        if XC(3)*XC(4)>(M_ori*N_ori/5000)&&RegionColor{i}.score>0.8
            for j=1:length(RegionBW)
                XB=RegionBW{j}.data;
                if (min(XB(1)+XB(3),XC(1)+XC(3))-max(XB(1),XC(1)))>0&&(min(XB(2)+XB(4),XC(2)+XC(4))-max(XB(2),XC(2)))>0
                    Inter=(min(XB(1)+XB(3),XC(1)+XC(3))-max(XB(1),XC(1)))*(min(XB(2)+XB(4),XC(2)+XC(4))-max(XB(2),XC(2)));
                else
                    Inter=0;
                end
                Join=(max(XB(1)+XB(3),XC(1)+XC(3))-min(XB(1),XC(1)))*(max(XB(2)+XB(4),XC(2)+XC(4))-min(XB(2),XC(2)));
                AreaRatio=Inter/Join;
                if AreaRatio>0.75
                    if RegionColor{i}.score>RegionBW{j}.score
                        Region(j)=RegionColor(i);
                        Region{j}.label=1;
                    end
                end
                BC=BC+AreaRatio;
            end
            if BC<0.2
                id=id+1;
                Region(id)=RegionColor(i);
                Region{id}.label=1;
            end
        end
    end
end