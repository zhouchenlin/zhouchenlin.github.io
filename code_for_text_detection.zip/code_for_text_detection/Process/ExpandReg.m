function Reg=ExpandReg(imgORI,Reg)
   M_ori=size(imgORI,1);
   N_ori=size(imgORI,2);
   disp('����')
   for ii=1:length(Reg)
        X(1)=max(1,Reg{ii}.data(2));
        X(2)=min(M_ori,Reg{ii}.data(2)+Reg{ii}.data(4));
        X(3)=max(1,Reg{ii}.data(1));
        X(4)=min(N_ori,Reg{ii}.data(1)+Reg{ii}.data(3));
        imgtmp=imgORI(X(1):floor(X(2)),X(3):floor(X(4)),:);
        tmp=rgb2gray(imgtmp);
        Imtemp= im2bw(tmp,graythresh(tmp));
        Xvalue=[mean(Imtemp(1,1:end)) mean(Imtemp(end,1:end)) mean(Imtemp(1:end,1)) mean(Imtemp(1:end,end))];
        sumori=sum(Xvalue);
        tempX=X;
        if sumori>2.5&&sumori<4
            for j=1:3
                X= Expand(X,Xvalue,0.99,M_ori,N_ori,3);
                imgtmp=imgORI(X(1):X(2),X(3):X(4),:);
                tmp=rgb2gray(imgtmp);
                Imtemp= im2bw(tmp,graythresh(tmp));
                Xvalue=[mean(Imtemp(1,1:end)) mean(Imtemp(end,1:end)) mean(Imtemp(1:end,1)) mean(Imtemp(1:end,end))];
                if sum(Xvalue)>1.1*sumori
                    sumori=sum(Xvalue);
                    tempX=X;
                end
            end
        else if sumori<1.5&&sumori>0
                for j=1:3
                    X= Expand(X,1-Xvalue,0.99,M_ori,N_ori,3);
                    imgtmp=imgORI(X(1):X(2),X(3):X(4),:);
                    tmp=rgb2gray(imgtmp);
                    Imtemp= im2bw(tmp,graythresh(tmp));
                    Xvalue=[mean(Imtemp(1,1:end)) mean(Imtemp(end,1:end)) mean(Imtemp(1:end,1)) mean(Imtemp(1:end,end))];
                    if sum(Xvalue)<0.9*sumori
                        sumori=sum(Xvalue);
                        tempX=X;
                    end
                end
            end
        end
        Reg{ii}.data=[tempX(3) tempX(1) tempX(4)-tempX(3) tempX(2)-tempX(1)];
   end