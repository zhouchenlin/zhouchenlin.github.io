function Reg=PostProcess(imgORI,imgresult,imgtest)

Reg={};
imedge=edge(rgb2gray(imgORI),'canny');
M_ori=size(imgORI,1);
N_ori=size(imgORI,2);
M=size(imgresult,1);
imgBW=imageBW(imgresult);
%         se=strel('disk',5);
%         imtemp=imclose(imgBW,se);
imtemp=imgBW;
box = regionprops(imtemp, 'BoundingBox');
%%%color
boxid=regionprops(imtemp, 'PixelList');
imgtest=double(imgtest);
for idrgb=1:length(boxid)
    boxrgb(idrgb).color=zeros(1,3);
    for idpixel=1:size(boxid(idrgb).PixelList,1)
        tempcolor(1)=imgtest(boxid(idrgb).PixelList(idpixel,2),boxid(idrgb).PixelList(idpixel,1),1);
        tempcolor(2)=imgtest(boxid(idrgb).PixelList(idpixel,2),boxid(idrgb).PixelList(idpixel,1),2);
        tempcolor(3)=imgtest(boxid(idrgb).PixelList(idpixel,2),boxid(idrgb).PixelList(idpixel,1),3);
        boxrgb(idrgb).color=boxrgb(idrgb).color...
            +tempcolor/size(boxid(idrgb).PixelList,1);
    end
end
para_PDE=[0.5 2 50];
myregion=PDE_tangle(imgBW,imgtest,para_PDE);
idd=0;
KKK=M_ori/M;
for ii=1:size(myregion,1);
    X(1)=max(1,KKK*myregion(ii,1));
    X(2)=min(M_ori,KKK*myregion(ii,2));
    X(3)=max(1,KKK*myregion(ii,3));
    X(4)=min(N_ori,KKK*myregion(ii,4));
    ratio=myratio(imedge(X(1):X(2),X(3):X(4)));
    if (X(2)-X(1))*(X(4)-X(3))>M_ori*N_ori/1000
        if (X(4)-X(3))/(X(2)-X(1))>0.75&&ratio>0.3
            idd=idd+1;
            tempX=[X(3) X(1) X(4)-X(3) X(2)-X(1)];
            Reg{idd}.data=tempX;
        end
    end
end
if isempty(Reg)
    for ii=1:size(myregion,1);
        X(1)=max(1,KKK*myregion(ii,1));
        X(2)=min(M_ori,KKK*myregion(ii,2));
        X(3)=max(1,KKK*myregion(ii,3));
        X(4)=min(N_ori,KKK*myregion(ii,4));
        ratio=myratio(imedge(X(1):X(2),X(3):X(4)));
        if (X(2)-X(1))*(X(4)-X(3))>M_ori*N_ori/500
            idd=idd+1;
            tempX=[X(3) X(1) X(4)-X(3) X(2)-X(1)];
            Reg{idd}.data=tempX;
        end
    end
end
if isempty(Reg)
    for ii=1:size(myregion,1);
        X(1)=max(1,KKK*myregion(ii,1));
        X(2)=min(M_ori,KKK*myregion(ii,2));
        X(3)=max(1,KKK*myregion(ii,3));
        X(4)=min(N_ori,KKK*myregion(ii,4));
        ratio=myratio(imedge(X(1):X(2),X(3):X(4)));
        if (X(2)-X(1))*(X(4)-X(3))>100
            idd=idd+1;
            tempX=[X(3) X(1) X(4)-X(3) X(2)-X(1)];
            Reg{idd}.data=tempX;
        end
    end
end

Area=0;
for i=1:length(Reg)
    Area=Area+Reg{i}.data(3)*Reg{i}.data(4);
end
if Area/(M_ori*N_ori)<0.1
    Reg={};
end


temp=0;
for i=1:length(Reg);
    X(1)=Reg{i}.data(2);
    X(2)=Reg{i}.data(2)+Reg{i}.data(4);
    X(3)=Reg{i}.data(1);
    X(4)=Reg{i}.data(1)+Reg{i}.data(3);
    if temp<sum((X(1)<5)+(X(2)>M_ori-3)+(X(3)<5)+(X(4)>N_ori-3))
        temp=sum((X(1)<5)+(X(2)>M_ori-3)+(X(3)<5)+(X(4)>N_ori-3));
    end
end
if temp>1
    Reg={};
end