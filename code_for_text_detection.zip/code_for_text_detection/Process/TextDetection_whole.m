function Region=TextDetection_whole(imgORI,InImage,TTLearners,TTWeights,CCLearners,CCWeights)

M_ori=size(imgORI,1);
N_ori=size(imgORI,2);
disp('ȡ��ͼ')
 myregion{1}.data=[1 1 N_ori-1 M_ori-1];
disp('���໭�򲢷���')
Region={};
cont=0;
[RegionColor,Color]=TangleSecond_Color(imgORI,myregion,InImage,TTLearners,TTWeights,CCLearners,CCWeights);
for i=1:length(RegionColor)
    idC=RegionColor{i}.component;
    if RegionColor{i}.score>0.5&&length(idC)>2&&max(RegionColor{i}.score2)>0.5
        if RegionColor{i}.score>0.75||max(RegionColor{i}.score2)>0.6
            cont=cont+1;
            Region(cont)=RegionColor(i);
            Region{cont}.label='Color';
        end
    end
end
[RegionBW,BW]=TangleSecond_BW(imgORI,myregion,InImage,TTLearners,TTWeights,CCLearners,CCWeights);
for i=1:length(RegionBW)
    idC=RegionBW{i}.component;
    if RegionBW{i}.score>0.5&&length(idC)>2&&max(RegionBW{i}.score2)>0.5
        if RegionBW{i}.score>0.75||max(RegionBW{i}.score2)>0.6
            cont=cont+1;
            Region(cont)=RegionBW(i);
            Region{cont}.label='BW';
        end
    end
end
disp('����ɫ�Ͷ�ֵ���ںϵĽ��ȥ���ظ��Ŀ�')
Region=RemoveRepetition(Region);
disp('ȥ��������')
Region=RemoveChildren(Region);
disp('�ִ�')
Region=Split2Words(Region,BW,Color);
disp('����')
Region=ExpandReg(imgORI,Region);
disp('�˵�һЩ����')
if ~isempty(Region)
    Region=RemoveWrong(imgORI,Region);
end