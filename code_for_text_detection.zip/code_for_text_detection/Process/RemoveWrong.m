function Region=RemoveWrong(imgORI,Region)

    M_ori=size(imgORI,1);
    N_ori=size(imgORI,2);
    Reg=Region;
    if isfield(Reg{1},'score')
        for i=1:length(Reg)
            if max(Reg{i}.score2)<0.7&&Reg{i}.similar>0.6
                Reg{i}.score=0;
            end
            idC=Reg{i}.component;
            Ratio=Reg{i}.data(3)/Reg{i}.data(4);
            if (length(idC)==1)||(Ratio<1.4&&length(idC)>=3)||...
                    (length(idC)==2&&min(Reg{i}.score2)<0.5)||(Ratio/length(idC)>3.5)
                Reg{i}.score=0;
            end
            height=min(Reg{i}.data(2)-1,M_ori-Reg{i}.data(2)-Reg{i}.data(4));
            if height<5&&Reg{i}.data(4)/M_ori<0.05
                Reg{i}.score=0;
            end
        end
    end
    cont=0;
    Region={};
    for i=1:length(Reg)
        if Reg{i}.score>0.2
            cont=cont+1;
            Region(cont)=Reg(i);
        end
    end