function myregion=split_region(region,I)

for i=1:length(region)
    yvalue(i,1)=region{i}.BoundingBox(2);
    yvalue(i,2)=region{i}.BoundingBox(2)+region{i}.BoundingBox(4);
    yvalue(i,3)=region{i}.BoundingBox(1);
    yvalue(i,4)=region{i}.BoundingBox(1)+region{i}.BoundingBox(3);
end

[~,id]=sort(yvalue(:,3));
[~,id1]=sort(yvalue(:,4));


if length(region)>5
    y=[];
    for j=1:length(region)-1
        y(j)=yvalue(id(j+1),3)-yvalue(id1(j),4);
    end
    y1=sort(y);
    y2=y1(find(y1>=0));
    if length(y2)>1
        yyy=y2(max(1,round(2/3*length(y2))));
    else
        yyy=1;
    end
    xxx=min(yvalue(:,2)-yvalue(:,1));
    if length(y)<25
        peak=find(y>max([10,xxx/15,(3.5-min(20,length(y))/10)*yyy]));
    else
        peak=find(y>max([xxx/15,(3.5-min(20,length(y))/10)*yyy]));
    end
    
    if isempty(peak)&&y1(end)>=2*y1(end-1)&&y1(end)>6
        peak=find(y==y1(end));
    end
    
    if length(peak)>5&&length(y)<25
        peak=find(y>4*yyy);
    end
    if length(y)>14&&isempty(peak)
        peak=find(y>2*yyy);
        if length(peak)>3
            peak=find(y>3*yyy);
        end
    end
    if length(y)>8&&length(y)<15&&isempty(peak)
        peak=find(y>1.5*yyy);
        if length(peak)>2
            peak=find(y>2.5*yyy);
        end
    end
%     if length(y)>8&&length(y)<15&&isempty(peak)
%         peak=find(y>1.5*yyy);
%         if length(peak)>2
%             peak=find(y>2.5*yyy);
%         end
%     end
else
    peak=[];
    for j=1:length(region)-1
        R1=region{id(j)}.BoundingBox(3)/region{id(j)}.BoundingBox(4);
        R2=region{id(j+1)}.BoundingBox(3)/region{id(j+1)}.BoundingBox(4);
        y(j)=yvalue(id(j+1),3)-yvalue(id(j),4);
        %  if (R1>3||R2>3)&&y(j)<min(region{j}.BoundingBox(4),region{j+1}.BoundingBox(4))/min(R1,R2)
        if (R1>2.5||R2>2.5)&&y(j)>5
            peak=[peak j];
        end
    end
end
if isempty(peak)
    split=[0 length(region)];
else
    split=[0 peak length(region)];
end
cont=0;
myregion={};
for i=1:length(split)-1
    cont=cont+1;
    %  myregion{cont}.data=[min(yvalue(id(split(i)+1:split(i+1)),1)) max(yvalue(id(split(i)+1:split(i+1)),2)) min(yvalue(id(split(i)+1:split(i+1)),3)) max(yvalue(id(split(i)+1:split(i+1)),4))];
    myregion{cont}.data=[min(yvalue(id(split(i)+1:split(i+1)),3))...
        min(yvalue(id(split(i)+1:split(i+1)),1))...
        max(yvalue(id(split(i)+1:split(i+1)),4))-min(yvalue(id(split(i)+1:split(i+1)),3))...
        max(yvalue(id(split(i)+1:split(i+1)),2))-min(yvalue(id(split(i)+1:split(i+1)),1))];
    myregion{cont}.component=id(split(i)+1:split(i+1));
    myregion{cont}.parent=I;
end