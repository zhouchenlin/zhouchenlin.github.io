function [Region,scale]=TextDetection_Test(imgORI,InImage,a,b,TTLearners,TTWeights,CCLearners,CCWeights)

M_ori=size(imgORI,1);
N_ori=size(imgORI,2);
% disp('����PDE���')
 [imgresult,imgtest]=solvePDE(imgORI,a,b);
 figure;imshow(imgresult);
%%%ԭ���ָ�ͻ���ĳ���
 imgBW=imageBW_ORI(imgresult);
 figure;imshow(imgBW);
 para_PDE=[0.5 2 50];
 myregion=PDE_tangle(imgBW,imgtest,para_PDE);
 disp('ԭʼͼ��Ŀ�')
scale=1;
if max(M_ori,N_ori)>3500
    scale=0.25;
    M_ori=round(scale*M_ori);
    N_ori=round(scale*N_ori);
    imgORI=imresize(imgORI,[M_ori N_ori]);
else if max(M_ori,N_ori)>1800
        scale=0.5;
        M_ori=round(scale*M_ori);
        N_ori=round(scale*N_ori);
        imgORI=imresize(imgORI,[M_ori N_ori]);
    end
end
 myregion=ORI_tangle(imgORI,imgresult,myregion);

    figure;imshow(imgORI);hold on
    for i=1:length(myregion)
        X1=myregion{i}.data(2);
        X2=myregion{i}.data(2)+myregion{i}.data(4);
        Y1=myregion{i}.data(1);
        Y2=myregion{i}.data(1)+myregion{i}.data(3);
        YY2=[X1 X1 X2 X2 X1];
        XX2=[Y1 Y2 Y2 Y1 Y1];
        plot(XX2, YY2, 'g-');
        hold on, text(Y1, X1, num2str(i), 'EdgeColor','blue');
    end
 
disp('���໭�򲢷���')
Region={};
cont=0;
%[RegionColor,Color]=TangleSecond_Color(imgORI,myregion,InImage,TTLearners,TTWeights,CCLearners,CCWeights);

load(['.\data\cluster\Color\'...
    InImage(1:end-4) '.mat']);
Color=RegionCC;
load(['.\data\retangle\Color\'...
    InImage(1:end-4) '.mat']);
RegionColor=Newregion;
   figure('Visible','off');subplot(2,2,1); imshow(imgORI);hold on
   figure;subplot(2,2,1);imshow(imgORI);hold on
    for i=1:length(Color)
        X1=Color{i}.BoundingBox(2);
        X2=Color{i}.BoundingBox(2)+Color{i}.BoundingBox(4);
        Y1=Color{i}.BoundingBox(1);
        Y2=Color{i}.BoundingBox(1)+Color{i}.BoundingBox(3);
        YY2=[X1 X1 X2 X2 X1];
        XX2=[Y1 Y2 Y2 Y1 Y1];
        if Color{i}.score<0.5
            plot(XX2, YY2, 'r-');
        else if Color{i}.score<0.75
                plot(XX2, YY2, 'y-');
            else
                plot(XX2, YY2, 'g-');
            end
        end 
    end
   subplot(2,2,2);imshow(imgORI);hold on
    for i=1:length(RegionColor)
        X1=RegionColor{i}.data(2);
        X2=RegionColor{i}.data(2)+RegionColor{i}.data(4);
        Y1=RegionColor{i}.data(1);
        Y2=RegionColor{i}.data(1)+RegionColor{i}.data(3);
        YY2=[X1 X1 X2 X2 X1];
        XX2=[Y1 Y2 Y2 Y1 Y1];
        if RegionColor{i}.score1<0.5
            plot(XX2, YY2, 'r-');
            hold on, text(Y1, X1, num2str(i), 'EdgeColor','blue');
        else if RegionColor{i}.score1<0.75
                plot(XX2, YY2, 'y-');
                hold on, text(Y1, X1, num2str(i), 'EdgeColor','blue');
            else
                plot(XX2, YY2, 'g-');
                hold on, text(Y1, X1, num2str(i), 'EdgeColor','blue');
            end
        end            
    end

for i=1:length(RegionColor)
    idC=RegionColor{i}.component;
    if RegionColor{i}.score1>0.75&&RegionColor{i}.score1+max(RegionColor{i}.score2)>1.27||...
            (mean(RegionColor{i}.score2)>0.75)&&length(idC)>2
        cont=cont+1;
        Region(cont)=RegionColor(i);
        Region{cont}.label='Color';
      else if RegionColor{i}.score1>0.5&&max(RegionColor{i}.score2)>0.75
            cont=cont+1;
            Region(cont)=RegionColor(i);
            Region{cont}.label='Color';
        end
    end
end


%[RegionBW,BW]=TangleSecond_BW(imgORI,myregion,InImage,TTLearners,TTWeights,CCLearners,CCWeights);
load(['.\data\cluster\BW\'...
    InImage(1:end-4) '.mat']);
BW=RegionCC;
load(['.\data\retangle\BW\'...
    InImage(1:end-4) '.mat']);
RegionBW=Newregion;
subplot(2,2,3);imshow(imgORI);hold on
    for i=1:length(BW)
        X1=BW{i}.BoundingBox(2);
        X2=BW{i}.BoundingBox(2)+BW{i}.BoundingBox(4);
        Y1=BW{i}.BoundingBox(1);
        Y2=BW{i}.BoundingBox(1)+BW{i}.BoundingBox(3);
        YY2=[X1 X1 X2 X2 X1];
        XX2=[Y1 Y2 Y2 Y1 Y1];
        if BW{i}.score<0.5
            plot(XX2, YY2, 'r-');
        else if BW{i}.score<0.75
                plot(XX2, YY2, 'y-');
            else
                plot(XX2, YY2, 'g-');
            end
        end 
    end
   subplot(2,2,4);imshow(imgORI);hold on
    for i=1:length(RegionBW)
        X1=RegionBW{i}.data(2);
        X2=RegionBW{i}.data(2)+RegionBW{i}.data(4);
        Y1=RegionBW{i}.data(1);
        Y2=RegionBW{i}.data(1)+RegionBW{i}.data(3);
        YY2=[X1 X1 X2 X2 X1];
        XX2=[Y1 Y2 Y2 Y1 Y1];
        if RegionBW{i}.score1<0.5
            plot(XX2, YY2, 'r-');
            hold on, text(Y1, X1, num2str(i), 'EdgeColor','blue');
        else if RegionBW{i}.score1<0.75
                plot(XX2, YY2, 'y-');
                hold on, text(Y1, X1, num2str(i), 'EdgeColor','blue');
            else
                plot(XX2, YY2, 'g-');
                hold on, text(Y1, X1, num2str(i), 'EdgeColor','blue');
            end
        end            
    end
    tempresult_path = ['.\data\ColorBW\'...
        InImage(1:end-4)  '.jpg'];
    saveas(gcf,tempresult_path,'jpg');
    
for i=1:length(RegionBW)
    idC=RegionBW{i}.component;
    if (RegionBW{i}.score1>0.75&&RegionBW{i}.score1+max(RegionBW{i}.score2)>1.27)||...
            (mean(RegionBW{i}.score2)>0.75)&&length(idC)>2
        cont=cont+1;
        Region(cont)=RegionBW(i);
        Region{cont}.label='BW';
    else if RegionBW{i}.score1>0.5&&max(RegionBW{i}.score2)>0.75
            cont=cont+1;
            Region(cont)=RegionBW(i);
            Region{cont}.label='BW';
        end
    end
end
% % %figure('Visible','off');subplot(2,2,1); imshow(imgORI);title('Color');hold on
% figure;subplot(1,2,1);imshow(imgORI);hold on
% for i=1:length(Region)
%     X1=Region{i}.data(2);
%     X2=Region{i}.data(2)+Region{i}.data(4);
%     Y1=Region{i}.data(1);
%     Y2=Region{i}.data(1)+Region{i}.data(3);
%     YY2=[X1 X1 X2 X2 X1];
%     XX2=[Y1 Y2 Y2 Y1 Y1];
%     if Region{i}.score<0.5
%         plot(XX2, YY2, 'r-');
%         hold on, text(Y1, X1, num2str(i));
%     else if Region{i}.score<0.75
%             plot(XX2, YY2, 'y-');
%             hold on, text(Y1, X1, num2str(i));
%         else
%             plot(XX2, YY2, 'g-');
%             hold on, text(Y1, X1, num2str(i));
%         end
%     end
% end

disp('����ɫ�Ͷ�ֵ���ںϵĽ��ȥ���ظ��Ŀ�')
Region=RemoveRepetition(Region);
% subplot(1,2,2);imshow(imgORI);hold on
% for i=1:length(Region)
%     X1=Region{i}.data(2);
%     X2=Region{i}.data(2)+Region{i}.data(4);
%     Y1=Region{i}.data(1);
%     Y2=Region{i}.data(1)+Region{i}.data(3);
%     YY2=[X1 X1 X2 X2 X1];
%     XX2=[Y1 Y2 Y2 Y1 Y1];
%     if Region{i}.score<0.5
%         plot(XX2, YY2, 'r-');
%         hold on, text(Y1, X1, num2str(i));
%     else if Region{i}.score<0.75
%             plot(XX2, YY2, 'y-');
%             hold on, text(Y1, X1, num2str(i));
%         else
%             plot(XX2, YY2, 'g-');
%             hold on, text(Y1, X1, num2str(i));
%         end
%     end
% end
disp('ȥ��������')
Region=RemoveChildren(Region);
% subplot(1,2,2);imshow(imgORI);hold on
% for i=1:length(Region)
%     X1=Region{i}.data(2);
%     X2=Region{i}.data(2)+Region{i}.data(4);
%     Y1=Region{i}.data(1);
%     Y2=Region{i}.data(1)+Region{i}.data(3);
%     YY2=[X1 X1 X2 X2 X1];
%     XX2=[Y1 Y2 Y2 Y1 Y1];
%     if Region{i}.score<0.5
%         plot(XX2, YY2, 'r-');
%         hold on, text(Y1, X1, num2str(i));
%     else if Region{i}.score<0.75
%             plot(XX2, YY2, 'y-');
%             hold on, text(Y1, X1, num2str(i));
%         else
%             plot(XX2, YY2, 'g-');
%             hold on, text(Y1, X1, num2str(i));
%         end
%     end
% end
disp('�ִ�')
Region=Split2Words(Region,BW,Color);
% subplot(1,2,2);imshow(imgORI);hold on
% for i=1:length(Region)
%     X1=Region{i}.data(2);
%     X2=Region{i}.data(2)+Region{i}.data(4);
%     Y1=Region{i}.data(1);
%     Y2=Region{i}.data(1)+Region{i}.data(3);
%     YY2=[X1 X1 X2 X2 X1];
%     XX2=[Y1 Y2 Y2 Y1 Y1];
%     if Region{i}.score<0.5
%         plot(XX2, YY2, 'r-');
%         hold on, text(Y1, X1, num2str(i));
%     else if Region{i}.score<0.75
%             plot(XX2, YY2, 'y-');
%             hold on, text(Y1, X1, num2str(i));
%         else
%             plot(XX2, YY2, 'g-');
%             hold on, text(Y1, X1, num2str(i));
%         end
%     end
% end
%Region=RemoveRepetition(Region);
% disp('����')
%  Region=ExpandReg(imgORI,Region);
% if ~isempty(Region)
%     Region=RemoveWrong(imgORI,Region);
% end


% if  isempty(Region)
%     disp('����ͼ�ϻ���')
%     Region=TextDetection_whole(imgORI,InImage,TTLearners,TTWeights,CCLearners,CCWeights);
% end
% if  isempty(Region)
%     disp('����PDE���')
%     [imgresult,imgtest]=solvePDE(imgORI,a,b);
%     disp('����PDE�Ľ��ֱ�ӻ���')
%     Region=PostProcess(imgORI,imgresult,imgtest);
% end

% if  isempty(Region)
%     cont=0;
%     for i=1:length(RegionColor)
%         if RegionColor{i}.score>0.5
%             cont=cont+1;
%             Region(cont)=RegionColor(i);
%             Region{cont}.label='Color';
%         end
%     end
%     for i=1:length(RegionBW)
%         if RegionBW{i}.score>0.5
%             cont=cont+1;
%             Region(cont)=RegionBW(i);
%             Region{cont}.label='BW';
%         end
%     end
% end
close all