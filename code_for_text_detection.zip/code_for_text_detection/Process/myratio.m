function ratio=myratio(imed)
[m,n,~]=size(imed);
if max(m,n)<30
    ratio=0;
    return;
end
% %tempgray=rgb2gray(img);
% addpath('D:\data\text\MRSA\MSRA-TD500\MSRA-TD500\data_TEXT\CombineAndSplit\ColorFeatures\ColorFeatures\');
% sigma1=2;                                   % standard deviation gaussian derivative kernel
% sigma2=2;                                   % standard deviation gaussian averaging kernel
% edgeT=3;                                    % threshold on which edges to display
% [out3]=color_canny(img, sigma1, sigma2, 0);
% out3(out3>edgeT)=255;
%imed=im2bw(uint8(imed));
%imed=edge(tempgray,'canny');
%imed=edge(tempgray,'sobel');
% imed=imgedge(X1:X2,Y1:Y2,:);
se = strel('disk',1);
imedtemp=imclose(imed,se);
count = sum(sum(double(imedtemp)));
if count==0
    ratio=0;
    return;
end
for j=1:5
    imed=bwmorph(imed,'skel',Inf);
end
se = strel('disk',1);
imed=imclose(imed,se);
box=regionprops(imed,'PixelList');
con=0; imch=zeros(m,n);
for u=1:length(box)
    ll=box(u).PixelList;
    x1=ll(:,1);y1=ll(:,2);
    if size(ll,1)>30
        cov=corrcoef(x1,y1);
        if abs(cov(1,2))<0.9||size(ll,1)<50
            con=con+size(ll,1);
        end
    end
end
ratio=con/count;
end

