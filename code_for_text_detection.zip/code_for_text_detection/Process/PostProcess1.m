
clear all
close all
clc
warning('off');
%%��ȡ
AA = dir('.\data\badcase\*.jpg');
InImage={};
for i=1:length(AA)
    InImage(i).name=AA(i).name;
end
 InImage=struct2cell(InImage); 
 addpath('.\natsort\');
[InImage,B,C]=natsort(InImage,'\d+','afterchar');
    disp('��ȡPDE��ϵ��')	
    load( '.\coef\20110118100\a.mat');
    load( '.\coef\20110118100\b.mat');
    for s=9:length(InImage)
        s
        disp('��ȡͼ��')
        imgori_path=['.\data\ORI\' InImage{s}];
        imgORI=imread(imgori_path);
        M_ori=size(imgORI,1);
        N_ori=size(imgORI,2);
        tic
        [imgresult,imgtest]=solvePDE(imgORI,a,b);
        toc
        imedge=edge(rgb2gray(imgORI),'canny');
        M=size(imgresult,1);
        N=size(imgresult,2);
        h=fspecial('average',[3 3]);
        imgresult=imfilter(imgresult,h);
        imgresult=padarray(imgresult(6:M-5,6:N-5),[5,5],'replicate');
        imgBW=im2bw(imgresult,graythresh(imgresult));
        se = strel('rectangle',[2 2]);
        imgBW = imclose(imgBW,se);
        se = strel('rectangle',[2 2]);
        imgBW = imopen(imgBW,se);
        imtemp=imgBW;
        box = regionprops(imtemp, 'BoundingBox');
        %%%color
        boxid=regionprops(imtemp, 'PixelList');
        imgtest=double(imgtest);
        for idrgb=1:length(boxid)
            boxrgb(idrgb).color=zeros(1,3);
            for idpixel=1:size(boxid(idrgb).PixelList,1)
                tempcolor(1)=imgtest(boxid(idrgb).PixelList(idpixel,2),boxid(idrgb).PixelList(idpixel,1),1);
                tempcolor(2)=imgtest(boxid(idrgb).PixelList(idpixel,2),boxid(idrgb).PixelList(idpixel,1),2);
                tempcolor(3)=imgtest(boxid(idrgb).PixelList(idpixel,2),boxid(idrgb).PixelList(idpixel,1),3);
                boxrgb(idrgb).color=boxrgb(idrgb).color...
                    +tempcolor/size(boxid(idrgb).PixelList,1);
            end
        end
        
        para_PDE=[0.25 1 50];
        myregion=PDE_tangle(imgBW,imgtest,para_PDE);
        figure;subplot(1,2,1);imshow(imgBW);hold on
        subplot(1,2,2);imshow(imgORI);hold on
        Reg={};
        idd=0;
        KKK=M_ori/M;
       
        for ii=1:size(myregion,1);
            X(1)=max(1,KKK*myregion(ii,1));
            X(2)=min(M_ori,KKK*myregion(ii,2));
            X(3)=max(1,KKK*myregion(ii,3));
            X(4)=min(N_ori,KKK*myregion(ii,4));
            ratio=myratio(imedge(X(1):X(2),X(3):X(4)));
            YY2=[X(1) X(1) X(2) X(2) X(1)];
            XX2=[X(3) X(4) X(4) X(3) X(3)];
            if (X(2)-X(1))*(X(4)-X(3))>M_ori*N_ori/1000
                if (X(4)-X(3))/(X(2)-X(1))>0.75&&ratio>0.3
                    plot(XX2, YY2, 'g-');
                    hold on, text(XX2(1), YY2(1), num2str(ratio), 'EdgeColor','blue');
                    idd=idd+1;
                    tempX=[X(3) X(1) X(4)-X(3) X(2)-X(1)];
                    Reg{idd}.data=tempX;
                end
            end
        end
          tempresult_path = ['.\data\temp\' InImage{s}];
          saveas(gcf,tempresult_path,'jpg');
       close all 
        if isempty(Reg)
            for ii=1:size(myregion,1);
                X(1)=max(1,KKK*myregion(ii,1));
                X(2)=min(M_ori,KKK*myregion(ii,2));
                X(3)=max(1,KKK*myregion(ii,3));
                X(4)=min(N_ori,KKK*myregion(ii,4));
                ratio=myratio(imedge(X(1):X(2),X(3):X(4)));
                if (X(2)-X(1))*(X(4)-X(3))>M_ori*N_ori/500
                    idd=idd+1;
                    tempX=[X(3) X(1) X(4)-X(3) X(2)-X(1)];
                    Reg{idd}.data=tempX;
                end
            end
        end
        if isempty(Reg)
            for ii=1:size(myregion,1);
                X(1)=max(1,KKK*myregion(ii,1));
                X(2)=min(M_ori,KKK*myregion(ii,2));
                X(3)=max(1,KKK*myregion(ii,3));
                X(4)=min(N_ori,KKK*myregion(ii,4));
                ratio=myratio(imedge(X(1):X(2),X(3):X(4)));
                if (X(2)-X(1))*(X(4)-X(3))>100
                    idd=idd+1;
                    tempX=[X(3) X(1) X(4)-X(3) X(2)-X(1)];
                    Reg{idd}.data=tempX;
                end
            end
        end

      
         temp=0;
        for i=1:length(Reg);
            X(1)=Reg{i}.data(2);
            X(2)=Reg{i}.data(2)+Reg{i}.data(4);
            X(3)=Reg{i}.data(1);
            X(4)=Reg{i}.data(1)+Reg{i}.data(3);
            if temp<sum((X(1)<5)+(X(2)>M_ori-3)+(X(3)<5)+(X(4)>N_ori-3))
                temp=sum((X(1)<5)+(X(2)>M_ori-3)+(X(3)<5)+(X(4)>N_ori-3));
            end
        end
        if temp>1
            Reg={};
        end
        
        figure('Visible','off');imshow(imgORI);hold on
        for i=1:length(Reg)
            YY2=[Reg{i}.data(2) Reg{i}.data(2) Reg{i}.data(2)+Reg{i}.data(4)...
                Reg{i}.data(2)+Reg{i}.data(4) Reg{i}.data(2)];
            XX2=[Reg{i}.data(1) Reg{i}.data(1)+Reg{i}.data(3) Reg{i}.data(1)+Reg{i}.data(3)...
                Reg{i}.data(1) Reg{i}.data(1)];
            plot(XX2, YY2, 'g-');
            hold on, text(XX2(1), YY2(1), num2str(i), 'EdgeColor','blue');
        end  
          tempresult_path = ['.\data\temp\1' InImage{s}];
          saveas(gcf,tempresult_path,'jpg');
    end