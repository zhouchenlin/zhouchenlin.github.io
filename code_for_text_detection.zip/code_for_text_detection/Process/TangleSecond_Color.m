function [Newregion,RegionCC]=TangleSecond_Color(imgORI,myregion,InImage,MLearners,MWeights,CCLearners,CCWeights)
warning('off');
M_ori=size(imgORI,1);
N_ori=size(imgORI,2);
RegionCC={};%%%
RegionTangle={};
for i=1:length(myregion)
    A0=length(RegionCC);
    X(1)=max(1,myregion{i}.data(2));
    X(2)=min(M_ori,myregion{i}.data(2)+myregion{i}.data(4));
    X(3)=max(1,myregion{i}.data(1));
    X(4)=min(N_ori,myregion{i}.data(1)+myregion{i}.data(3));
    I_rgb=imgORI(X(1):X(2),X(3):X(4),:);
    [RegionCCTemp,RegionTangleTemp]=Color_cluster(I_rgb,X,CCLearners,CCWeights,A0);
    RegionCC=[RegionCC RegionCCTemp];
    RegionTangle=[RegionTangle RegionTangleTemp];
end
cont=0;
Newregion={};
for k=1:length(RegionTangle)
    X(1)=max(1,RegionTangle{k}.data(2));
    X(2)=min(M_ori,RegionTangle{k}.data(2)+RegionTangle{k}.data(4));
    X(3)=max(1,RegionTangle{k}.data(1));
    X(4)=min(N_ori,RegionTangle{k}.data(1)+RegionTangle{k}.data(3));
    if  (X(1)-X(2))*(X(3)-X(4))>100&&(X(2)-X(1))>5&&(X(4)-X(3))>10&&(X(2)-X(1))/(X(4)-X(3))<1
        cont=cont+1;
        Newregion{cont}.img=imgORI(X(1):X(2),X(3):X(4),:);
        Newregion{cont}.data=[X(3),X(1),X(4)-X(3),X(2)-X(1)];
        Newregion{cont}.component=RegionTangle{k}.component;
    end
end
%%%��ȡ����
Newregion=geneallfeature(Newregion,RegionCC,imgORI);
%%%����
weak_learner = tree_node_w(8);
for i=1:length(Newregion)
    testData= Newregion{i}.feature';
    testData(find(isnan(testData)==1)) = 0;
    P=Classify(MLearners, MWeights, testData');
    P1=exp(P);
    Newregion{i}.score1=P1./(P1+ones(1,length(P1)));
    idC=Newregion{i}.component;
    Score2=zeros(length(idC),1);
    for j=1:length(idC)
        Score2(j)=RegionCC{idC(j)}.score;
    end
    Newregion{i}.score2=Score2;
    Newregion{i}.score=(mean(Newregion{i}.score2)+ 2*Newregion{i}.score1)/3;
end
    
   