function imgBW=imageBW(imgresult)
%%��𷨶�ֵ�� 
%%���룺imgresult�������imgBW
M=size(imgresult,1);
N=size(imgresult,2);
h=fspecial('average',[3 3]);
imgresult=imfilter(imgresult,h);
imgresult=padarray(imgresult(6:M-5,6:N-5),[5,5],'replicate');
imgBW=im2bw(imgresult,graythresh(imgresult));
se = strel('rectangle',[2 2]);
imgBW = imclose(imgBW,se);
se = strel('rectangle',[2 2]);
imgBW = imopen(imgBW,se);