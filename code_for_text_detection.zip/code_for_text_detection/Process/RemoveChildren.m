function Reg=RemoveChildren(Reg)


for i=1:length(Reg)
    XF=Reg{i}.data;
    Children=[];
    for j=1:length(Reg)
        XC=Reg{j}.data;
        if j~=i&&XC(1)>=XF(1)-5&&XC(2)>=XF(2)-5&&XC(1)+XC(3)<=XF(1)+XF(3)+5&&XC(2)+XC(4)<=XF(2)+XF(4)+5
            Children=[Children;j];
        end
    end
    Reg{i}.Children=Children;
    Reg{i}.Area=XF(4)*XF(3);
end

for i=1:length(Reg)
    if isempty(Reg{i}.Children)==0
        id=Reg{i}.Children;
        AA=0;
        Score=0;
        for j=1:length(id)
            AA=AA+Reg{id(j)}.Area;
            Score=Score+Reg{id(j)}.Area*Reg{i}.score;
        end
        if AA/Reg{i}.Area>0.7;
            if Score/AA>Reg{i}.score
                Reg{i}.score1=0;
            else
                for j=1:length(id)
                    Reg{id(j)}.score1=0;
                end
            end
        end
    end
end

for i=1:length(Reg)
    if isempty(Reg{i}.Children)==0
        if length(id)>2
            id=Reg{i}.Children;
            XF=Reg{i}.data;
            for j=1:length(id)
                XC(j,:)=Reg{id(j)}.data;
                if XC(j,4)/XF(4)>1/2
                    break;
                end
            end
            temp=max(XC(:,2)+XC(:,4))-min(XC(:,2));
            if temp/XF(4)>0.5
                Reg{i}.score1=0;
            end 
        end
    end
end




for i=1:length(Reg)
    XF=Reg{i}.data;
    if XF(3)/XF(4)<1.3&&Reg{i}.score1<0.75
        Reg{i}.score1=0;
    end
end

Region={};
ii=0;
for i=1:length(Reg)
    if Reg{i}.score1>0.2
        ii=ii+1;
        Region(ii)=Reg(i);
    end
end

Reg={};
cont=0;
if length(Region)>8
    for i=1:length(Region)
        if Region{i}.score>0.7
            cont=cont+1;
            Reg(cont)=Region(i);
        end
    end
else
    Reg=Region;
end