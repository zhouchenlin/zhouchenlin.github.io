function [Region,scale]=TextDetection(imgORI,InImage,a,b,TTLearners,TTWeights,CCLearners,CCWeights)

M_ori=size(imgORI,1);
N_ori=size(imgORI,2);
  disp('Solve PDEs...')
 [imgresult,imgtest]=solvePDE(imgORI,a,b);
imgBW=imageBW_ORI(imgresult);
 para_PDE=[0.5 2 50];
% myregion=PDE_tangle_ORI(imgresult,imgBW,imgtest,para_PDE);
 myregion=PDE_tangle(imgBW,imgtest,para_PDE);
scale=1;
if max(M_ori,N_ori)>3500
    scale=0.25;
    M_ori=round(scale*M_ori);
    N_ori=round(scale*N_ori);
    imgORI=imresize(imgORI,[M_ori N_ori]);
else if max(M_ori,N_ori)>1800
        scale=0.5;
        M_ori=round(scale*M_ori);
        N_ori=round(scale*N_ori);
        imgORI=imresize(imgORI,[M_ori N_ori]);
    end
end
 myregion=ORI_tangle(imgORI,imgresult,myregion);

disp('cluster and classification...')
Region={};
cont=0;
[RegionColor,Color]=TangleSecond_Color(imgORI,myregion,InImage,TTLearners,TTWeights,CCLearners,CCWeights);
for i=1:length(RegionColor)
   % idC=RegionColor{i}.component;
    if RegionColor{i}.score1>0.75&&RegionColor{i}.score1+max(RegionColor{i}.score2)>1.25
        cont=cont+1;
        Region(cont)=RegionColor(i);
        Region{cont}.label='Color';
      else if RegionColor{i}.score1>0.5&&max(RegionColor{i}.score2)>0.75
            cont=cont+1;
            Region(cont)=RegionColor(i);
            Region{cont}.label='Color';
        end
    end
end
[RegionBW,BW]=TangleSecond_BW(imgORI,myregion,InImage,TTLearners,TTWeights,CCLearners,CCWeights);
for i=1:length(RegionBW)
  %  idC=RegionBW{i}.component;
    if RegionBW{i}.score1>0.75&&RegionBW{i}.score1+max(RegionBW{i}.score2)>1.25
        cont=cont+1;
        Region(cont)=RegionBW(i);
        Region{cont}.label='BW';
    else if RegionBW{i}.score1>0.5&&max(RegionBW{i}.score2)>0.75
            cont=cont+1;
            Region(cont)=RegionBW(i);
            Region{cont}.label='BW';
        end
    end
end
disp('Remove repetition...')
Region=RemoveRepetition(Region);
Region=RemoveChildren(Region);
disp('Split words...')
Region=Split2Words(Region,BW,Color);
% disp('����')
% Region=ExpandReg(imgORI,Region);
disp('Remove some false...')
if ~isempty(Region)
    Region=RemoveWrong(imgORI,Region);
end
if  isempty(Region)
    Region=TextDetection_whole(imgORI,InImage,TTLearners,TTWeights,CCLearners,CCWeights);
end
if  isempty(Region)
    Region=PostProcess(imgORI,imgresult,imgtest);
end