function Reg=Split2Words(Region,BW,Color)
cont=0;
Reg={};
for i=1:length(Region)
    X=Region{i}.data;
    idC=Region{i}.component;
    idT=setdiff(min(idC):max(idC),idC);
    BCtemp=Region{i}.label;
    if strcmp(BCtemp,'BW')
        if ~isempty(idT)
            for j=1:length(idT)
                if BW{idT(j)}.score>0.3
                    C=CCDistance(BW(idT(j)),BW(idC(end)));
                    if C>0
                        idC=[idC;idT(j)];
                    end
                end
            end
        end
        Region{i}.similar=eliminatesimilar(BW(idC));
        if Region{i}.similar<0.8
            regiontemp=split_region(BW(idC),i);
            for k=1:length(regiontemp)
                Xtemp=regiontemp{k}.data;
                if  (Xtemp(3)*Xtemp(4))>100&&Xtemp(4)>5&&Xtemp(3)>10
                    cont=cont+1;
                    Reg(cont)=Region(i);
                    Reg{cont}.data=regiontemp{k}.data;
                    Com=regiontemp{k}.component;
                    Reg{cont}.component=idC(Com);
                    Score=zeros(length(Com),1);
                    for jj=1:length(Com)
                        Score(jj)=BW{idC(Com(jj))}.score;
                    end
                    Reg{cont}.score2=Score;
                    Reg{cont}.score=(2*Reg{cont}.score1+mean(Reg{cont}.score2))/3;
                end
            end
        end
    else
        if ~isempty(idT)
            for j=1:length(idT)
                if Color{idT(j)}.score>0.3
                    C=CCDistance(Color(idT(j)),Color(idC(end)));
                    if C>0
                        idC=[idC;idT(j)];
                    end
                end
            end
        end
        Region{i}.similar=eliminatesimilar(Color(idC));
        if Region{i}.similar<0.8
            regiontemp=split_region(Color(idC),i);
            for k=1:length(regiontemp)
                Xtemp=regiontemp{k}.data;
                if  (Xtemp(3)*Xtemp(4))>100&&Xtemp(4)>5&&Xtemp(3)>10
                    cont=cont+1;
                    Reg(cont)=Region(i);
                    Reg{cont}.data=regiontemp{k}.data;
                    Com=regiontemp{k}.component;
                    Reg{cont}.component=idC(Com);
                    Score=zeros(length(Com),1);
                    for jj=1:length(Com)
                        Score(jj)=Color{idC(Com(jj))}.score;
                    end
                    Reg{cont}.score2=Score;
                    Reg{cont}.score=(2*Reg{cont}.score1+mean(Score))/3;
                end
            end
        end
    end
end

%     cont=0;
%     Region=Reg;
%     Reg={};
%     if ~isempty(Region)
%         for i=1:length(Region)
%             if Region{i}.score2+1-Region{i}.similar>1
%                 cont=cont+1;
%                 Reg(cont)=Region(i);
%             end
%         end
%     end

%     cont=0;
%     Region=Reg;
%     Reg={};
%     if ~isempty(Region)
%         if isfield(Region{1},'label')
%             for i=1:length(Region)
%                 idC=Region{i}.component;
%                 BCtemp=Region{i}.label;
%                 if strcmp(BCtemp,'BW')
%                     similar=eliminatesimilar(BW(idC));
%                     if similar<0.8
%                         cont=cont+1;
%                         Reg(cont)=Region(i);
%                         Reg{cont}.similar=similar;
%                     end
%                 else if strcmp(BCtemp,'Color')
%                         similar=eliminatesimilar(Color(idC));
%                         if similar<0.8
%                             cont=cont+1;
%                             Reg(cont)=Region(i);
%                             Reg{cont}.similar=similar;
%                         end 
%                     else
%                         cont=cont+1;
%                         Reg(cont)=Region(i);
%                     end
%                 end
%             end
%         else
%             Reg=Region;
%         end
%     end