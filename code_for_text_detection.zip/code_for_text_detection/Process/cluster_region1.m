function myregion=cluster_region1(region,a)

for i=1:length(region)
    y(i,1)=region{i}.BoundingBox(1);
    y(i,2)=region{i}.BoundingBox(2);
    y(i,3)=region{i}.BoundingBox(3);
    y(i,4)=region{i}.BoundingBox(4);
end


C=zeros(length(region),length(region));
for i=1:length(region)
    C(i,i)=1;
    for j=i+1:length(region)
        XX=min(abs(y(i,1)-y(j,1)-y(j,3)),abs(y(j,1)-y(i,1)-y(i,3)))/max(y(i,3),y(j,3));
        YY=min(abs(y(i,2)-y(j,2)),abs(y(i,2)+y(i,4)-y(j,2)-y(j,4)));
        %temp1=sqrt(XX^2+YY^2);
        T1=min(region{i}.BoundingBox(4),region{j}.BoundingBox(4));
        temp2=dist(region{i}.Color,region{j}.Color');
        temp4=abs(region{i}.Area-region{j}.Area);
        T3=5*min(region{i}.Area,region{j}.Area);
        temp5=abs(y(i,3)-y(j,3))/max(y(i,3),y(j,3))+abs(y(i,4)-y(j,4))/max(y(i,4),y(j,4));
        if XX<3&&YY<T1/3&&temp2<a&&temp4<T3&&temp5<1
           % if temp1<TT&&temp2<a(2)
             C(i,j)=1;
        end
    end
end


   C=C+C'-diag(diag(C));
   C=sparse(C);
   CC=components(C);
   
   cont=0;
   myregion={};
   for i=1:max(CC)
       idC=find(CC==i);
       region1=split_region(region(idC));
       for j=1:length(region1)
           cont=cont+1;
           myregion{cont}.data=region1{j}.data;
           myregion{cont}.component=idC(region1{j}.component);
       end 
   end
   
   