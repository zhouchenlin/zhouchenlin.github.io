function [imgresult,imgtest]=solvePDE(imgORI,a,b)
%%%imgORI ԭʼͼ��, a,b:PDEϵ��
M_ori=size(imgORI,1);
N_ori=size(imgORI,2);
if M_ori>400&&M_ori<901
    imgtest=imresize(imgORI,[M_ori/2 N_ori/2]);
else if M_ori>900&&M_ori<1801
        imgtest=imresize(imgORI,[M_ori/4 N_ori/4]);
    else if M_ori>1800&&M_ori<3600
            imgtest=imresize(imgORI,[M_ori/8 N_ori/8]);
        else
            imgtest=imgORI;
        end
    end
end
%%����PDE���
glo.dt=0.05;
glo.INV=69;
T=size(a,2);
ImgIn=SetZeroboundry(imgtest);
temp=rgb2gray(ImgIn);
[W,H]=size(temp);
U=im2double(temp);
U(:,:)=1;
V=im2double(ImgIn);
for k=1:T
    Inv=geneInv_auto(U,glo,V);
    if k<T
        U=pdeStep_auto(U,Inv,a(:,k),glo);
        for i=1:3
            V(:,:,i)=pdeStep_auto(V(:,:,i),Inv,b(:,i,k),glo);
        end
    else
        U=pdeStep_auto(U,Inv,a(:,k),glo);
    end
end
temp=U(3:W-2,3:H-2);
temp=255*temp+0.5;
temp(find(temp<0))=0;
temp(find(temp>255))=255;
imgresult=uint8(temp);