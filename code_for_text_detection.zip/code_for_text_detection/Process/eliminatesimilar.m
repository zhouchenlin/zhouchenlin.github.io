% load('D:\Result\Test_9.mat')
% load('C:\Users\Administrator\Desktop\retangle\cluster\Color\Test_9.mat')
% color=RegionCC;
% load('C:\Users\Administrator\Desktop\retangle\cluster\BW\Test_9.mat')
% bw=RegionCC;
function  similar=eliminatesimilar(tempcc)
% for jj=1:length(Reg)
% region=Reg{1,jj};
% %figure;
% %imshow(region.img);
% if strcmp(region.label,'BW')
%     tempcc=bw;
% else
%     tempcc=color;
% end
% nn=length(region.component);
% if nn<2
%     Reg{1,jj}.similar=0;
%     continue;
% end
% aaall=cell(1,nn);

%img1=zeros(900,1200);

nn=length(tempcc);
if nn<2
     similar=0;
     return;
end
aaall=cell(1,nn);
for i=1:nn    
%pix1=round(tempcc{1,region.component(i)}.Pixel);
pix1=round(tempcc{1,i}.Pixel);
pixmax1=max(pix1(:,1));
     pixmax2=max(pix1(:,2));
     pixmin1=min(pix1(:,1));
     pixmin2=min(pix1(:,2));
     aa=zeros(pixmax2-pixmin2+1,pixmax1-pixmin1+1);

        for ll=1:size(pix1,1)
       % img1(pix1(ll,2),pix1(ll,1))=1;
          aa(pix1(ll,2)-pixmin2+1,pix1(ll,1)-pixmin1+1)=1;
        end
        %   figure
       % imshow(aa);
 %         figure;
%          imshow(img1);
      aaall{1,i}.img=aa;
end
%close all
cov=[];
for i=1:nn
    for j=i+1:nn
        if size(aaall{1,i}.img,2)>size(aaall{1,j}.img,2)
            if size(aaall{1,i}.img,2)/size(aaall{1,j}.img,2)>1.7
              tempimg1=aaall{1,i}.img;
              tempimg2=repmat(aaall{1,j}.img,1,round(size(aaall{1,i}.img,2)/size(aaall{1,j}.img,2)));
            else
                tempimg1=aaall{1,i}.img;
                 tempimg2=aaall{1,j}.img;
            end
        else
            if size(aaall{1,j}.img,2)/size(aaall{1,i}.img,2)>1.7
                        tempimg1=aaall{1,j}.img;
              %tempimg2=padarray(aaall{1,i}.img,[0,size(aaall{1,j}.img,2)-size(aaall{1,i}.img,2)],'replicate','post');
              tempimg2=repmat(aaall{1,i}.img,1,round(size(aaall{1,j}.img,2)/size(aaall{1,i}.img,2)));
            else 
                  tempimg1=aaall{1,j}.img;
                 tempimg2=aaall{1,i}.img;
            end
        end
        if  size(tempimg1,1)/size(tempimg2,2)>1.7
         tempimg2=repmat(tempimg2,round(size(tempimg1,1)/size(tempimg2,1)),1);
        end
        if size(tempimg2,1)/size(tempimg1,2)>1.7
             tempimg1=  repmat(tempimg1,round(size(tempimg2,1)/size(tempimg1,1)),1); 
        end
        zo1=length(find(tempimg1>0));
        zo2=length(find(tempimg2>0));
        %figure; imshow(tempimg1);figure; imshow(tempimg2);
    temp=xcorr2(tempimg1,tempimg2);
    %cov=[cov,max(max(temp))/max(length(tempcc{1,region.component(i)}.Pixel),length(tempcc{1,region.component(j)}.Pixel))];
    cov=[cov,max(max(temp))/max(zo1,zo2)];
    end    
end
cov=sort(cov);
if nn>2
similar=(cov(floor(length(cov)/2))+cov(ceil(length(cov)/3)))/2;
else
 similar=cov(1);
end
% Reg{1,jj}.similar=similar;
% end
%close all