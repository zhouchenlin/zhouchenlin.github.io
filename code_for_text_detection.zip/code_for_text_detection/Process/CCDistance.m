function C=CCDistance(region1,region2)

C=0;

y(1,:)=region1{1}.BoundingBox;
y(2,:)=region2{1}.BoundingBox;
% if (y(1,1)-y(2,1))*(y(1,1)+y(1,3)-y(2,1)-y(2,3))<0
%     XX =3+1;
% else
%     XX=min(abs(y(1,1)-y(2,1)-y(2,3)),abs(y(2,1)-y(1,1)-y(1,3)))/max(y(1,3),y(2,3));
% end
YY=min(abs(y(1,2)-y(2,2)),abs(y(1,2)+y(1,4)-y(2,2)-y(2,4)))/min(region1{1}.BoundingBox(4),region2{1}.BoundingBox(4));
YY1=max(abs(y(1,2)-y(2,2)),abs(y(1,2)+y(1,4)-y(2,2)-y(2,4)))/max(region1{1}.BoundingBox(4),region2{1}.BoundingBox(4));

temp2=dist(region1{1}.Color,region2{1}.Color');
temp6=abs(y(1,4)-y(2,4))/max(y(1,4),y(2,4));
%if XX<3&&YY<1/3&&temp2<50
if YY<1/3&&temp2<50&&temp6<0.7&&YY1<1/2
    C=1;
end
