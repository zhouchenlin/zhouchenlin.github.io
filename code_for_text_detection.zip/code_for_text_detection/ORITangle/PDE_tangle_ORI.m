function  myregion=PDE_tangle_ORI(imgresult,imgBW,imgori1,para)


    [M N]=size(imgresult);
    h=fspecial('average',[3 3]);
    imgresult1=imfilter(imgresult,h);
    imgresult=padarray(imgresult1(6:M-5,6:N-5),[5,5],'replicate');
    Yvalue=sum(im2double(imgBW)');
    Yvalue=smooth(Yvalue,0.15,'loess');
    peakmin=fpeakmin(1:M,Yvalue,10,[5,M-5,-5,max(5,mean(Yvalue)-1*std(Yvalue))]);
    Ydata=[];
    if size(peakmin,1)>0
        idpeakmin=[1;peakmin(:,1);M];
        for idpeak=1:size(peakmin,1)+1
            Ydata(idpeak,1)=idpeakmin(idpeak);
            Ydata(idpeak,2)=idpeakmin(idpeak+1);
        end
    else
        Ydata=[1 M];
    end
    
    myregion=[];
    for jj=1:size(Ydata,1)
        imtemp=imgresult(Ydata(jj,1):Ydata(jj,2),:);
        imtemprgb=imgori1(Ydata(jj,1):Ydata(jj,2),:,:);
        imtemprgb=double(imtemprgb);
        if max(max(imtemp))>60
            imtemp=im2bw(imtemp,graythresh(imtemp));
            box = regionprops(imtemp, 'BoundingBox');
            %%%color
            boxid=regionprops(imtemp, 'PixelList');
            for idrgb=1:length(boxid)
                boxrgb(idrgb).color=zeros(1,1,3);
                for idpixel=1:size(boxid(idrgb).PixelList,1)
                    tempcolor=imtemprgb(boxid(idrgb).PixelList(idpixel,2),boxid(idrgb).PixelList(idpixel,1),:);
                    boxrgb(idrgb).color=boxrgb(idrgb).color...
                        +tempcolor/size(boxid(idrgb).PixelList,1);
                end
            end
            myregiontemp=unite_box(box,boxrgb,para);
            %%%�޸�myregion
             myretemp=[];
            idd=1;
            for idre=1:size(myregiontemp,1);
                XX1=ceil(myregiontemp(idre,1));
                XX2=floor(myregiontemp(idre,2));
                YY1=ceil(myregiontemp(idre,3));
                YY2=floor(myregiontemp(idre,4));
                if (XX2-XX1)*(YY2-YY1)>100
                    myretemp(idd,1)=myregiontemp(idre,1)+Ydata(jj,1)-1;
                    myretemp(idd,2)=myregiontemp(idre,2)+Ydata(jj,1)-1;
                    myretemp(idd,3)=myregiontemp(idre,3);
                    myretemp(idd,4)=myregiontemp(idre,4);
                    idd=idd+1;
                end
            end
            myregion=[myregion;myretemp];
            myregiontemp=[];
        end
    end