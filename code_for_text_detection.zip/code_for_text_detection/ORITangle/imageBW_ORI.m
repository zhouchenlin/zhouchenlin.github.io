function imBW=imageBW_ORI(img)

    M=size(img,1);
    N=size(img,2);
    tt = graythresh(img);
    congray=zeros(256,1);
    for i=1:M
        for j=1:N
            congray(img(i,j)+1,1)=congray(img(i,j)+1,1)+1;
        end
    end
    cont=0;
    tt=256;
    while (tt>0)
        cont=cont+congray(tt,1);
        if cont>(M*N)/10
            break
        end
        tt=tt-1;
    end
    bim=im2bw(img,tt/255);
    se = strel('rectangle',[2 2]);
    bim = imclose(bim,se);
    se = strel('rectangle',[2 2]);
    imBW = imopen(bim,se);