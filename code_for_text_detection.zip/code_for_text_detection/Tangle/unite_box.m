function myregion=unite_box(box,boxrgb,a)



for i=1:length(box)
    yvalue(i,1)=box(i).BoundingBox(2);
    yvalue(i,2)=box(i).BoundingBox(2)+box(i).BoundingBox(4);
    yvalue(i,3)=box(i).BoundingBox(1);
    yvalue(i,4)=box(i).BoundingBox(1)+box(i).BoundingBox(3);
end

C=zeros(length(box),length(box));
for i=1:length(box)
    C(i,i)=1;
    for j=i+1:length(box)
        T1=min(box(i).BoundingBox(4),box(j).BoundingBox(4));
        T2=min(box(i).BoundingBox(3),box(j).BoundingBox(3));
        temp1=Y_distance(yvalue(i,1:2),yvalue(j,1:2));
        temp2=X_distance(yvalue(i,3:4),yvalue(j,3:4));
        temp3=rgb_distance(boxrgb(i).color,boxrgb(j).color);
        if temp1<a(1)*T1&&temp2<a(2)*T2&&temp3<a(3)
            C(i,j)=1;
        end
    end
end

   C=C+C'-diag(diag(C));
   C=sparse(C);
   CC=components(C);
   myregion=zeros(max(CC),4);
   for i=1:max(CC)
       idC=find(CC==i);
       myregion(i,1:4)=[min(yvalue(idC,1)) max(yvalue(idC,2)) min(yvalue(idC,3)) max(yvalue(idC,4))];
   end
   
function L=rgb_distance(a,b)
    L=sqrt((a(1)-b(1))^2+(a(2)-b(2))^2+(a(3)-b(3))^2);
function X=Y_distance(A,B)
if A(1)<B(1)&&A(2)>B(2)
    X=0;
else if A(1)>B(1)&&A(2)<B(2)
        X=0;
    else
        X=min(abs(A(1)-B(1)),abs(A(2)-B(2)));
    end
end
   function X=X_distance(A,B)
if A(1)<B(1)&&A(2)>B(2)
    X=0;
else if A(1)>B(1)&&A(2)<B(2)
        X=0;
    else
        X=min([abs(A(1)-B(1)),abs(A(2)-B(2)),abs(A(1)-B(2)),abs(A(2)-B(1))]);
    end
end 
