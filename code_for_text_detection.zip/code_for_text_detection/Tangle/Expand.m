function Y=Expand(X,Xvalue,T,M,N,A)
if Xvalue(1)<T
    Y(1)=max(1,X(1)-A);
else
    Y(1)=X(1);
end
if Xvalue(2)<T
    Y(2)=min(M,X(2)+A);
else
    Y(2)=X(2);
end
if Xvalue(3)<T
    Y(3)=max(1,X(3)-A);
else
    Y(3)=X(3);
end
if Xvalue(4)<T
    Y(4)=min(N,X(4)+A);
else
    Y(4)=X(4);
end