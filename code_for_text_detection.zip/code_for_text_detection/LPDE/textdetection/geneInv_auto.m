function inv=geneInv_auto(Uin,glo,V)
% //************************************************************************
% //*  Function Name: geneInv
% //*  Function Description: 
% //*      computes invariant bases inv_i(t).
% //*  Arguments: 
% //*      [IN] : DifImage_T &idc
% //*      [IN] : DifImage_T &gen
% //*      [OUT] : double *invBase
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2013-11-24 13:46:52 by Zhenyu Zhao
% //************************************************************************
[ww,hh,ll]=size(V);
Dif_v=zeros(ww,hh,6,ll+1);
Dif_v(:,:,:,1)=DifImage1(Uin);
for i=1:ll
    Dif_v(:,:,:,i+1)=DifImage1(V(:,:,i));
end
ll=1+ll;
inv=zeros(ww*glo.INV,hh);
%%%inv
s=1;
inv((s-1)*ww+1:s*ww,:)=ones(ww,hh);
for i=1:ll
    temp=Dif_v(:,:,1,i);
    s=s+1;
    inv((s-1)*ww+1:s*ww,:)=temp;
end

for i=1:ll
    for j=i:ll
        temp=Dif_v(:,:,2,i).*Dif_v(:,:,2,j)+Dif_v(:,:,3,i).*Dif_v(:,:,3,j);
        s=s+1;
        inv((s-1)*ww+1:s*ww,:)=temp;
    end
end

for i=1:ll
    temp=Dif_v(:,:,4,i)+Dif_v(:,:,6,i);
    s=s+1;
    inv((s-1)*ww+1:s*ww,:)=temp;
end

for i=1:ll
    for j=i:ll
        for k=1:ll
            temp=(Dif_v(:,:,2,i).*Dif_v(:,:,4,k)+Dif_v(:,:,3,i).*Dif_v(:,:,5,k)).*Dif_v(:,:,2,j)...
                +(Dif_v(:,:,2,i).*Dif_v(:,:,5,k)+Dif_v(:,:,3,i).*Dif_v(:,:,6,k)).*Dif_v(:,:,3,j);
            s=s+1;
            inv((s-1)*ww+1:s*ww,:)=temp;
        end
    end
end

for i=1:ll
    for j=i:ll
        temp=Dif_v(:,:,4,i).*Dif_v(:,:,4,j)+2*Dif_v(:,:,5,i).*Dif_v(:,:,5,j)+Dif_v(:,:,6,i).*Dif_v(:,:,6,j);
        s=s+1;
        inv((s-1)*ww+1:s*ww,:)=temp;
    end
end
