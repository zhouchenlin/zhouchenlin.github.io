function [a,b,Err]=train_FC(Uin,Vin,Uout,glo)

% 
% //************************************************************************
% //*  Function Name: train 
% //*  Function Description: 
% //*      learn coefficient function from image pairs
% //*  Arguments: 
% //*      [IN] : string inFilePath
% //*      [IN] : string outFilePath
% //*      [OUT] : double *a
% //*      [IN] : globalParam
% //* 
% //*  Return Value: a
% //*      none.
% //* 
% //*  Last Modified on: 2014-04-03 10:47:48 by Zhenyu Zhao
% //************************************************************************

%%set initial values of a
U_last=Uin;
V_last=Vin;
V=V_last;
Dphi=1+glo.eps;
Err=[];
%while Dphi<glo.eps&&layer<glo.maxIter
[a(:,1),phi]=stepa(Uin,V,Uout,glo);
for L=1:glo.M
    Inv=geneInv_auto(U_last{L}.data,glo,V_last{L}.data);
    U{L}.data=pdeStep_auto(U_last{L}.data,Inv,a(:,1),glo);
end
Err=[Err phi]

MaxDerr=phi;
t=2;
while MaxDerr>glo.eps&&t<glo.maxIter
   b(:,:,t-1)=zeros(glo.INV,3,1);
   a(:,t)=zeros(glo.INV,1);
    %%each time
    counter=1;
    MaxDb=glo.eps+1;
    while MaxDb>glo.eps&&counter<5
        [tempa,err(1)]=stepa(U,V,Uout,glo);
        [b(:,:,t-1),err(2),U_next,V]=stepb(U_last,U,V_last,Uout,a(:,t),b(:,:,t-1),glo);
%         b(:,:,t-1)=zeros(glo.INV,3,1);
%         err(2)=err(1);
        MaxDb=max(abs(tempa-a(:,t)));
        a(:,t)= tempa;
        counter=counter+1;
        if abs(err(1)-err(2))<10*glo.eps
            break;
        end
    end
   
    
    MaxDerr=abs(err(1)-phi);
    phi=err(1);
    Err=[Err phi]
   V_last=V;
  
   
   for s=1:glo.M
       %congray=zeros(256,1);
       map=U_next{s}.data*256;
       map(find(map>255))=255;
       map(find(map<0))=0;
       fil=ones(36)/1296;
       if(t>2)
           map=map.*indi{s}.data;
       end
       if(t==10)
           V_last{s}.data(:,:,1)=Vin{s}.data(:,:,1);
           V_last{s}.data(:,:,2)=Vin{s}.data(:,:,2);
           V_last{s}.data(:,:,3)=Vin{s}.data(:,:,3);
       end
       [m,n]=size(map);
       so=map(:);
       so=sort(so);
       ide=1;
       while(so(ide)==0)
           ide=ide+1;
       end
       qq=ide+(m*n-ide)/2;
       tt=so(round(qq));
       map(find(map<tt))=0;
       map=double(map)/255;
       indi{s}.data=imfilter(map,fil,'replicate');
       indi{s}.data(find(indi{s}.data>0))=1;
       %indi(find(indi)<0.01)=0;
       U_next{s}.data=map;
       
   end
    
    
    
    U_last=U;
    U=U_next;
    if MaxDerr<glo.eps
        break;
    end
    t=t+1;
end



