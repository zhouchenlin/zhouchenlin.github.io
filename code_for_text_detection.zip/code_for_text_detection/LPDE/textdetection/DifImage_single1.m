function Dif_image=DifImage_single1(P,p,q);

% 
% //************************************************************************
% //*  Module Name: 
% //*        implementation of differential image class.
% //*  Abstract: 
% //*        implements a class to do difference operator of images.
% //*  Note: 
% //*        none.
% //* 
% //*  Last Modified on: 2013-11-23 10:38:42 by Zhenyu Zhao
% //***********************************************************************
% *

[m n]=size(P);
F=zeros(m+4,n+4);
F(3:m+2,3:n+2)=P;
if p==0&&q==0
    Dif_image(:,:)=P;
else if p==1&&q==0
           Dif_image(:,:)=(F(3:m+2,4:n+3)-F(3:m+2,2:n+1))/2;
    else if p==0&&q==1
             Dif_image(:,:)=(F(4:m+3,3:n+2)-F(2:m+1,3:n+2))/2;
        else if p==2&&q==0
               Dif_image(:,:)=F(3:m+2,2:n+1)+F(3:m+2,4:n+3)-2*P;
            else if p==1&&q==1
                    Dif_image(:,:)=(F(2:m+1,2:n+1)+F(4:m+3,4:n+3)-F(2:m+1,4:n+3)-F(4:m+3,2:n+1))/4;
                else   
                     Dif_image(:,:)=F(2:m+1,3:n+2)+F(4:m+3,3:n+2)-2*P;
                end
            end
        end
    end
end
Dif_image(1,:)=0;
Dif_image(m,:)=0;
Dif_image(:,1)=0;
Dif_image(:,n)=0;
