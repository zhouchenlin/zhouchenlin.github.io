function [b,phi,U_next,V]=stepb(U_last,U,V_last,Uout,a,b,glo)
% //************************************************************************
% //*  Function Name: stepInit 
% //*  Function Description: 
% //*      
% //*  Arguments: 
% //*      [IN] : DifImage_T *pGen
% //*      [IN] : DifImage_T *pIdc
% //*      [IN] : DifImage_T *outImage
% //*      [OUT] : double *a
% //*      [IN] : int t
% //*      [IN] : GlobalParam_T &globalParam
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2014-3-10 22:10:11 by Zhenyu Zhao
% //************************************************************************  
c=zeros(3,1);
g=zeros(glo.INV,3);
G=zeros(glo.INV,glo.INV,3);
V=V_last;
for s=1:glo.M
    Inv_last=geneInv_auto(U_last{s}.data,glo,V_last{s}.data);
    for k=1:3
        V{s}.data(:,:,k)=pdeStep_auto(V_last{s}.data(:,:,k),Inv_last,b(:,k),glo);
    end
    Inv=geneInv_auto(U{s}.data,glo,V{s}.data);
    for k=1:3
        U_next1=pdeStep_auto(U{s}.data,Inv,a,glo);
        h=(Uout{s}.data-U_next1)/glo.dt;
        [W,H]=size(U{s}.data);
        L=zeros(W,H,glo.INV);
        Indicate=9*Uout{s}.data+ones(W,H);
        for i=1:6
            [p,q]=invInd(i);
            %       sigma1=geneSigmaO_auto(U(:,:,s),a,p,q,glo,V(:,:,s));
            sigma=geneSigmaO(U{s}.data,a,p,q,glo,1+k,V{s}.data);
            for j=1:glo.INV
                d_tmp=DifImage_single1(Inv_last((j-1)*W+1:j*W,:),p,q);
                L(:,:,j)=L(:,:,j)-sigma.*d_tmp;
            end
        end
        for j=1:glo.INV
            d_temp=h-b(j,k)*L(:,:,j);
        end
        c(k)=c(k)+trace(d_temp'*d_temp)/(W*H);
        for i=1:glo.INV
            g(i,k)=g(i,k)+sum(sum(Indicate.*L(:,:,i).*d_temp))/(W*H);
            for j=i:glo.INV
                G(i,j,k)=G(i,j,k)+sum(sum(Indicate.*L(:,:,i).*L(:,:,j)))/(W*H);
            end
        end
    end
end
for i=2:glo.INV
    for j=1:i-1
        G(i,j,:)=G(j,i,:);
    end
end
phi=0;
for k=1:3
    C=G(:,:,k)^(1/2);
    C=real(C);
    d=pinv(C)*g(:,k);
    lb=-0.1*glo.lamta*ones(glo.INV,1);
    ub=0.1*glo.lamta*ones(glo.INV,1);
    %        G=reshape(G,glo.INV*glo.INV,1);
    %        X0=qcqp(G,g,c);
    %        G=reshape(G,glo.INV,glo.INV);
    X0=zeros(glo.INV,1);
    OPTIONS.TolFun=glo.eps;
    OPTIONS.MaxIter=20;
    b(:,k)=lsqlin(C,d,[],[],[],[],lb,ub,X0,OPTIONS);
    phi=phi+c(k)/2-g(:,k)'*b(:,k)+b(:,k)'*G(:,:,k)*b(:,k)/2;
end


U_next=U;
phi=0;
for s=1:glo.M
    Inv_last=geneInv_auto(U_last{s}.data,glo,V_last{s}.data);
    for k=1:3
        V{s}.data(:,:,k)=pdeStep_auto(V_last{s}.data(:,:,k),Inv_last,b(:,k),glo);
    end
    Inv=geneInv_auto(U{s}.data,glo,V{s}.data);
    U_next{s}.data=pdeStep_auto(U{s}.data,Inv,a,glo);
    [W H]=size(U{s}.data);
    Indicate=9*Uout{s}.data+ones(W,H);
    phi=phi+sum(sum(Indicate.*(Uout{s}.data-U_next{s}.data).*(Uout{s}.data-U_next{s}.data)))/(2*W*H);
end


function [p,q]=invInd(i)

if i==1
    p=0;q=0;
else if i==2
        p=1;q=0;
    else if i==3
            p=0;q=1;
        else if i==4
                p=2;q=0;
            else if i==5
                    p=1;q=1;
                else
                    p=0;q=2;
                end
            end
        end
    end
end




