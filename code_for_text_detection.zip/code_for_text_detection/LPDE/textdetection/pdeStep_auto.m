function U_next=pdeStep_auto(U,Inv,a,glo)
% //************************************************************************
% //*  Function Name: pdeStep
% //*  Function Description: 
% //*      solve the pde step by step
% //*  Arguments: 
% //*      [IN] :U_temp
% //*      [IN] : U
% //*      [OUT] : DifImage_T U_next
% //*      [IN] : a_temp
% //*      [IN] : glo
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2014-3-10 21:25:52 by Zhenyu Zhao
% //************************************************************************
[W,H]=size(U);
U_next=zeros(W,H);
for i=1:glo.INV
    U_next(:,:)=U_next(:,:)+a(i)*Inv((i-1)*W+1:i*W,:);
end
U_next(:,:)=U(:,:)+glo.dt*U_next(:,:);
U_next(1:2,:,:)=0;
U_next(W-1:W,:,:)=0;
U_next(:,1:2,:)=0;
U_next(:,H-1:H,:)=0;