function a=solvea_auto(b,G,a,c,glo);
% //************************************************************************
% //*  Function Name: solvea
% //*  Function Description: 
% //*      Solve a
% //*  Arguments: 
% //*      [IN] : DifImage_T &inImage
% //*      [IN] : double *psi
% //*      [OUT] : double *a - coefficient functions a = {a} 
% //*      [IN] : double *pLamta 
% //*      [IN] : double mu 
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2013-11-25 23:29:53 by Zhenyu Zhao
% //************************************************************************
for kk=1:2
    
    bb=b(:,kk);
    GG=G(:,:,kk);
 %   aa=a(:,kk);
    cc=c(:,kk);
    
    
  %  a(:,kk)=pinv(GG+glo.lamta*eye(glo.INV))*bb;
    
    GG=reshape(GG,glo.INV*glo.INV,1);
    a(:,kk)=qcqp(GG,bb,cc);
    
%         % %%    lasso
%     D=GG^(1/2);
%     D=real(D);
%     X=pinv(D)*bb;
%     % %     a=lasso(D,X, 'Lambda',glo.lamta/glo.mu);
%     %
%     %%mexLasso
%     paramSR.lambda2 = 0;
%     paramSR.mode    = 0;
%     paramSR.lambda  = glo.lamta/mu;
%     a_temp = mexLasso(X, D, paramSR);
%     a(:,kk) = full(a_temp);
    
%     L=max(eig(GG));
%     
%     Obj=[];
%     phi=glo.eps+1.0;
%     counter=1;
%     while phi>glo.eps&&counter<glo.maxIter
%         tempa=aa;
%         aa=aa-(GG*aa-bb)/L;
%         for i=1:glo.INV
%             if aa(i)>glo.lamta/(mu*L)
%                 aa(i)=aa(i)-glo.lamta/(mu*L);
%             else if aa(i)<-glo.lamta/(mu*L)
%                     aa(i)=aa(i)+glo.lamta/(mu*L);
%                 else
%                     aa(i)=0;
%                 end
%             end
%         end
%         phi=(aa-tempa)'*(aa-tempa);
%         obj=glo.lamta*sum(abs(a))-mu*bb'*aa+mu/2*aa'*GG*aa;
%         Obj=[Obj obj];
%         %     disp('Solvea: acounter: ');
%         % 	counter
%         % 	disp('Solvea: AobjVal: ');
%         %     obj
%         %      counter=counter+1;
%     end
%     a(:,kk)=aa;
end