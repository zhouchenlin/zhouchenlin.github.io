function [a,b,Err]=train_auto(U,V,Uout,glo)

% 
% //************************************************************************
% //*  Function Name: train 
% //*  Function Description: 
% //*      learn coefficient function from image pairs
% //*  Arguments: 
% //*      [IN] : string inFilePath
% //*      [IN] : string outFilePath
% //*      [OUT] : double *a
% //*      [IN] : globalParam
% //* 
% //*  Return Value: a
% //*      none.
% //* 
% //*  Last Modified on: 2014-04-03 10:47:48 by Zhenyu Zhao
% //************************************************************************

%%set initial values of a
U_last=U;
V_last=V;
V=V_last;
Err=[];
[a(:,1),phi]=stepa(U,V,Uout,glo);
for L=1:glo.M
    Inv=geneInv_auto(U_last{L}.data,glo,V_last{L}.data);
    U{L}.data=pdeStep_auto(U_last{L}.data,Inv,a(:,1),glo);
end
Err=[Err phi]
MaxDerr=phi;
t=2;
while MaxDerr>glo.eps&&t<glo.maxIter
    b(:,:,t-1)=zeros(glo.INV,3,1);
    a(:,t)=zeros(glo.INV,1);
    %%each time
    counter=1;
    MaxDb=glo.eps+1;
    while MaxDb>glo.eps&&counter<5
        [tempa,err(1)]=stepa(U,V,Uout,glo);
        [b(:,:,t-1),err(2),U_next,V]=stepb(U_last,U,V_last,Uout,a(:,t),b(:,:,t-1),glo);
        MaxDb=max(abs(tempa-a(:,t)));
        a(:,t)= tempa;
        counter=counter+1;
        if abs(err(1)-err(2))<10*glo.eps
            break;
        end
    end
    MaxDerr=abs(err(1)-phi);
    phi=err(1);
    Err=[Err phi]
    V_last=V;
    U_last=U;
    U=U_next;
    if MaxDerr<glo.eps
        break;
    end
    t=t+1;
end



