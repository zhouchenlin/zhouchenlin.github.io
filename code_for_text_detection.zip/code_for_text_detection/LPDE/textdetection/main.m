clear all
clc

%%set parameters
glo={};
glo.lamta=10;
glo.dt=0.05;
glo.M=60;
glo.eps=0.01*glo.M/(255*255);
glo.gapWidth=2;
glo.maxIter=10;
glo.selfInit=1;
glo.INV=69;
glo.mu=1;

% %%%ICDAR2003���ݼ�
%InImage = dir('D:\data\text\ICDAR2003\dataRename\Resize\GT\*.jpg');

% %%%ICDAR2003���ݼ�
InImage = dir('D:\data\text\ICDAR2013\data\input\*.jpg');

%%%MSRA���ݼ�
% InImage = dir('D:\data\text\MRSA\data\output\*.jpg');

%%%OSTD���ݼ�
% InImage = dir('D:\data\text\OSTD\OrientedSceneTextDataset\input\*.bmp');
% testImage = dir('D:\data\text\OSTD\OrientedSceneTextDataset\input\*.bmp');

Ind=randperm(length(InImage));
Uin=cell(glo.M,1);
Vin=cell(glo.M,1);
Uout=cell(glo.M,1);


for s=1:glo.M
    tempin_path=['D:\data\text\ICDAR2013\data\input\' InImage(Ind(s)).name];
    Img1=imread(tempin_path);
    tempout_path=['D:\data\text\ICDAR2013\data\output1\' InImage(Ind(s)).name];
    Img2=imread(tempout_path);
    if size(Img1,1)==size(Img2,1)
        ImgIn=SetZeroboundry(Img1);
        temp=rgb2gray(ImgIn);
        Uin{s}.data=im2double(temp);
        Uin{s}.data(:,:)=1;
        Vin{s}.data=im2double(ImgIn);
        ImgOut=SetZeroboundry(Img2);
        Uout{s}.data=im2double(ImgOut(:,:,1));
    end
end
tic
[a,b,Err]=train_auto(Uin,Vin,Uout,glo);
toc
testImage = dir('D:\data\text\ICDAR2013\data\test\*.jpg');
mkdir('D:\data\text\ICDAR2013\data\result1\');
save('D:\data\text\ICDAR2013\data\result1\a','a');
save('D:\data\text\ICDAR2013\data\result1\b','b');
%%%test
T=size(a,2);
for s=1:length(testImage)
    tempin_path=['D:\data\text\ICDAR2013\data\test\' testImage(s).name];
    Img1=imread(tempin_path);
    ImgIn=SetZeroboundry(Img1);
    temp=rgb2gray(ImgIn);
    [W,H]=size(temp);
    U=im2double(temp);
    U(:,:)=1;
    V=im2double(ImgIn);
    for k=1:T
        Inv=geneInv_auto(U,glo,V);
        if k<T
            U=pdeStep_auto(U,Inv,a(:,k),glo);
            for i=1:3
                V(:,:,i)=pdeStep_auto(V(:,:,i),Inv,b(:,i,k),glo);
            end
        else
            U=pdeStep_auto(U,Inv,a(:,k),glo);
        end
    end
    
    temp=U(3:W-2,3:H-2);
    temp=255*temp+0.5;
    temp(find(temp<0))=0;
    temp(find(temp>255))=255;
    temp=uint8(temp);
    tempresult_path=['D:\data\text\ICDAR2013\data\result1\' testImage(s).name];
    imwrite(temp,tempresult_path,'jpg');
end

