function [a,phi]=stepa(U,V,O,glo)
% //************************************************************************
% //*  Function Name: stepInit 
% //*  Function Description: 
% //*      
% //*  Arguments: 
% //*      [IN] : DifImage_T *pGen
% //*      [IN] : DifImage_T *pIdc
% //*      [IN] : DifImage_T *outImage
% //*      [OUT] : double *a
% //*      [IN] : int t
% //*      [IN] : GlobalParam_T &globalParam
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2014-3-10 22:10:11 by Zhenyu Zhao
% //************************************************************************
c=0;
g=zeros(glo.INV,1);
G=zeros(glo.INV,glo.INV);
for s=1:glo.M
    d_temp=(O{s}.data-U{s}.data)/glo.dt;
    Inv=geneInv_auto(U{s}.data,glo,V{s}.data);
    [W,H]=size(U{s}.data);
    Indicate=9*O{s}.data+ones(W,H);
    c=c+trace(d_temp'*d_temp)/(W*H);
    for i=1:glo.INV
        g(i)=g(i)+sum(sum(Indicate.*Inv((i-1)*W+1:i*W,:).*d_temp))/(W*H);
        for j=i:glo.INV
            G(i,j)=G(i,j)+sum(sum(Indicate.*Inv((i-1)*W+1:i*W,:).*Inv((j-1)*W+1:j*W,:)))/(W*H);
        end
    end
end
G=G+G'-diag(diag(G));
%%trust region
C=G^(1/2);
C=real(C);
d=pinv(C)*g;
lb=-glo.lamta*ones(glo.INV,1);
ub=glo.lamta*ones(glo.INV,1);

G=reshape(G,glo.INV*glo.INV,1);
X0=qcqp(G,g,c);
G=reshape(G,glo.INV,glo.INV);

%     X0=zeros(glo.INV,1);
OPTIONS.TolFun=glo.eps;
OPTIONS.MaxIter=10;
a=lsqlin(C,d,[],[],[],[],lb,ub,X0,OPTIONS);
%%Err
%phi=c/2-g'*a+a'*G*a/2;

U_next=U;
phi=0;
for s=1:glo.M
    Inv=geneInv_auto(U{s}.data,glo,V{s}.data);
    U_next{s}.data=pdeStep_auto(U{s}.data,Inv,a,glo);
    [W,H]=size(U{s}.data);
    Indicate=9*O{s}.data+ones(W,H);
    phi=phi+sum(sum(Indicate.*(O{s}.data-U_next{s}.data).*(O{s}.data-U_next{s}.data)))/(2*W*H);
end
