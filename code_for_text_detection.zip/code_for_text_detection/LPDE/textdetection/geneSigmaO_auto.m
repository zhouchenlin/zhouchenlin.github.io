function sigma=geneSigmaO_auto(Uin,a,p,q,glo,V)
% //************************************************************************
% //*  Function Name: geneSigmaO
% //*  Function Description: 
% //*      generate Sigma for O
% //*  Arguments: 
% //*      [IN] : Uin
% //*      [IN] : psi
% //*      [OUT] : sigma
% //*      [IN] : a
% //*      [IN] : p
% //*      [IN] : q
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2013-11-25 23:35:25 by Zhenyu Zhao
% //***********************************************************************
% *

if nargin == 5
    ll=size(Uin,3);
    for i=1:ll
        Dif_v(:,:,:,i)=DifImage1(Uin(:,:,i));
    end
else if nargin == 6
        Dif_v(:,:,:,1)=DifImage1(Uin);
        Dif_v(:,:,:,2)=DifImage1(V);
    end
end

sigma=zeros(glo.width,glo.height);

ind=invId(p,q);
switch ind;
    case 1;
        sigma(:,:)=a(3);
    case 2;
        sigma(:,:)=sigma(:,:)+a(5)*Dif_v(:,:,2,1);
        sigma(:,:)=sigma(:,:)+a(6)*2*Dif_v(:,:,2,2);
        for k=1:2
            sigma(:,:)=sigma(:,:)+a(10+k)*(Dif_v(:,:,2,1).*Dif_v(:,:,4,k)+Dif_v(:,:,3,1).*Dif_v(:,:,5,k));
        end
        for k=1:2
            sigma(:,:)=sigma(:,:)+a(12+k)*(2*Dif_v(:,:,2,2).*Dif_v(:,:,4,k)+2*Dif_v(:,:,3,2).*Dif_v(:,:,5,k));
        end
    case 3;
    
        sigma(:,:)=sigma(:,:)+a(5)*Dif_v(:,:,3,1);
        sigma(:,:)=sigma(:,:)+a(6)*2*Dif_v(:,:,3,2);
        for k=1:2
            sigma(:,:)=sigma(:,:)+a(10+k)*(Dif_v(:,:,3,1).*Dif_v(:,:,6,k)+Dif_v(:,:,2,1).*Dif_v(:,:,5,k));
        end
        for k=1:2
            sigma(:,:)=sigma(:,:)+a(12+k)*(2*Dif_v(:,:,3,2).*Dif_v(:,:,6,k)+2*Dif_v(:,:,2,2).*Dif_v(:,:,5,k));
        end
        
    case 4;

        sigma(:,:)=sigma(:,:)+a(8)*ones(glo.width,glo.height);
        sigma(:,:)=sigma(:,:)+a(10)*Dif_v(:,:,2,1).*Dif_v(:,:,2,1);
        sigma(:,:)=sigma(:,:)+a(12)*Dif_v(:,:,2,1).*Dif_v(:,:,2,2);
        sigma(:,:)=sigma(:,:)+a(14)*Dif_v(:,:,2,2).*Dif_v(:,:,2,2);
        sigma(:,:)=sigma(:,:)+a(17)*2*Dif_v(:,:,4,2);
        sigma(:,:)=sigma(:,:)+a(16)*Dif_v(:,:,4,1);
        
    case 5;

        sigma(:,:)=sigma(:,:)+a(10)*2*Dif_v(:,:,2,1).*Dif_v(:,:,3,1);
        sigma(:,:)=sigma(:,:)+a(12)*(Dif_v(:,:,2,2).*Dif_v(:,:,3,1)+Dif_v(:,:,3,2).*Dif_v(:,:,2,1));
        sigma(:,:)=sigma(:,:)+a(14)*2*Dif_v(:,:,2,2).*Dif_v(:,:,3,2);
        sigma(:,:)=sigma(:,:)+a(17)*4*Dif_v(:,:,5,2);
        sigma(:,:)=sigma(:,:)+a(16)*2*Dif_v(:,:,5,1);
    case 6;

        sigma(:,:)=sigma(:,:)+a(8)*ones(glo.width,glo.height);
        sigma(:,:)=sigma(:,:)+a(10)*Dif_v(:,:,3,1).*Dif_v(:,:,3,1);
        sigma(:,:)=sigma(:,:)+a(12)*Dif_v(:,:,3,1).*Dif_v(:,:,3,2);
        sigma(:,:)=sigma(:,:)+a(14)*Dif_v(:,:,3,2).*Dif_v(:,:,3,2);
        sigma(:,:)=sigma(:,:)+a(17)*2*Dif_v(:,:,6,2);
        sigma(:,:)=sigma(:,:)+a(16)*Dif_v(:,:,6,1);
    otherwise
        disp('[p q] is wrong.')
end

function Ind=invId(p,q)

if p==0&&q==0
    Ind=1;
else if p==1&&q==0
        Ind=2;
    else if p==0&&q==1
            Ind=3;
        else if p==2&&q==0
                Ind=4;
            else if p==1&&q==1
                    Ind=5;
                else
                    Ind=6;
                end
            end
        end
    end
end