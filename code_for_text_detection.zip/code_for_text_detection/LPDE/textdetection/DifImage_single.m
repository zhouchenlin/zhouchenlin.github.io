function Dif_image=DifImage_single(image,p,q);
% 
% //************************************************************************
% //*  Module Name: 
% //*        implementation of differential image class.
% //*  Abstract: 
% //*        implements a class to do difference operator of images.
% //*  Note: 
% //*        none.
% //* 
% //*  Last Modified on: 2013-11-23 10:38:42 by Zhenyu Zhao
% //************************************************************************

f=im2double(image);

Dif_image(:,:)=gD(f, 2, p, q);



function g = gD( f, scale, ox, oy )
% Gaussian (Derivative) Convolution
% K = ceil( 3 * scale );
K = ceil(1* scale );
x = -K:K;
% Gs = exp( - x.^2 / (2*scale^2) );
Gs = exp( - x.^2 /( 4*scale) )/sqrt(4*pi*scale);
Gs = Gs / sum(Gs);
Gsx = gDerivative( ox, x, Gs, scale );
Gsy = gDerivative( oy, x, Gs, scale );
% g = conv2( Gsx, Gsy, f, 'same' );
g = convSepBrd( f, Gsx, Gsy ); %%set boudnry equal not zero,if want to set zero,use conv2

function r = gDerivative( order, x, Gs, scale )
switch order
case 0
r = Gs;
case 1
% r = -x/(scale^2) .* Gs;
r = -x/(2*scale).* Gs;
case 2
% r = (x.^2-scale^2)/(scale^4) .* Gs;
r = (x.^2-2*scale)/(4*scale^2).* Gs;
otherwise
error('only derivatives up to second order are supported');
end

%%set boudnry equal not zero,
function g = convSepBrd( f, w1, w2 )
% convolve along colums + along rows with repetition of the border
N = size(f,1);
M = size(f,2);
K = (size(w1(:),1)-1)/2;
L = (size(w2(:),1)-1)/2;
iind = min(max((1:(N+2*K))-K,1),N);
jind = min(max((1:(M+2*L))-L,1),M);
fwb = f(iind,jind);
g=conv2(w1,w2,fwb,'valid');