% 
% warning off
%clc
clear all
close all

add_path

% randn('state',100);
% rand('state',50);

%% parameters for the experiments
% experiment option
DEBUG = 1;

lambda = 0.01;
num = 1;

% algorithm option
doAPG = 1;
doADM = 1;
doLADM = 1;
doLADMG = 1;
doLADMPS = 1;
doLADMPSAP = 1;

doGenData = 1;
doSave = 0;

% data option
ns = 5;
np = 50;
D = 250;
d = 5;

% ns = 10;
% np = 50;
% D = 500;
% d = 5;

% ns = 20;
% np = 50;
% D = 1000;
% d = 5;

%%
% initialize

opts = [];
opts.tol_chg = 1e-4;
opts.tol_err = 1e-4;
opts.max_iter = 1200;
opts.DEBUG = DEBUG;

apg_result = cell(num,1);
adm_result = cell(num,1);
ladm_result = cell(num,1);
ladmap_result = cell(num,1);

%%
d_inf = strcat(num2str(ns), 'x', num2str(np),...
        'x', num2str(D), 'x', num2str(d));
    
gt_fn = strcat('gt_data_', d_inf, '.mat');

if doGenData
    % generate data
    X0s = cell(num,1);
    E0s = cell(num,1);
    inds = cell(num,1);
    
    % generate ground truth
    Zs = cell(num,1);
    Ls = cell(num,1);
    Es = cell(num,1);
    
    for i = 1:num
        data = gene_subspace(ns,np,d,D);
        X0 = data.X;
        E0 = data.E;
        X0s{i} = X0;
        E0s{i} = E0;
        X = X0 + E0;
        inds{i} = data.inds;
        
        [gtZ,gtL,gtE] = ladmps_gt_latlrr(X,lambda);
        Zs{i} = gtZ;
        Ls{i} = gtL;
        Es{i} = gtE;

        
        ladmps_gt_rec_err = norm(X*gtZ+gtL*X+gtE-X,'fro')/norm(X,'fro')
%         S_Z = svd(gtZ,'econ');
%         S_L = svd(gtL,'econ');
%         ladmps_gt_obj_val = sum(S_Z) + sum(S_L) + lambda*sum(sum(abs(gtE)))
%     
%         [lgtZ,lgtL,lgtE] = ladmpsap4latlrr_gt(X,lambda);
%         
%         lladmps_gt_rel_err_Z = norm(lgtZ - gtZ,'fro')/norm(X,'fro')
%         lladmps_gt_rel_err_L = norm(lgtL - gtL,'fro')/norm(X,'fro')
%         lladmps_gt_rel_err_E = norm(lgtE - gtE,'fro')/norm(X,'fro')
    end
    
    save(gt_fn, 'X0s', 'E0s', 'inds', 'Zs', 'Ls', 'Es');
else
    load(gt_fn)
end

% for testing
% num = 20;
%%
for i = 1:num
    
    disp(num2str(i));
    %----------------------------------
    % generate data
    ii = i;% index for the generated data
    X = X0s{ii} + E0s{ii};
    ind = inds{ii};   
    uid = unique(ind);
    nGroup = length(uid);
    
    Z0 = Zs{ii};
    gt.Z = Z0;
    L0 = Ls{ii};
    gt.L = L0;
    E0 = Es{ii};
    gt.E = E0;
    %-----------------------------------

[m, n] = size(X);



% --- plot problem ---
fprintf('\n --- Summary of Problem ---\n');
fprintf('Matrix Size             : %d x %d\n',m,n);
fprintf('Subspace Number         : %d\n',ns);
fprintf('Sample Number           : %d\n',np);
fprintf('Subspace Dimension      : %d\n',d);
fprintf('Observation Dimension   : %d\n',D);

if doAPG
    disp('APG is running ...')
    
    apg_ts = tic; 
    [Z, L, E, Out] = apg_latlrr(X, lambda, opts, gt);
    apg_tf = toc(apg_ts)

    apg_result{i} = comp_result(Z, L, E, Out, ...
        Z0, L0, E0, ind, nGroup);

        
     apg_rec_err = norm(X*Z+L*X+E-X,'fro')/norm(X,'fro')
%     S_Z = svd(Z,'econ');
%     S_L = svd(L,'econ');
%     apg_obj_val = sum(S_Z) + sum(S_L) + lambda*sum(sum(abs(E)))

    apg_rel_err_Z = norm(Z - gtZ,'fro')/norm(gtZ,'fro')
    apg_rel_err_L = norm(L - gtL,'fro')/norm(gtL,'fro')
    apg_rel_err_E = norm(E - gtE,'fro')/norm(gtE,'fro')
end

if doADM
    disp('ADM is running ...')
    
    adm_ts = tic; 
    [Z, L, E, Out] = adm_latlrr(X, lambda, opts, gt);
    adm_tf = toc(adm_ts)

    adm_result{i} = comp_result(Z, L, E, Out, ...
        Z0, L0, E0, ind, nGroup);

    adm_rec_err = norm(X*Z+L*X+E-X,'fro')/norm(X,'fro')
%     S_Z = svd(Z,'econ');
%     S_L = svd(L,'econ');
%     adm_obj_val = sum(S_Z) + sum(S_L) + lambda*sum(sum(abs(E)))

    adm_rel_err_Z = norm(Z - gtZ,'fro')/norm(gtZ,'fro')
    adm_rel_err_L = norm(L - gtL,'fro')/norm(gtL,'fro')
    adm_rel_err_E = norm(E - gtE,'fro')/norm(gtE,'fro')
end

if doLADM
    disp('LADM is running ...')

    ladm_ts = tic; 
    [Z, L, E, Out] = ladm_latlrr(X, lambda, opts, gt);
    ladm_tf = toc(ladm_ts)

    ladm_result{i} = comp_result(Z, L, E, Out, ...
        Z0, L0, E0, ind, nGroup);

    ladm_rec_err = norm(X*Z+L*X+E-X,'fro')/norm(X,'fro')
%     S_Z = svd(Z,'econ');
%     S_L = svd(L,'econ');
%     ladm_obj_val = sum(S_Z) + sum(S_L) + lambda*sum(sum(abs(E)))

    ladm_rel_err_Z = norm(Z - gtZ,'fro')/norm(gtZ,'fro')
    ladm_rel_err_L = norm(L - gtL,'fro')/norm(gtL,'fro')
    ladm_rel_err_E = norm(E - gtE,'fro')/norm(gtE,'fro')
end

if doLADMG
    disp('LADMG is running ...')
    
    ladmg_ts = tic; 
    [Z, L, E, Out] = ladmg_latlrr(X, lambda, opts, gt);
    ladmg_tf = toc(ladmg_ts)

    ladmg_result{i} = comp_result(Z, L, E, Out, ...
        Z0, L0, E0, ind, nGroup);

    ladmg_rec_err = norm(X*Z+L*X+E-X,'fro')/norm(X,'fro')
%     S_Z = svd(Z,'econ');
%     S_L = svd(L,'econ');
%     ladmg_obj_val = sum(S_Z) + sum(S_L) + lambda*sum(sum(abs(E)))

    ladmg_rel_err_Z = norm(Z - gtZ,'fro')/norm(gtZ,'fro')
    ladmg_rel_err_L = norm(L - gtL,'fro')/norm(gtL,'fro')
    ladmg_rel_err_E = norm(E - gtE,'fro')/norm(gtE,'fro')
end

if doLADMPS
    disp('LADMPS is running ...')

    ladmps_ts = tic; 
    [Z, L, E, Out] = ladmps_latlrr(X, lambda, opts, gt);
    ladmps_tf = toc(ladmps_ts)

    ladmps_result{i} = comp_result(Z, L, E, Out, ...
        Z0, L0, E0, ind, nGroup);

    ladmps_rec_err = norm(X*Z+L*X+E-X,'fro')/norm(X,'fro')
%     S_Z = svd(Z,'econ');
%     S_L = svd(L,'econ');
%     ladmps_obj_val = sum(S_Z) + sum(S_L) + lambda*sum(sum(abs(E)))

    ladmps_rel_err_Z = norm(Z - gtZ,'fro')/norm(gtZ,'fro')
    ladmps_rel_err_L = norm(L - gtL,'fro')/norm(gtL,'fro')
    ladmps_rel_err_E = norm(E - gtE,'fro')/norm(gtE,'fro')
end

if doLADMPSAP
    disp('LADMPSAP is running ...')
    

    ladmpsap_ts = tic; 
    [Z, L, E, Out] = ladmpsap_latlrr(X, lambda, opts, gt);
    ladmpsap_tf = toc(ladmpsap_ts)

    plot(Out.mus)
    Out.rho_i

    ladmpsap_result{i} = comp_result(Z, L, E, Out, ...
        Z0, L0, E0, ind, nGroup);  

    ladmpsap_rec_err = norm(X*Z+L*X+E-X,'fro')/norm(X,'fro')
%     S_Z = svd(Z,'econ');
%     S_L = svd(L,'econ');
%     ladmpsap_obj_val = sum(S_Z) + sum(S_L) + lambda*sum(sum(abs(E)))
    
    ladmpsap_rel_err_Z = norm(Z - gtZ,'fro')/norm(gtZ,'fro')
    ladmpsap_rel_err_L = norm(L - gtL,'fro')/norm(gtL,'fro')
    ladmpsap_rel_err_E = norm(E - gtE,'fro')/norm(gtE,'fro')
    
end


end

if doAPG
    m_apg = comp_m_result(apg_result, num)
end
if doADM
    m_adm = comp_m_result(adm_result, num)
end
if doLADM
    m_ladm = comp_m_result(ladm_result, num)
end
if doLADMG
    m_ladmg = comp_m_result(ladmg_result, num)
end
if doLADMPS
    m_ladmps = comp_m_result(ladmps_result, num)
end
if doLADMPSAP
    m_ladmpsap = comp_m_result(ladmpsap_result, num)
end

if doSave
    r_fn = strcat('latlrr_result_', d_inf, '.mat');
    save(r_fn, 'apg_result','adm_result', 'ladm_result',...
        'ladmg_result', 'ladmps_result', 'ladmpsap_result');
    mr_fn = strcat('latlrr_m_result_', d_inf, '.mat');
    save(mr_fn, 'm_apg','m_adm', 'm_ladm',...
        'm_ladmg', 'm_ladmps', 'm_ladmpsap');
end

r_fn = strcat('latentlrr_result_', d_inf, '.mat');
save(r_fn, 'apg_tf','apg_rec_err','apg_rel_err_Z', 'apg_rel_err_L','apg_rel_err_E',...
        'adm_tf','adm_rec_err','adm_rel_err_Z', 'adm_rel_err_L','adm_rel_err_E',...
        'ladm_tf','ladm_rec_err','ladm_rel_err_Z', 'ladm_rel_err_L','ladm_rel_err_E',...        
        'ladmg_tf','ladmg_rec_err','ladmg_rel_err_Z', 'ladmg_rel_err_L','ladmg_rel_err_E',...
        'ladmps_tf','ladmps_rec_err','ladmps_rel_err_Z', 'ladmps_rel_err_L','ladmps_rel_err_E',...
        'ladmpsap_tf','ladmpsap_rec_err','ladmpsap_rel_err_Z', 'ladmpsap_rel_err_L','ladmpsap_rel_err_E');
    