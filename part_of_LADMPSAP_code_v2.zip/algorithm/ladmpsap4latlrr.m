function [Z,L,E] = ladmpsap4latlrr(X,lambda,opts)
% This matlab code implements linearized ADM with parallel splting and adaptive penalty (LADMPSAP) method for Lattent LRR problem
%------------------------------
% min |Z|_*+|L|_*+lambda*|E|_1
% s.t., X = XZ+LX+E
%--------------------------------
% Output:
%          Z -- n * n representation matrix
%          E -- d * n sparse matrix
%        Out -- output information
% Input: 
%         X -- d * n data matrix
%    lambda -- regularization parameter
%       opt -- option structure with fields: rho, DEBUG
%
% created by Zhouchen Lin on 05/31/2011, zlin@pku.edu.cn
%
% set parameters
[d, n] = size(X);
normfX = norm(X, 'fro');
norm2X = norm(X, 2);

tol_chg = 1e-4; %threshold for the change in the solutions
tol_err = 1e-4; %threshold for the error in constraint
max_iter = 500;

beta = norm2X*min(d, n)*tol_chg;
nv = 3;
etaE = nv*1.02;
eta = norm2X*norm2X*etaE; %eta needs to be larger than n||X||_2^2, but need not be too large.
rho = 10;
gamma = 1.0;

DEBUG = 1;

if ~exist('opts', 'var')
    opts = [];
end
    
if isfield(opts, 'tol_chg')        tol_chg = opts.tol_chg;         end
if isfield(opts, 'tol_err')        tol_err = opts.tol_err;         end
if isfield(opts, 'max_iter')       max_iter = opts.max_iter;       end
if isfield(opts, 'rho')            rho = opts.rho;                 end
% if isfield(opts, 'beta')             mu = opts.beta;                   end
if isfield(opts, 'beta_max')         max_mu = opts.beta_max;           end
if isfield(opts, 'eta')            eta = opts.eta;                 end
if isfield(opts, 'DEBUG')          DEBUG = opts.DEBUG;             end

%% 
% initialzie
Z = zeros(n);
L = zeros(d);
E = zeros(d,n);
Y = zeros(d,n);

XZ = zeros(d, n);%XZ = X*Z;
LX = zeros(d, n);%LX = L*X;


%%
% start main iteration
iter = 0;
converged = 0;
ts = tic; 
while iter < max_iter 
    iter = iter + 1;

    Y_hat = Y + beta*(XZ + LX + E - X);
    
    Zk = Z;
    Lk = L;
    Ek = E;
    Yk = Y;
    betak = beta;
    
    temp = Z - X'*Y_hat/(beta*eta);
    [U,S,V] = svd(temp, 'econ');
    S = diag(S);
    r_Z = length(find(S > 1/(beta*eta)));
    if r_Z >= 1    
        S = S(1:r_Z) - 1/(beta*eta);
        Z = U(:,1:r_Z)*diag(S)*(V(:,1:r_Z))';
    else
        Z = zeros(n);
    end
    XZ = X*Z;
    
    temp = L - Y_hat*X'/(beta*eta);
    [U,S,V] = svd(temp, 'econ');
    S = diag(S);
    r_L = length(find(S > 1/(beta*eta)));
    if r_L >= 1
        S = S(1:r_L) - 1/(beta*eta);
        L = U(:,1:r_L)*diag(S)*(V(:,1:r_L))';
    else
        L = zeros(d);
    end
    LX = L*X;
    
    temp = E - Y_hat/(beta*etaE);
    E = sign(temp).*max(abs(temp) - lambda/(beta*etaE), 0);
    
    dY = XZ + LX + E - X;
    Y = Y + beta*dY;
    
    feas_err = norm(dY, 'fro')/normfX;

    chg_Z = norm(Z - Zk, 'fro')/normfX;
    chg_L = norm(L - Lk, 'fro')/normfX;
    chg_E = norm(E - Ek, 'fro')/normfX;
    
    dual_err = max([chg_Z chg_L chg_E]);
    
    
    if beta*dual_err < tol_chg
        beta = beta*rho;
    end
    
    if feas_err < tol_err && dual_err < tol_chg
        converged = 1;
    end
    
    if iter == 1 || mod(iter, 50) == 0 || converged
        disp(['iter ' num2str(iter) ', beta=' num2str(beta) ...
            ', dual_err=' num2str(dual_err)...
            ', feas_err=' num2str(feas_err)]);
    end
    if converged == 1
        break;
    end   
    

%     XZk = X*Zk;
%     LkX = Lk*X;
%     
%     laY = Yk + betak*(XZk + LkX + Ek - X);    
%     
%     % update Z
%     temp = Zk - X'*laY/(betak*eta);
%     [U, S, V] = svd(temp,'econ');      
%     S = diag(S);
%     svpZ = length(find(S > 1/(betak*eta)));
%     if svpZ>=1
%         S = S(1:svpZ)-1/(betak*eta);
%     else
%         svpZ = 1;
%         S = 0;
%     end
%     U = U(:, 1:svpZ);
%     V = V(:, 1:svpZ);  
%     ZZ = U*diag(S)*V';   
%     
%     % update L     
%     temp = Lk - laY*X'/(betak*eta);
%     [U, S, V] = svd(temp,'econ');      
%     S = diag(S);
%     svpL = length(find(S > 1/(betak*eta)));
%     if svpL>=1
%         S = S(1:svpL)-1/(betak*eta);
%     else
%         svpL = 1;
%         S = 0;
%     end
%     U = U(:, 1:svpL);
%     V = V(:, 1:svpL);  
%     LL = U*diag(S)*V';
%     
%     % update E   
%     temp = Ek - laY/(betak*etaE);
%     EE = max(0,temp - lambda/(betak*etaE))+min(0,temp + lambda/(betak*etaE));
% 
%     if max([norm(Z - ZZ,'fro') norm(L - LL,'fro') norm(E - EE,'fro')]) > 1e-5
%         error('error!\n');
%     end
end
tf = toc(ts);

