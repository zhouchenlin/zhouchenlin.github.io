function [Z,L,E,Out] = ladm_latlrr(X,lambda,opts, gt)
% This matlab code implements linearized ADM method for LatLRR problem
%------------------------------
% min |Z|_*+|L|_*+lambda*|E|_2,1
% s.t., X = XZ+LX+E
%--------------------------------
% Output:
%          Z -- n * n representation matrix
%          E -- d * n sparse matrix
%        Out -- output information
% Input: 
%         X -- d * n data matrix
%    lambda -- regularization parameter
%       opt -- option structure with fields: rho, DEBUG
%
% created by Risheng Liu on 05/02/2011, rsliu0705@gmail.com
%
%%

% set parameters
[d, n] = size(X);
normfX = norm(X, 'fro');
norm2X = norm(X, 2);

tol_chg = 1e-4; %threshold for the change in the solutions
tol_err = 1e-4; %threshold for the error in constraint
max_iter = 500;

% mu = norm2X*min(d, n)*tol_chg;
%mu = 2.5*3/min(d, n);% for 5
% mu = 2.5*4/min(d, n);% for 10 and 20 data
mu = 2.5/min(d, n);

eta = norm2X*norm2X*1.02; %eta needs to be larger than ||X||_2^2, but need not be too large.
DEBUG = 1;

if ~exist('opts', 'var')
    opts = [];
end
    
if isfield(opts, 'tol_chg')        tol_chg = opts.tol_chg;         end
if isfield(opts, 'tol_err')        tol_err = opts.tol_err;         end
if isfield(opts, 'max_iter')       max_iter = opts.max_iter;       end
if isfield(opts, 'rho')            rho = opts.rho;                 end
% if isfield(opts, 'mu')             mu = opts.mu;                   end
if isfield(opts, 'eta')            eta = opts.eta;                 end
if isfield(opts, 'DEBUG')          DEBUG = opts.DEBUG;             end

%% 
% initialzie
Z = zeros(n);
L = zeros(d);
E = sparse(d,n);
Y = zeros(d,n);

XZ = zeros(d, n);%XZ = X*Z;
LX = zeros(d, n);

sv = min(d,n)/20;
% sv = 5;
svp = sv;

% opt_svd.tol = tol_chg;

rel_chg_Zs = [];
rel_chg_Ls = [];
rel_chg_Es = [];

%--------------------------------
gt_rel_err_Zs = [];
gt_rel_err_Ls = [];
gt_rel_err_Es = [];
gt_normZ = norm(gt.Z,'fro');
gt_normL = norm(gt.L,'fro');
gt_normE = norm(gt.E,'fro');
%------------------------------

rec_errs = [];

r_Zs = [];
r_Ls = [];
l0n_Es = [];

% kn_Zs = [];
% kn_Ls = [];
% l1n_Es = [];

%%
% start main iteration
iter = 0;
convergenced = 0;
ts = tic; 
while iter < max_iter
    iter = iter + 1;

    Zk = Z;
    Lk = L;
    Ek = E;
    
    % update E
    temp = E - (XZ + LX + E - X + Y/mu);
    E = max(0,temp - lambda/mu)+min(0,temp + lambda/mu);
    
    % update Z
    temp = Z - X'*(XZ + LX + E - X + Y/mu)/eta;
    %opt_svd.p0 = ones(n, 1);
    %[U, S, V] = lansvd(temp, n, n, sv, 'L', opt_svd);
    [U, S, V] = svd(temp,'econ');      
    S = diag(S);
    svp = length(find(S>1/(mu*eta)));
%     if svp < sv
%         sv = min(svp + 1, n);
%     else
%         sv = min(svp + round(0.05*n), n);
%     end    
    if svp>=1
        S = S(1:svp)-1/(mu*eta);
    else
        svp = 1;
        S = 0;
    end
    U = U(:, 1:svp);
    V = V(:, 1:svp);  
    Z = U*diag(S)*V';  
%     rZ = svp;
%     knZ = sum(S);
    XZ = X*Z;
    
    % update L
    temp = L - (XZ + LX + E - X + Y/mu)*X'/eta;
    %opt_svd.p0 = ones(d, 1);
    %[U, S, V] = lansvd(temp, d, d, sv, 'L', opt_svd);
    [U, S, V] = svd(temp,'econ');      
    S = diag(S);
    svp = length(find(S > 1/(mu*eta)));
%     if svp < sv
%         sv = min(svp + 1, d);
%     else
%         sv = min(svp + round(0.05*n), d);
%     end    
    if svp>=1
        S = S(1:svp)-1/(mu*eta);
    else
        svp = 1;
        S = 0;
    end
    U = U(:, 1:svp);
    V = V(:, 1:svp);  
    L = U*diag(S)*V';
%     rL = svp;
%     knL = sum(S);
    LX = L*X;
    
    %[rZ, knZ, rL, knL, l0E, l1E] = comp_est(Zkp1, Lkp1, Ekp1);
    [rZ, rL, l0E] = comp_est(Z, L, E);

    r_Zs = [r_Zs, rZ];
    r_Ls = [r_Ls, rL];
    l0n_Es = [l0n_Es, l0E];
    
%     kn_Zs = [kn_Zs, knZ];
%     kn_Ls = [kn_Ls, knL];
%     l1n_Es = [l1n_Es, l1E];
    
    diffE = norm(Ek - E, 'fro');
    diffL = norm(Lk - L,'fro');
    diffZ = norm(Zk - Z,'fro');
       
    rel_chg_Z = diffZ/normfX;
    rel_chg_Zs = [rel_chg_Zs, rel_chg_Z];
    
    rel_chg_L = diffL/normfX;
    rel_chg_Ls = [rel_chg_Ls, rel_chg_L];
    
    rel_chg_E = diffE/normfX;
    rel_chg_Es = [rel_chg_Es, rel_chg_E];
        
    rel_chg = max(rel_chg_Z, rel_chg_L);
    rel_chg = max(rel_chg, rel_chg_E);
    
    %------------------------
    gt_rel_err_Z = norm(Z-gt.Z,'fro')/gt_normZ;
    gt_rel_err_Zs = [gt_rel_err_Zs,gt_rel_err_Z];
    gt_rel_err_L = norm(L-gt.L,'fro')/gt_normL;
    gt_rel_err_Ls = [gt_rel_err_Ls,gt_rel_err_L];
    gt_rel_err_E = norm(E-gt.E,'fro')/gt_normE;
    gt_rel_err_Es = [gt_rel_err_Es,gt_rel_err_E];
    %------------------------

    dY =  XZ + LX + E - X;
    rec_err = norm(dY, 'fro')/normfX;
    rec_errs = [rec_errs, rec_err];
    
    convergenced = rel_chg < tol_chg && rec_err < tol_err;
    
    if DEBUG       
        if iter == 1 || mod(iter, 50) == 0 || convergenced 
            disp(['iter ' num2str(iter) ', mu=' num2str(mu) ...
                ', rank(Z)=' num2str(rZ) ', rank(L)=' num2str(rL)...
                ', rel_chg=' num2str(rel_chg)...
                ', rec_err=' num2str(rec_err)]);
        end
    end
    if convergenced
        break;
    else
        Y = Y + mu*dY;
    end
end
tf = toc(ts);

Out.rel_chg_Z = rel_chg_Zs;
Out.rel_chg_L = rel_chg_Ls;
Out.rel_chg_E = rel_chg_Es;
Out.rec_err = rec_errs;

%-------------------
Out.gt_rel_err_Z = gt_rel_err_Zs;
Out.gt_rel_err_L = gt_rel_err_Ls;
Out.gt_rel_err_E = gt_rel_err_Es;
%-------------------


Out.r_Zs = r_Zs;
Out.r_Ls = r_Ls;
Out.l0n_Es = l0n_Es;

% Out.kn_Zs = kn_Zs;
% Out.kn_Ls = kn_Ls;
% Out.l1n_Es = l1n_Es;

Out.iter = iter;
Out.cputime = tf;