function [Z,L,E] = ladmpsap4latlrr_gt(X,lambda)
% This matlab code implements linearized ADM with parallel splting and adaptive penalty (LADMPSAP) method for Lattent LRR problem
% It produces the ground truth optimal solution by using smaller thresholds
% and more iterations.
% %------------------------------
% min |Z|_*+|L|_*+lambda*|E|_1
% s.t., X = XZ+LX+E
%--------------------------------
% Output:
%          Z -- n * n representation matrix
%          E -- d * n sparse matrix
%        Out -- output information
% Input: 
%         X -- d * n data matrix
%    lambda -- regularization parameter
%
% created by Zhouchen Lin on 05/31/2011, zlin@pku.edu.cn
%
% set parameters
[d, n] = size(X);
normfX = norm(X, 'fro');
norm2X = norm(X, 2);

tol_chg = 1e-6; %threshold for the change in the solutions
tol_err = 1e-8; %threshold for the error in constraint
max_iter = 3000;

beta = norm2X*min(d, n)*tol_chg;
nv = 3;
etaE = nv*1.02;
eta = norm2X*norm2X*etaE; %eta needs to be larger than n||X||_2^2, but need not be too large.
rho = 10;
gamma = 1.0;

DEBUG = 1;

%% 
% initialzie
Z = zeros(n);
L = zeros(d);
E = zeros(d,n);
Y = zeros(d,n);

XZ = zeros(d, n);%XZ = X*Z;
LX = zeros(d, n);%LX = L*X;


%%
% start main iteration
iter = 0;
converged = 0;
ts = tic; 
while iter < max_iter 
    iter = iter + 1;

    Y_hat = Y + beta*(XZ + LX + E - X);
    
    Zk = Z;
    Lk = L;
    Ek = E;
    
    temp = Z - X'*Y_hat/(beta*eta);
    [U,S,V] = svd(temp, 'econ');
    S = diag(S);
    r_Z = length(find(S > 1/(beta*eta)));
    if r_Z >= 1    
        S = S(1:r_Z) - 1/(beta*eta);
        Z = U(:,1:r_Z)*diag(S)*(V(:,1:r_Z))';
    else
        Z = zeros(n);
    end
    XZ = X*Z;
    
    temp = L - Y_hat*X'/(beta*eta);
    [U,S,V] = svd(temp, 'econ');
    S = diag(S);
    r_L = length(find(S > 1/(beta*eta)));
    if r_L >= 1
        S = S(1:r_L) - 1/(beta*eta);
        L = U(:,1:r_L)*diag(S)*(V(:,1:r_L))';
    else
        L = zeros(d);
    end
    LX = L*X;
    
    temp = E - Y_hat/(beta*etaE);
    E = sign(temp).*max(abs(temp) - lambda/(beta*etaE), 0);
    E2 = max(0,temp - lambda/(beta*etaE))+min(0,temp + lambda/(beta*etaE));
    
    if norm(E - E2,'fro') > 1e-6
        error('wrong soft thresholding!\n');
    end
    
    dY = XZ + LX + E - X;
    Y = Y + beta*dY;
    
    feas_err = norm(dY, 'fro')/normfX;

    chg_Z = norm(Z - Zk, 'fro')/normfX;
    chg_L = norm(L - Lk, 'fro')/normfX;
    chg_E = norm(E - Ek, 'fro')/normfX;
    
    dual_err = max([chg_Z chg_L chg_E]);
    
    
    if beta*dual_err < tol_chg
        beta = beta*rho;
    end
    
    if feas_err < tol_err && dual_err < tol_chg
        converged = 1;
    end
    
    if iter == 1 || mod(iter, 50) == 0 || converged
        disp(['iter ' num2str(iter) ', beta=' num2str(beta) ...
            ', dual_err=' num2str(dual_err)...
            ', feas_err=' num2str(feas_err)]);
    end
    if converged == 1
        break;
    end   
end
tf = toc(ts);

