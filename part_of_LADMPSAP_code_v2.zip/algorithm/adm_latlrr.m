function [Z,L,E,Out] = adm_latlrr(X, lambda, opts, gt)
%LATLRR Summary of this function goes here
%   Detailed explanation goes here
% This routine solves the optmization problem of Latent-LRR (noisy model)
% min |Z|_* + alpha*|L|_* + beta*|E|_1
% s.t., X = XZ + LX + E  
% inputs:
%        X -- D*N data matrix, D is the data dimension, and N is the number
%             of data vectors.
%        alpha -- usually alpha = 1
%        beta  -- this parameter depends on the noise level of data


rho = 1.1;
alpha = 1.0;
if nargin < 2
    beta = 1.0;
else
    beta = lambda;
end

%% 
tol_chg = 1e-4;
tol_err = 1e-4;
max_iter = 500;
[d n] = size(X);
normfX = norm(X, 'fro');
max_mu = 1e30;
mu = 1e-6;
DEBUG = 1;

if ~exist('opts', 'var')
    opts = [];
end
if isfield(opts, 'tol_chg')        tol_chg = opts.tol_chg;   end       
if isfield(opts, 'tol_err')        tol_err = opts.tol_err;   end       
if isfield(opts, 'max_iter')       max_iter = opts.max_iter; end 
if isfield(opts, 'rho')            rho = opts.rho; end
if isfield(opts, 'alpha')          alpha = opts.alpha; end
if isfield(opts, 'DEBUG')          DEBUG = opts.DEBUG; end

xtx = X'*X;
xxt = X*X';
inv_xtx = inv(xtx+eye(n));
inv_xxt = inv(xxt+eye(d));
%% Initializing optimization variables
% intialize
J = zeros(n);
Z = zeros(n);
S = zeros(d);
L = zeros(d);
E = sparse(d,n);

Y1 = zeros(d,n);
Y2 = zeros(n);
Y3 = zeros(d);

sv = min(d,n)/20;
% sv = 5;
svp = sv;

opt_svd.tol = tol_chg;

rel_chg_Zs = [];
rel_chg_Ls = [];
rel_chg_Es = [];

%--------------------------------
gt_rel_err_Zs = [];
gt_rel_err_Ls = [];
gt_rel_err_Es = [];
gt_normZ = norm(gt.Z,'fro');
gt_normL = norm(gt.L,'fro');
gt_normE = norm(gt.E,'fro');
%------------------------------

rec_errs = [];

r_Zs = [];
r_Ls = [];
l0n_Es = [];

% kn_Zs = [];
% kn_Ls = [];
% l1n_Es = [];


%% Start main loop
iter = 0;
convergenced = 0;
if DEBUG
    disp(['initial,r(Z)=' num2str(rank(J)) ',r(L)=' num2str(rank(L)) ',|E|_1=' num2str(sum(sum(abs(E))))]);
end
ts = tic;
while iter<max_iter
    iter = iter + 1;
    
    Zk = Z;
    Lk = L;
    Ek = E;
    
    %update J
    temp = Z + Y2/mu;
    [U,sigma,V] = svd(temp,'econ');
    %opt_svd.p0 = ones(n, 1);
    %[U, sigma, V] = lansvd(temp, n, n, sv, 'L', opt_svd);
    sigma = diag(sigma);
    svp = length(find(sigma > 1/mu));
%     if svp < sv
%         sv = min(svp + 1, n);
%     else
%         sv = min(svp + round(0.05*n), n);
%     end
    if svp>=1
        sigma = sigma(1:svp) - 1/mu;
    else
        svp = 1;
        sigma = 0;
    end
    J = U(:,1:svp)*diag(sigma)*V(:,1:svp)';
%     rZ = svp; %rank(J);
    
    %update S
    temp = L + Y3/mu;
    [U,sigma,V] = svd(temp,'econ');
    %opt_svd.p0 = ones(d, 1);
    %[U, sigma, V] = lansvd(temp, d, d, sv, 'L', opt_svd);
    sigma = diag(sigma);
    svp = length(find(sigma > 1/mu));
%     if svp < sv
%         sv = min(svp + 1, n);
%     else
%         sv = min(svp + round(0.05*n), n);
%     end
    if svp>=1
        sigma = sigma(1:svp) - 1/mu;
    else
        svp = 1;
        sigma = 0;
    end
    S = U(:,1:svp)*diag(sigma)*V(:,1:svp)';
%     rL = svp; %rank(S);
    
    %udpate Z
    Z = inv_xtx*(xtx-X'*L*X-X'*E+J+(X'*Y1-Y2)/mu);
    
    %update L
    L = (xxt-X*Z*X'-E*X'+S+(Y1*X'-Y3)/mu)*inv_xxt; 
    
    %update E
    temp = X-X*Z-L*X+Y1/mu;
    E = max(0,temp - beta/mu)+min(0,temp + beta/mu);
    
    %[rZ, knZ, rL, knL, l0E, l1E] = comp_est(Zkp1, Lkp1, Ekp1);
    [rZ, rL, l0E] = comp_est(Z, L, E);

    r_Zs = [r_Zs, rZ];
    r_Ls = [r_Ls, rL];
    l0n_Es = [l0n_Es, l0E];
    
%     kn_Zs = [kn_Zs, knZ];
%     kn_Ls = [kn_Ls, knL];
%     l1n_Es = [l1n_Es, l1E];
    
    diffE = norm(Ek - E, 'fro');
    diffZ = norm(Zk - Z,'fro');
    diffL = norm(Lk - L,'fro');
    
    rel_chg_Z = diffZ/normfX;
    rel_chg_Zs = [rel_chg_Zs, rel_chg_Z];
    
    rel_chg_L = diffL/normfX;
    rel_chg_Ls = [rel_chg_Ls, rel_chg_L];
    
    rel_chg_E = diffE/normfX;
    rel_chg_Es = [rel_chg_Es, rel_chg_E];
    
    rel_chg = max(rel_chg_Z, rel_chg_L);
    rel_chg = max(rel_chg, rel_chg_E);
    
    %------------------------
    gt_rel_err_Z = norm(Z-gt.Z,'fro')/gt_normZ;
    gt_rel_err_Zs = [gt_rel_err_Zs,gt_rel_err_Z];
    gt_rel_err_L = norm(L-gt.L,'fro')/gt_normL;
    gt_rel_err_Ls = [gt_rel_err_Ls,gt_rel_err_L];
    gt_rel_err_E = norm(E-gt.E,'fro')/gt_normE;
    gt_rel_err_Es = [gt_rel_err_Es,gt_rel_err_E];
    %------------------------
    
    convergenced = rel_chg < tol_chg && rec_err < tol_err;
    
    %update the multiplies
    leq1 = X-X*Z-L*X-E;
    leq2 = Z-J;
    leq3 = L-S;
    %stopC = max(max(max(abs(leq1))),max(max(abs(leq2))));
    %stopC = max(max(max(abs(leq3))),stopC);
    
    rec_err = norm(leq1, 'fro')/normfX;
    rec_errs = [rec_errs, rec_err];
    
    if DEBUG
        if iter == 1 || mod(iter, 50) == 0 || convergenced 
            disp(['iter ' num2str(iter) ', mu=' num2str(mu) ...
                ', rank(Z)=' num2str(rZ) ', rank(L)=' num2str(rL)...
                ', rel_chg=' num2str(rel_chg)...
                ', rec_err=' num2str(rec_err)]);
        end
    end
    if convergenced
        break;
    else
        Y1 = Y1 + mu*leq1;
        Y2 = Y2 + mu*leq2;
        Y3 = Y3 + mu*leq3;
        mu = min(max_mu,mu*rho);
    end
end
tf = toc(ts);

Out.rel_chg_Z = rel_chg_Zs;
Out.rel_chg_L = rel_chg_Ls;
Out.rel_chg_E = rel_chg_Es;
Out.rec_err = rec_errs;

%-------------------
Out.gt_rel_err_Z = gt_rel_err_Zs;
Out.gt_rel_err_L = gt_rel_err_Ls;
Out.gt_rel_err_E = gt_rel_err_Es;
%-------------------

Out.r_Zs = r_Zs;
Out.r_Ls = r_Ls;
Out.l0n_Es = l0n_Es;

% Out.kn_Zs = kn_Zs;
% Out.kn_Ls = kn_Ls;
% Out.l1n_Es = l1n_Es;

Out.iter = iter;
Out.cputime = tf;
