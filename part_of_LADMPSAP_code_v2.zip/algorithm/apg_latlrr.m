function [Z, L, E, Out] = apg_latlrr(X,lambda,opts, gt)
%------------------------------
% min |Z|_*+|L|_*+lambda*|E|_2,1
% s.t., X = XZ+LX+E
%--------------------------------
% Output:
%          Z -- n * n representation matrix
%          E -- d * n sparse matrix
%        Out -- output information
% Input: 
%         X -- d * n data matrix
%    lambda -- regularization parameter
%       opt -- option structure with fields: rho, DEBUG
%         of data vectors.

%%
% set parameters
% addpath PROPACK;

[d, n] = size(X);
normfX = norm(X,'fro');

tol_chg = 1e-4; %threshold for the change in the solutions
tol_err = 1e-4; %threshold for the error in constraint
max_iter = 500;

DEBUG = 1;

%rho = 0.97;
rho = 0.9;
% mu = 1/norm(X,2);
mu = norm(X,2);
min_mu = 1e-10;

if ~exist('opts', 'var')
    opts = [];
end
    
if isfield(opts, 'tol_chg')        tol_chg = opts.tol_chg;         end
if isfield(opts, 'tol_err')        tol_err = opts.tol_err;         end
if isfield(opts, 'max_iter')       max_iter = opts.max_iter;        end
if isfield(opts, 'rho')            rho = opts.rho;                 end
% if isfield(opts, 'mu')             mu = opts.mu;                   end
if isfield(opts, 'min_mu')         min_mu = opts.min_mu;           end
if isfield(opts, 'DEBUG')          DEBUG = opts.DEBUG;             end



tk=1; tkm1=tk;
norm2X = norm(X,2);
tau0 = 3*norm2X*norm2X*1.01; % Lipschitz constant
tau = tau0;

%%
% initialzie
Zk = zeros(n,n);
Zkm1 = Zk;
Lk = zeros(d,d);
Lkm1 = Lk;
Ek = sparse(d,n);
Ekm1 = Ek;

sv = min(d,n)/20;
% sv = 5;
svp = sv;

% option structure for parital SVD
% opt_svd.tol = tol_chg;
% opt_svd.p0 = ones(n, 1);

rel_chg_Zs = [];
rel_chg_Ls = [];
rel_chg_Es = [];
rec_errs = [];

%--------------------------------
gt_rel_err_Zs = [];
gt_rel_err_Ls = [];
gt_rel_err_Es = [];
gt_normZ = norm(gt.Z,'fro');
gt_normL = norm(gt.L,'fro');
gt_normE = norm(gt.E,'fro');
%------------------------------

r_Zs = [];
r_Ls = [];
l0n_Es = [];

% kn_Zs = [];
% kn_Ls = [];
% l1n_Es = [];

%%
% start main iteration
iter = 0;
convergenced = 0;

ts = tic;
while iter < max_iter
    iter = iter + 1;
    
    Eb = Ek + ((tkm1-1)/tk)*(Ek-Ekm1);
    Zb = Zk + ((tkm1-1)/tk)*(Zk-Zkm1);
    Lb = Lk + ((tkm1-1)/tk)*(Lk-Lkm1);
    
    tmp = X*Zb + Lb*X + Eb - X;
    %tmp = X*Zb +  Eb - X;
    
    Ge = Eb - (1/tau)*tmp;
    Gz = Zb - (1/tau)*X'*tmp;
    Gl = Lb - (1/tau)*tmp*X';
    
    %Ekp1 = solve_l1l2(Ge, lambda*mu/tau);
    Ekp1 = max(0,Ge - lambda*mu/tau)+min(0,Ge + lambda*mu/tau);
    
    [U,S,V] = svd(Gz,'econ');
    %[U,S,V] = lansvd(Gz,n,n, sv, 'L',opt_svd);
    S = diag(S);
    svp = length(find(S > mu/tau));
%     if svp < sv
%         sv = min(svp + 1, n);
%     else
%         sv = min(svp + round(0.05*n), n);
%     end
    
    if svp>=1
        S = S(1:svp) - mu/tau;
    else
        svp = 1;
        S = 0;
    end
    Zkp1 = U(:,1:svp)*diag(S)*V(:,1:svp)';
%     rZ = svp;
%     knZ = sum(S);
    
    [U,S,V] = svd(Gl,'econ');
    %[U,S,V] = lansvd(Gl,d,d, sv, 'L',opt_svd);
    S = diag(S);
    svp = length(find(S > mu/tau));
%     if svp < sv
%         sv = min(svp + 1, n);
%     else
%         sv = min(svp + round(0.05*n), n);
%     end
    
    if svp>=1
        S = S(1:svp) - mu/tau;
    else
        svp = 1;
        S = 0;
    end
    Lkp1 = U(:,1:svp)*diag(S)*V(:,1:svp)';
%     rL = svp;
%     knL = sum(S);
    
    %[rZ, knZ, rL, knL, l0E, l1E] = comp_est(Zkp1, Lkp1, Ekp1);
    [rZ, rL, l0E] = comp_est(Zkp1, Lkp1, Ekp1);

    r_Zs = [r_Zs, rZ];
    r_Ls = [r_Ls, rL];
    l0n_Es = [l0n_Es, l0E];
    
%     kn_Zs = [kn_Zs, knZ];
%     kn_Ls = [kn_Ls, knL];
%     l1n_Es = [l1n_Es, l1E];


    tkp1 = 0.5*(1+sqrt(4*tkm1*tkm1+1));
    
    rel_chg_Z = norm(Zkp1-Zk,'fro')/normfX;
    rel_chg_Zs = [rel_chg_Zs, rel_chg_Z];
    rel_chg_L = norm(Lkp1-Lk,'fro')/normfX;
    rel_chg_Ls = [rel_chg_Ls, rel_chg_L];
    rel_chg_E = norm(Ekp1-Ek,'fro')/normfX;
    rel_chg_Es = [rel_chg_Es, rel_chg_E];
    rel_chg = max(rel_chg_Z, rel_chg_E);
    rel_chg = max(rel_chg_Z, rel_chg_L);
    
    %------------------------
    gt_rel_err_Z = norm(Zkp1-gt.Z,'fro')/gt_normZ;
    gt_rel_err_Zs = [gt_rel_err_Zs,gt_rel_err_Z];
    gt_rel_err_L = norm(Lkp1-gt.L,'fro')/gt_normL;
    gt_rel_err_Ls = [gt_rel_err_Ls,gt_rel_err_L];
    gt_rel_err_E = norm(Ekp1-gt.E,'fro')/gt_normE;
    gt_rel_err_Es = [gt_rel_err_Es,gt_rel_err_E];
    %------------------------    
    
    leq = X - X*Zkp1 - Lkp1*X - Ekp1;
    %leq = X - X*Zkp1 - Ekp1;
    rec_err = norm(leq,'fro')/normfX;
    rec_errs = [rec_errs, rec_err];
    
    convergenced = rel_chg < tol_chg && rec_err < tol_err;
    
    if DEBUG       
        if iter == 1 || mod(iter, 50) == 0 || convergenced 
            disp(['iter ' num2str(iter) ', mu=' num2str(mu) ...
                ', rank(Z)=' num2str(rZ)  ', rank(L)=' num2str(rL)...
                ', rel_chg=' num2str(rel_chg) ', rec_err=' num2str(rec_err)]);
        end
    end
    
    tkm1 = tk; tk = tkp1;
    Ekm1 = Ek; Ek = Ekp1;
    Zkm1 = Zk; Zk = Zkp1;
    Lkm1 = Lk; Lk = Lkp1;
        
    if convergenced
        break;
    else
        mu = max(min_mu,mu*rho);
    end
end
L = Lk;
Z = Zk;
E = Ek;

tf = toc(ts);

Out.rel_chg_Z = rel_chg_Zs;
Out.rel_chg_L = rel_chg_Ls;
Out.rel_chg_E = rel_chg_Es;
Out.rec_err = rec_errs;

%-------------------
Out.gt_rel_err_Z = gt_rel_err_Zs;
Out.gt_rel_err_L = gt_rel_err_Ls;
Out.gt_rel_err_E = gt_rel_err_Es;
%-------------------

Out.r_Zs = r_Zs;
Out.r_Ls = r_Ls;
Out.l0n_Es = l0n_Es;

% Out.kn_Zs = kn_Zs;
% Out.kn_Ls = kn_Ls;
% Out.l1n_Es = l1n_Es;

Out.iter = iter;
Out.cputime = tf;