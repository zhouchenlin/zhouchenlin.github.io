function [Z,L,E] = ladmps_gt_latlrr(X,lambda)
% This matlab code implements linearized ADM method for LRR problem
%------------------------------
% min |Z|_*+|L|_*+lambda*|E|_2,1
% s.t., X = XZ+LX+E
%--------------------------------
% Output:
%          Z -- n * n representation matrix
%          E -- d * n sparse matrix
%        Out -- output information
% Input: 
%         X -- d * n data matrix
%    lambda -- regularization parameter
%       opt -- option structure with fields: rho, DEBUG
%
% created by Risheng Liu on 05/02/2011, rsliu0705@gmail.com
%
%%

% set parameters
[d, n] = size(X);
normfX = norm(X, 'fro');
norm2X = norm(X, 2);

tol_chg = 1e-6; %threshold for the change in the solutions
tol_err = 1e-8; %threshold for the error in constraint
max_iter = 2000;
rho = 10;
%mu = 10*min(d, n)*tol_chg;
mu = norm2X*min(d, n)*tol_chg;
nv = 3;
etaE = nv*1.02;
eta = norm2X*norm2X*etaE; %eta needs to be larger than ||X||_2^2, but need not be too large.

DEBUG = 1;
gamma = 1;

%% 
% initialzie
Z = zeros(n);
L = zeros(d);
E = sparse(d,n);
Y = zeros(d,n);

XZ = zeros(d, n);%XZ = X*Z;
LX = zeros(d, n);

svZ = min(d,n)/20;
svpZ = svZ;
svL = svZ;
svpL = svL;

opt_svd.tol = tol_chg;

rel_chg_Zs = [];
rel_chg_Ls = [];
rel_chg_Es = [];

rec_errs = [];

r_Zs = [];
r_Ls = [];
kn_Zs = [];
kn_Ls = [];
l1n_Es = [];
l0n_Es = [];

%%
% start main iteration
iter = 0;
convergenced = 0;
ts = tic; 
while iter < max_iter
    iter = iter + 1;

    Zk = Z;
    Lk = L;
    Ek = E;
    
    laY = Y + mu*(XZ + LX + E - X);    
    
    % update Z
    temp = Z - X'*laY/(mu*eta);
    %opt_svd.p0 = ones(n, 1);
    %[U, S, V] = lansvd(temp, n, n, svZ, 'L', opt_svd);
    [U, S, V] = svd(temp,'econ');      
    S = diag(S);
    svpZ = length(find(S > 1/(mu*eta)));
%     if svpZ < svZ
%         svZ = min(svpZ + 1, n);
%     else
%         svZ = min(svpZ + round(0.05*n), n);
%     end    
    if svpZ>=1
        S = S(1:svpZ)-1/(mu*eta);
    else
        svpZ = 1;
        S = 0;
    end
    U = U(:, 1:svpZ);
    V = V(:, 1:svpZ);  
    Z = U*diag(S)*V';
    diffZ = norm(Zk - Z,'fro');
    rZ = svpZ;
    knZ = sum(S);
    XZ = X*Z;
    
    % update L     
    temp = L - laY*X'/(mu*eta);
    %opt_svd.p0 = ones(d, 1);
    %[U, S, V] = lansvd(temp, d, d, svL, 'L', opt_svd);
    [U, S, V] = svd(temp,'econ');      
    S = diag(S);
    svpL = length(find(S > 1/(mu*eta)));
%     if svpL < svL
%         svL = min(svpL + 1, d);
%     else
%         svL = min(svpL + round(0.05*n), d);
%     end    
    if svpL>=1
        S = S(1:svpL)-1/(mu*eta);
    else
        svpL = 1;
        S = 0;
    end
    U = U(:, 1:svpL);
    V = V(:, 1:svpL);  
    L = U*diag(S)*V';
    diffL = norm(Lk - L,'fro');
    rL = svpL;
    knL = sum(S);
    LX = L*X; 
    
    % update E   
    temp = E - laY/(mu*etaE);
%    E = max(0,temp - lambda/mu)+min(0,temp + lambda/mu);%Error!!
    E = max(0,temp - lambda/(mu*etaE))+min(0,temp + lambda/(mu*etaE));
    diffE = norm(Ek - E, 'fro');
    
    r_Zs = [r_Zs, rZ];
    r_Ls = [r_Ls, rL];
    kn_Zs = [kn_Zs, knZ];
    kn_Ls = [kn_Ls, knL];
    l1n_Es = [l1n_Es, sum(sum(abs(E)))];
    nz_idx = abs(E)>eps*10;
    l0n_Es = [l0n_Es, sum(nz_idx(:))];
        
    rel_chg_Z = diffZ/normfX;
    rel_chg_Zs = [rel_chg_Zs, rel_chg_Z];
    
    rel_chg_L = diffL/normfX;
    rel_chg_Ls = [rel_chg_Ls, rel_chg_L];
    
    rel_chg_E = diffE/normfX;
    rel_chg_Es = [rel_chg_Es, rel_chg_E];
        
    rel_chg = max(rel_chg_Z, rel_chg_L);
    rel_chg = max(rel_chg, rel_chg_E);

    dY =  XZ + LX + E - X;
    rec_err = norm(dY, 'fro')/normfX;
    rec_errs = [rec_errs, rec_err];
    
    convergenced = rel_chg < tol_chg && rec_err < tol_err;
    
    if DEBUG       
        if iter == 1 || mod(iter, 50) == 0 || convergenced 
            disp(['iter ' num2str(iter) ', mu=' num2str(mu) ...
                ', rank(Z)=' num2str(rZ) ', rank(L)=' num2str(rL)...
                ', rel_chg=' num2str(rel_chg)...
                ', rec_err=' num2str(rec_err)]);
        end
    end
    if convergenced
        break;
    else
        Y = Y + gamma*mu*dY;
%        mu = mu*rho; %Error!!
        if mu*rel_chg < tol_chg
            mu = mu*rho;
        end
    end
end
tf = toc(ts);

Out.rel_chg_Z = rel_chg_Zs;
Out.rel_chg_L = rel_chg_Ls;
Out.rel_chg_E = rel_chg_Es;
Out.rec_err = rec_errs;

Out.r_Zs = r_Zs;
Out.r_Ls = r_Ls;
Out.kn_Zs = kn_Zs;
Out.kn_Ls = kn_Ls;
Out.l1n_Es = l1n_Es;
Out.l0n_Es = l0n_Es;

Out.iter = iter;
Out.cputime = tf;