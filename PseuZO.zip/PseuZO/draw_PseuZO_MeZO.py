import pandas as pd
import json
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

zo_path0 = '/data1/xlyang/zo/result/SST2-opt-1.3b-mezo-ft-10000-16-1e-7-1e-3-0-zo-Gaussian/checkpoint-10000/trainer_state.json'
zo_path1 = '/data1/xlyang/zo/result/SST2-opt-1.3b-mezo-ft-10000-16-1e-7-1e-3-1-zo-Gaussian/checkpoint-10000/trainer_state.json'
zo_path2 = '/data1/xlyang/zo/result/SST2-opt-1.3b-mezo-ft-10000-16-1e-7-1e-3-2-zo-Gaussian/checkpoint-10000/trainer_state.json'
pzo_path0 = '/data1/xlyang/pzo/result/SST2-opt-1.3b-mezo-ft-10000-16-1e-7-1e-3-0-pzo-Gaussian/checkpoint-10000/trainer_state.json'
pzo_path1 = '/data1/xlyang/pzo/result/SST2-opt-1.3b-mezo-ft-10000-16-1e-7-1e-3-1-pzo-Gaussian/checkpoint-10000/trainer_state.json'
pzo_path2 = '/data1/xlyang/pzo/result/SST2-opt-1.3b-mezo-ft-10000-16-1e-7-1e-3-2-pzo-Gaussian/checkpoint-8000/trainer_state.json'
# 读取所有文件
zo_paths = [zo_path0, zo_path1, zo_path2]
pzo_paths = [pzo_path0, pzo_path1, pzo_path2]

zo_data_list = []
pzo_data_list = []

for path in zo_paths:
    with open(path, "r") as f:
        zo_data_list.append(json.load(f))

for path in pzo_paths:
    with open(path, "r") as f:
        pzo_data_list.append(json.load(f))

# 数据预处理函数
def prep(df, loss_col):
    df = df.copy()
    df[loss_col] = pd.to_numeric(df[loss_col], errors="coerce")
    df = df.dropna(subset=[loss_col])
    df = df[df[loss_col] != 0]
    df = df.sort_values("epoch")
    return df

# 平滑函数
def smooth_including_self(s, half_window=50):
    w = 2 * half_window + 1
    return s.rolling(window=w, center=True, min_periods=1).mean()

# 计算多个seed的平均loss（不做插值，只使用完全相同的epoch点）
def compute_average_loss(data_list, loss_cols_list):
    """
    计算多个seed的平均loss曲线
    不做插值，只使用所有seed共有的epoch点
    只画到所有seed中epoch最少的那个
    loss_cols_list: 每个seed对应的loss列名列表
    """
    # 预处理每个seed的数据
    dfs = []
    for i, data in enumerate(data_list):
        df = pd.DataFrame(data["log_history"])
        loss_col = loss_cols_list[i]
        df = prep(df, loss_col)
        if len(df) > 0:
            # 统一列名为"loss"以便后续处理
            df = df.rename(columns={loss_col: "loss"})
            dfs.append(df)
    
    if len(dfs) == 0:
        return pd.DataFrame(columns=["epoch", "loss"])
    
    # 找到所有seed中epoch最少的（最小的最大epoch）
    max_epoch = min([df["epoch"].max() for df in dfs])
    print(f"所有seed中最小的最大epoch: {max_epoch}")
    
    # 找到所有seed共有的epoch值（完全相同的点，不做插值）
    # 并且只保留到max_epoch的点
    common_epochs = set(dfs[0][dfs[0]["epoch"] <= max_epoch]["epoch"].values)
    for df in dfs[1:]:
        df_filtered = df[df["epoch"] <= max_epoch]
        common_epochs = common_epochs.intersection(set(df_filtered["epoch"].values))
    
    if len(common_epochs) == 0:
        print("警告：没有找到所有seed共有的epoch点")
        return pd.DataFrame(columns=["epoch", "loss"])
    
    common_epochs = sorted([ep for ep in common_epochs if ep <= max_epoch])
    print(f"共有的epoch点数量: {len(common_epochs)}")
    
    if len(common_epochs) == 0:
        return pd.DataFrame(columns=["epoch", "loss"])
    
    # 对每个seed，在共有的epoch点上获取loss值
    losses_at_common_epochs = []
    for df in dfs:
        losses = []
        for ep in common_epochs:
            # 直接查找完全匹配的点
            matching = df[df["epoch"] == ep]
            if len(matching) > 0:
                losses.append(matching.iloc[0]["loss"])
            else:
                losses.append(np.nan)
        losses_at_common_epochs.append(losses)
    
    if len(losses_at_common_epochs) == 0:
        return pd.DataFrame(columns=["epoch", "loss"])
    
    # 计算平均loss（忽略NaN值）
    losses_array = np.array(losses_at_common_epochs)
    avg_loss = np.nanmean(losses_array, axis=0)
    
    # 创建平均DataFrame
    avg_df = pd.DataFrame({
        "epoch": common_epochs,
        "loss": avg_loss
    })
    # 移除NaN值
    avg_df = avg_df.dropna(subset=["loss"])
    avg_df = avg_df[avg_df["loss"] > 0]
    avg_df = avg_df.sort_values("epoch")
    
    return avg_df

# 确定loss列名（尝试常见的列名）
def find_loss_column(data):
    """查找loss列名"""
    df = pd.DataFrame(data["log_history"])
    possible_cols = ["train_loss", "loss", "eval_loss"]
    for col in possible_cols:
        if col in df.columns:
            return col
    return "train_loss"  # 默认值

# 为每个文件单独检测loss列名
loss_cols_zo = [find_loss_column(data) for data in zo_data_list]
loss_cols_pzo = [find_loss_column(data) for data in pzo_data_list]

print(f"ZO loss列名: {loss_cols_zo}")
print(f"PZO loss列名: {loss_cols_pzo}")

# 计算平均loss
zo_avg_df = compute_average_loss(zo_data_list, loss_cols_zo)
pzo_avg_df = compute_average_loss(pzo_data_list, loss_cols_pzo)

# 平滑参数
half = 1

# 确保ZO和PZO只画到两者都有的epoch范围
common_max_epoch = min(zo_avg_df["epoch"].max(), pzo_avg_df["epoch"].max())
zo_avg_df = zo_avg_df[zo_avg_df["epoch"] <= common_max_epoch]
pzo_avg_df = pzo_avg_df[pzo_avg_df["epoch"] <= common_max_epoch]

# 只保留两者共有的epoch点
zo_epochs = set(zo_avg_df["epoch"].values)
pzo_epochs = set(pzo_avg_df["epoch"].values)
common_epochs = sorted(list(zo_epochs.intersection(pzo_epochs)))

zo_avg_df = zo_avg_df[zo_avg_df["epoch"].isin(common_epochs)].sort_values("epoch")
pzo_avg_df = pzo_avg_df[pzo_avg_df["epoch"].isin(common_epochs)].sort_values("epoch")

print(f"ZO和PZO共有的epoch点数量: {len(common_epochs)}")
print(f"最大epoch: {max(common_epochs) if len(common_epochs) > 0 else 0}")

# 画图
plt.figure(figsize=(10, 6))
ax = plt.gca()

palette = sns.color_palette("deep", 2)
zo_color = palette[0]
pzo_color = palette[1]

plt.rcParams.update({
    "font.size": 14,
    "axes.labelsize": 14,
    "axes.titlesize": 14,
    "xtick.labelsize": 12,
    "ytick.labelsize": 12,
    "legend.fontsize": 14,
})

# 绘制ZO平均曲线（使用统一的"loss"列名）
x_zo = zo_avg_df["epoch"].to_numpy()
y_zo = zo_avg_df["loss"].to_numpy()
y_zo_s = smooth_including_self(zo_avg_df["loss"], half_window=half).to_numpy()
ax.plot(x_zo, y_zo, color=zo_color, alpha=0.25, linewidth=1)
ax.plot(x_zo, y_zo_s, color=zo_color, alpha=1.0, linewidth=2.5, label="MeZO (avg, smooth)")

# 绘制PZO平均曲线（使用统一的"loss"列名）
x_pzo = pzo_avg_df["epoch"].to_numpy()
y_pzo = pzo_avg_df["loss"].to_numpy()
y_pzo_s = smooth_including_self(pzo_avg_df["loss"], half_window=half).to_numpy()
ax.plot(x_pzo, y_pzo, color=pzo_color, alpha=0.25, linewidth=1)
ax.plot(x_pzo, y_pzo_s, color=pzo_color, alpha=1.0, linewidth=2.5, label="PseuZO (avg, smooth)")

# 计算加速比：找到ZO平滑曲线的最低点，画水平线与PZO曲线相交
# 找到ZO平滑曲线的最低点
zo_min_idx = np.argmin(y_zo_s)
zo_min_epoch = x_zo[zo_min_idx]
zo_min_loss = y_zo_s[zo_min_idx]

# 找PZO平滑曲线第一次达到(<=) zo_min_loss的位置
idxs = np.where(y_pzo_s <= zo_min_loss)[0]
if len(idxs) > 0:
    i = int(idxs[0])
    if i == 0:
        pzo_inter_epoch = x_pzo[0]
    else:
        x0, x1 = x_pzo[i-1], x_pzo[i]
        y0, y1 = y_pzo_s[i-1], y_pzo_s[i]
        # 线性插值求更精确的相交 epoch
        pzo_inter_epoch = x0 if y1 == y0 else (x0 + (zo_min_loss - y0) * (x1 - x0) / (y1 - y0))

    speedup = zo_min_epoch / max(pzo_inter_epoch, 1e-12)  # epoch 的加速比

    # 水平虚线：从ZO最低点画到PZO相交点
    ax.hlines(zo_min_loss, xmin=pzo_inter_epoch, xmax=zo_min_epoch,
              colors=zo_color, linestyles="--", linewidth=2, alpha=0.8)

    # 标出两个关键点：ZO最低点、PZO相交点
    ax.scatter([zo_min_epoch], [zo_min_loss], s=60, color=zo_color, zorder=6, marker='o')
    ax.scatter([pzo_inter_epoch], [zo_min_loss], s=60, color=pzo_color, zorder=6, marker='o')

    # 标注加速比
    x_mid = 0.5 * (pzo_inter_epoch + zo_min_epoch)
    ax.text(x_mid, zo_min_loss, f"≈{speedup:.2f}×",
            ha="center", va="bottom", fontsize=12, fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))

else:
    # 如果 PZO 没有达到 ZO 最低 loss
    ax.scatter([zo_min_epoch], [zo_min_loss], s=60, color=zo_color, zorder=6, marker='o')
    ax.text(zo_min_epoch, zo_min_loss, "no intersection", ha="left", va="bottom", fontsize=10)

plt.xlabel("Epoch", fontsize=14)
plt.ylabel("Loss", fontsize=14)
plt.legend(loc='best')
plt.grid(True, alpha=0.3)
plt.tight_layout()

# 保存图片
task = "SST2"  # 可根据实际情况修改
output_path = f"/home/xlyang/PseuZO/{task}_MeZO_vs_PseuZO_avg_comparison.png"
plt.savefig(output_path, dpi=300, bbox_inches="tight")
print(f"图片已保存至: {output_path}")
plt.close()

#plt.figure(figsize=(8,4))
#sns.lineplot(data=df1, x="epoch", y=df1["hessian_matrix"],label="rho=1e-1")
#sns.lineplot(data=df2, x="epoch", y=df2["hessian_matrix"],label="rho=1e-2")
#sns.lineplot(data=df3, x="epoch", y=df3["hessian_matrix"],label="rho=1e-3")
#sns.lineplot(data=df4, x="epoch", y=df4["hessian_matrix"],label="perturb_H^{-1}")
#plt.title("HHZO_SST2_RHO_Hessian")
#plt.xlabel("epoch")
#plt.ylabel("hessian_matrix")
#plt.legend()
#plt.tight_layout()
#plt.savefig("/home/yangxuanlin/MeZO-main/myassets/SST2_HHZO_RHO_Hessian.png", dpi=300, bbox_inches="tight")