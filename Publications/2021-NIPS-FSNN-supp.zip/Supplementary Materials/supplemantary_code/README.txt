This is the supplementary code for NeurIPS 2021 submission titled 'Training Feedback Spiking Neural Networks by Implicit Differentiation on the Equilibrium State'. Please do not distribute.

Requirements: PyTorch

To execute the code, run scripts as the following examples:

python mnist_conv_lif.py --time_step 30 --checkpoint mnist_lif --gpu-id 0

python cifar_alexnet_lif.py --time_step 30 --checkpoint cifar10_alexnet_lif --gpu-id 0

python cifar_cifarnet_if.py --dataset cifar100 --time_step 100 --checkpoint cifar100_cifarnet_if --gpu-id 0

The default hyperparameters are the same as in the paper.

You may need to download the cifar-10, cifar-100, and N-MNIST datasets and place them in the /data/. For MNIST and Fashion-MNIST, the data can be downloaded by torchvision as in the code. The cifar-10 and cifar-100 datasets are avaliable at https://www.cs.toronto.edu/~kriz/cifar.html. The N-MNIST dataset is avaliable at https://www.garrickorchard.com/datasets/n-mnist.
For the N-MNIST, we use the preprocessing code from https://github.com/stonezwr/TSSL-BP/tree/master/preprocessing/NMNIST. You may preprocess the data by this code and then place the data in the /data/NMNIST/.

The code for the broyden's method is from https://github.com/locuslab/mdeq.