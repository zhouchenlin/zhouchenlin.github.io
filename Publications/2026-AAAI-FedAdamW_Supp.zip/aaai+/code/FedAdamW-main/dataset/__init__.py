from .cifar import *
from .tiny_imagenet import *

