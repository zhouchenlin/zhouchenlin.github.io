import nltk
nltk.download('averaged_perceptron_tagger')

pos_dict = {
    "verb" : ["V", "VD", "VG", "VN", "MOD", "MD", "VB", "VBD","VBG","VBN","VBP","VBZ"],
    "noun" : ["N", "NP", "NUM", "FW", "CD", "LS","NN","NNS","NNP","NNPS"],
    "adjective" : ["ADJ", "JJ", "JJR", "JJS"],
    "determiner" : ["DET", "DT", "PDT","WDT"],
    "adverb" : ["ADV", "EX", "WH", "RB", "RBR", "RBS", "RP","WRB"],
    "pronoun" : ["PRO", "PRP", "PRP$", "WP", "WP$"],
    "preposition" : ["P", "TO"],
    "conjunction" : ["CNJ", "CC", "IN"],
    "interjection" : ["UH"],
    "other" : ["POS", "SYM"]
}

def get_pos(sentence):
    pos_list = []
    tokens = nltk.word_tokenize(sentence)
    tagged = nltk.pos_tag(tokens)
    for word, tag in tagged:
        match_flag = 0
        for pos in pos_dict:
            if tag in pos_dict[pos]:
                pos_list.append([word, pos])
                match_flag = 1
                break
        if not match_flag : pos_list.append([word, "other"])
        return(pos_list)

if __name__ == "__main__":
    example = "At eight o'clock on Thursday morning, Arthur didn't feel very good."
    print(get_pos(example))