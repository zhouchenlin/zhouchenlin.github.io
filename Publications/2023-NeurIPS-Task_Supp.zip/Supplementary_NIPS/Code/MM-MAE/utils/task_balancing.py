# Copyright (c) EPFL VILAB.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

import torch
import torch.nn as nn
import torch.nn.functional as F


class NoWeightingStrategy(nn.Module):
    """No weighting strategy
    """

    def __init__(self, **kwargs):
        super(NoWeightingStrategy, self).__init__()

    def forward(self, task_losses):
        return task_losses

class SoftmaxWeightingStrategy(nn.Module):
    """softmax weighting strategy
    """

    def __init__(self, tasks):
        super(SoftmaxWeightingStrategy, self).__init__()

        self.tasks = tasks

    def forward(self, task_losses):
        losses_tensor = torch.stack(list(task_losses.values()))
        non_zero_losses_mask = (losses_tensor != 0.0)

        weight = F.softmax(losses_tensor, dim=0) * losses_tensor

        weight *= non_zero_losses_mask

        weighted_task_losses = task_losses.copy()
        weighted_task_losses.update(zip(weighted_task_losses, weight))

        return weighted_task_losses

class UncertaintyWeightingStrategy(nn.Module):
    """Uncertainty weighting strategy
    """

    def __init__(self, tasks):
        super(UncertaintyWeightingStrategy, self).__init__()

        self.tasks = tasks
        self.log_vars = nn.Parameter(torch.zeros(len(tasks)))

    def forward(self, task_losses):
        losses_tensor = torch.stack(list(task_losses.values()))
        non_zero_losses_mask = (losses_tensor != 0.0)

        # calculate weighted losses
        # debug

        losses_tensor = torch.exp(-self.log_vars) * losses_tensor + self.log_vars

        # if some loss was 0 (i.e. task was dropped), weighted loss should also be 0 and not just log_var as no information was gained
        losses_tensor *= non_zero_losses_mask

        # return dictionary of weighted task losses
        weighted_task_losses = task_losses.copy()
        weighted_task_losses.update(zip(weighted_task_losses, losses_tensor))
        return weighted_task_losses
    
class GradNormStrategy(nn.Module):
    """GradNorm weighting strategy
    """

    def __init__(self, tasks):
        super(GradNormStrategy, self).__init__()
        self.tasks = tasks
        self.num_tasks = len(tasks)
        self.initial_losses = [1.0] * self.num_tasks
        self.current_losses = [1.0] * self.num_tasks
        self.first_iteration = True

    def update_losses(self, task_losses):
        if self.first_iteration:
            for i, loss in enumerate(task_losses):
                self.initial_losses[i] = loss.item()
            self.first_iteration = False

        for i, loss in enumerate(task_losses):
            self.current_losses[i] = loss.item()

    def compute_scaling_factors(self):
        scaling_factors = []
        for i in range(self.num_tasks):
            scaling_factor = self.current_losses[i] / self.initial_losses[i]
            scaling_factors.append(scaling_factor)

        return scaling_factors

    def forward(self, task_losses):
        task_losses_list = list(task_losses.values())
        self.update_losses(task_losses_list)
        scaling_factors = self.compute_scaling_factors()

        weighted_losses = []
        for i, loss in enumerate(task_losses_list):
            weighted_loss = loss * scaling_factors[i]
            weighted_losses.append(weighted_loss)

        weighted_task_losses = task_losses.copy()
        weighted_task_losses.update(zip(weighted_task_losses, weighted_losses))
        return weighted_task_losses

class DynamicWeightStrategy(nn.Module):
    """Dynamic Weight Averaging weighting strategy
    """
    def __init__(self, tasks, beta=0.9):
        super(DynamicWeightStrategy, self).__init__()
        self.tasks = tasks
        self.num_tasks = len(tasks)
        self.current_weights = [1.0] * self.num_tasks
        self.running_weights = [1.0] * self.num_tasks
        self.beta = beta

    def update_weights(self, task_weights):
        for i, weight in enumerate(task_weights):
            self.running_weights[i] = self.beta * self.running_weights[i] + (1 - self.beta) * weight.item()
            self.current_weights[i] = self.running_weights[i] / (1 - self.beta ** (i+1))

    def compute_scaling_factors(self):
        scaling_factors = []
        for i in range(self.num_tasks):
            scaling_factor = self.current_weights[i]
            scaling_factors.append(scaling_factor)

        return scaling_factors

    def forward(self, task_weights):
        task_weights_list = list(task_weights.values())
        self.update_weights(task_weights_list)
        scaling_factors = self.compute_scaling_factors()

        weighted_weights = []
        for i, weight in enumerate(task_weights_list):
            weighted_weight = weight * scaling_factors[i]
            weighted_weights.append(weighted_weight)

        weighted_task_weights = task_weights.copy()
        weighted_task_weights.update(zip(weighted_task_weights, weighted_weights))
        return weighted_task_weights