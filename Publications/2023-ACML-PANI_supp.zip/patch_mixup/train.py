from __future__ import print_function
import argparse
import csv
import os
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torch.nn.functional as F
import time
import models
from utils import progress_bar

parser = argparse.ArgumentParser(description='PyTorch CIFAR10 Training')
parser.add_argument('--lr', default=0.1, type=float, help='learning rate')
parser.add_argument('--resume', '-r', action='store_true', help='resume from checkpoint')
parser.add_argument('--model', default="ResNet18", type=str, help='model type (default: ResNet18), WRN28_10, DenseNet190')
parser.add_argument('--name', default='0', type=str, help='name of run')
parser.add_argument('--seed', default=0, type=int, help='random seed')
parser.add_argument('--batch-size', default=2, type=int, help='default:128, batch size')
parser.add_argument('--epoch', default=200, type=int, help='total epochs to run')
parser.add_argument('--no-augment', dest='augment', action='store_false', help='use standard augmentation (default: True)')
parser.add_argument('--decay', default=1e-4, type=float, help='weight decay')
parser.add_argument('--betaalpha', default=1., type=float, help='mixup interpolation coefficient (default: 1)')
parser.add_argument('--method', type=str, default='peer', help='mixup, normal, peer, pmixup')
parser.add_argument('--dataset', type=str, default='CIFAR10', help='CIFAR10, SVHN, CIFAR100')
parser.add_argument('--n', default=1, type=int, help='number of neighbors in a batch')
parser.add_argument('--k', default='1', type=str, help='number of knn in pixel-level')
parser.add_argument('--index_h', default='0', type=str, help='position of purturbation in a nn')
parser.add_argument('--patch', default='11', type=str, help='patch size')
#parser.add_argument('--stride', default='', type=str, help='stride size')
parser.add_argument('--alpha', default='1.0', type=str, help='')
parser.add_argument('--eta', default=1.0, type=float, help='restraint on norm')
parser.add_argument('--lam_min',default=0.0, type=float, help='')
parser.add_argument('--exp',default=1.0,type=float, help='thresholding of mask')
#parser.add_argument('--num-steps', type=int, default=10, help='default: 10, perturb number of steps')
#parser.add_argument('--step_size', type=float, default=0.007, help='perturb step size')
#parser.add_argument('--VATepsilon', default=0.1, type=float, help='norm')
#parser.add_argument('--random_d', action='store_true', help='random d')
#parser.add_argument('--random_graph', action='store_true', help='random graph')
#parser.add_argument('--gpu',default='0',help='gpu')
args = parser.parse_args()
print(args)
INDEX_H = [int(i) for i in args.index_h.split('_')]
ALPHA = [float(i) for i in args.alpha.split('_')]
PSIZE = [int(i) for i in args.patch.split('_')] # multiple patch size
#if args.stride=='':
#    SSIZE=PSIZE
KPIX = [int(i) for i in args.k.split('_')] # multiple k_pixel
if (len(KPIX) == 1) and (len(INDEX_H) > 1): # multiple positions with the same k_pixel
    KPIX = KPIX * len(INDEX_H)
if (len(ALPHA) == 1) and (len(INDEX_H) > 1): # multiple positions with the same norm constrains
    ALPHA = ALPHA * len(INDEX_H)
if (len(PSIZE) == 1) and (len(INDEX_H) > 1): # multiple positions with the same patch size
    PSIZE = PSIZE * len(INDEX_H)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
CLASSES = 100 if args.dataset == 'CIFAR100' else 10
if args.seed != 0:
    torch.manual_seed(args.seed)

def mixup_data(x, y, alpha=1.0, device='cpu'):
    # (1) sample mix coefficient
    if alpha > 0:
        lam = np.random.beta(alpha, alpha) # default: beta(1,1)=U(0,1)
    else:
        lam = 1
    # (2) random index
    batch_size = x.size()[0]
    index = torch.randperm(batch_size).to(device)
    # (3) mixup inputs and return labels
    mixed_x = lam * x + (1 - lam) * x[index, :]
    y_a, y_b = y, y[index]
    return mixed_x, y_a, y_b, lam


def _Compute_patch(x, patch_size, C, deconv=False):
    if patch_size == 1:
        return x
    w = np.identity(C * patch_size * patch_size).astype(np.float32)
    w = np.reshape(w, [C * patch_size * patch_size, C, patch_size, patch_size])
    #w = np.transpose(w, [0,3,1,2])
    w = torch.from_numpy(w).to(device)
    w.requires_grad = False
    if deconv:
        # x = tf.nn.conv2d_transpose(x, w, output_shape=shape, strides=[1, patch_size, patch_size, 1], padding='SAME')
        x = F.conv_transpose2d(x, w, stride=patch_size)
    else:
        # x = tf.nn.conv2d(x, w, strides=[1, patch_size, patch_size, 1], padding='SAME')
        x = F.conv2d(x, w, stride=patch_size) # default: valid
    return x

def mixup_data2(x, y, alpha=1.0, device='cpu'):
    # (1) sample mix coefficient
    if alpha > 0:
        lam = np.random.beta(alpha, 1.0) # default: beta(1,1)=U(0,1)
    else:
        lam = 1
    # (2) random index
    batch_size = x.size()[0]
    index = torch.randperm(batch_size).to(device)
    # (3) mixup inputs and return labels
    N, C, H, W = list(x.shape)
    patch_size = PSIZE[0]
    H_, W_, C_ = int(H / patch_size + 1e-3), int(W / patch_size + 1e-3), C * patch_size * patch_size
    H_ = H_ + 1 if H % patch_size > 0 else H_
    W_ = W_ + 1 if W % patch_size > 0 else W_
    # padding = SAME in pytorch
    if H % patch_size > 0:
        p_size = patch_size - H % patch_size
        x = F.pad(x, (0, p_size, 0, p_size))
    x_patch = _Compute_patch(x, patch_size, C)
    # d is the combination coefficient of patches
    d = np.random.rand(N, H_, W_,1)
    d = d/(1e-6+np.mean(d,axis=(1,2),keepdims=True))*(1.0-lam)
    d = torch.from_numpy(d).float().to(device)
    mixed_x = d * x_patch + (1.0 - d) * x_patch[index, :]
    mixed_x = _Compute_patch(mixed_x, patch_size, C, deconv=True)
    if H%patch_size>0:
        mixed_x=mixed_x[:,0:H,0:W,:]
    y_a, y_b = y, y[index]
    return mixed_x, y_a, y_b, lam


def mixup_randperm(batch_size, alpha=1.0, device='cpu'):
    '''
    if alpha>0:
        lam=np.random.beta(alpha,alpha)
    else:
        lam=1
    if lam<0.5:
        lam=1.0-lam
    '''
    lam=np.random.beta(alpha,1.0)
    lam=lam*(1.0-args.lam_min)+args.lam_min
    index=[]
    #y_perm=[]
    for n in range(args.n):
        index.append(torch.randperm(batch_size).to(device))
        #y_perm.append(y[index[-1]])
    return torch.stack(index, dim=1), lam
    #lam_arr=lam_arr/(1e-6+np.sum(lam_arr))*(1.0-lam)
    #return index,y_perm,lam,lam_arr


def mixup_criterion(criterion, pred, y_a, y_b, lam): # mix CE loss(hard)
    return lam * criterion(pred, y_a) + (1 - lam) * criterion(pred, y_b)


def train(epoch):
    print('\nEpoch: %d' % epoch, time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))
    net.train()
    train_loss = 0
    reg_loss = 0
    correct = 0
    total = 0
    for batch_idx, (inputs, targets) in enumerate(trainloader):
        inputs, targets = inputs.to(device), targets.to(device)
        if args.method == 'mixup':
            # (1) mix input and labels
            inputs, targets_a, targets_b, lam = mixup_data(inputs, targets, args.betaalpha, device)
            outputs = net(inputs)
            # (2) mix loss
            loss = mixup_criterion(criterion, outputs, targets_a, targets_b, lam)
        elif args.method == 'pmixup':
            # (1) mix input and labels
            inputs, targets_a, targets_b, lam = mixup_data2(inputs, targets, args.betaalpha, device)
            outputs = net(inputs)
            # (2) mix loss
            loss = mixup_criterion(criterion, outputs, targets_a, targets_b, lam)
        elif args.method == 'normal':
            outputs = net(inputs)
            loss = criterion(outputs, targets)
        else: # peer method
            batch_size=inputs.size()[0]
            index, lam = mixup_randperm(batch_size,args.betaalpha,device) # return
            one_hot = torch.zeros(batch_size, CLASSES).to(device).scatter_(1, targets.reshape([-1,1]), 1)
            #inputs, targets_a, targets_b, lam=mixup_data(inputs, targets, args.betaalpha, device)
            outputs, y = net(inputs, pars=[INDEX_H,ALPHA,PSIZE,KPIX,index,lam,one_hot,device,args.eta,args.exp])
            pred = F.softmax(outputs, dim=-1)
            loss = y*torch.log(pred+1e-6)
            loss = -1.0 * CLASSES * loss.mean()
        _, predicted = torch.max(outputs.data, 1)
        total += targets.size(0)
        if args.method == 'mixup':
            correct += (lam * predicted.eq(targets_a.data).cpu().sum().float()
                        + (1 - lam) * predicted.eq(targets_b.data).cpu().sum().float())
        else:
            correct += predicted.eq(targets).cpu().sum().float()

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        progress_bar(batch_idx, len(trainloader), 'Loss: %.3f | Reg: %.5f | Acc: %.3f%% (%d/%d)' % (train_loss/(batch_idx+1), reg_loss/(batch_idx+1),
                100.*correct/total, correct, total))
    return (train_loss/batch_idx, reg_loss/batch_idx, 100.*correct/total)


def test_model(epoch):
    global best_acc
    net.eval()
    test_loss = 0
    correct = 0
    total = 0
    for batch_idx, (inputs, targets) in enumerate(testloader):
        inputs, targets = inputs.to(device), targets.to(device)
        outputs = net(inputs)
        loss = criterion(outputs, targets)

        test_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        total += targets.size(0)
        correct += predicted.eq(targets.data).cpu().sum()

        progress_bar(batch_idx, len(testloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)' % (test_loss/(batch_idx+1), 100.*float(correct)/float(total), correct, total))
    acc = 100.*correct/total
    if epoch == start_epoch + args.epoch - 1 or acc > best_acc:
        checkpoint(acc, epoch)
    if acc > best_acc:
        best_acc = acc
    return (test_loss/batch_idx, 100.*float(correct)/float(total))


def checkpoint(acc, epoch):
    # Save checkpoint.
    print('Saving..')
    state = {
        'net': net,
        'acc': acc,
        'epoch': epoch,
        'rng_state': torch.get_rng_state()
    }
    if not os.path.isdir('checkpoint'):
        os.mkdir('checkpoint')
    torch.save(state, './checkpoint/ckpt.t7' + args.name + '_'
               + str(args.seed))


def adjust_learning_rate(optimizer, epoch):
    """decrease the learning rate at 100 and 150 epoch"""
    lr = args.lr
    if args.model == 'DenseNet190':
        if epoch >= 60:
            lr /= 10
        if epoch >= 120:
            lr /= 10
        if epoch >= 180:
            lr /= 10
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
    else:
        if epoch >= 100:
            lr /= 10
        if epoch >= 150:
            lr /= 10
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr

if __name__ == '__main__':
    best_acc = 0  # best test accuracy
    start_epoch = 0  # start from epoch 0 or last checkpoint epoch

    # Data
    print('==> Preparing data..')
    if args.augment:
        transform_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize((0.4914, 0.4822, 0.4465),
                                 (0.2023, 0.1994, 0.2010)),
        ])
    else:
        transform_train = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.4914, 0.4822, 0.4465),
                                 (0.2023, 0.1994, 0.2010)),
        ])

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])
    if args.dataset == 'CIFAR10':
        trainset = datasets.CIFAR10(root='data', train=True, download=True, transform=transform_train)
        trainloader = torch.utils.data.DataLoader(trainset, batch_size=args.batch_size, shuffle=True, num_workers=0)
        testset = datasets.CIFAR10(root='data', train=False, download=True, transform=transform_test)
        testloader = torch.utils.data.DataLoader(testset, batch_size=100, shuffle=False, num_workers=0)
    elif args.dataset == 'SVHN':
        trainset = datasets.SVHN(root='data', split='train', download=True, transform=transform_train)
        trainloader = torch.utils.data.DataLoader(trainset, batch_size=args.batch_size, shuffle=True, num_workers=0)
        testset = datasets.SVHN(root='data', split='test', download=True, transform=transform_test)
        testloader = torch.utils.data.DataLoader(testset, batch_size=100, shuffle=False, num_workers=0)
    elif args.dataset == 'CIFAR100':
        trainset = datasets.CIFAR100(root='data', train=True, download=True, transform=transform_train)
        trainloader = torch.utils.data.DataLoader(trainset, batch_size=args.batch_size, shuffle=True, num_workers=0)
        testset = datasets.CIFAR100(root='data', train=False, download=True, transform=transform_test)
        testloader = torch.utils.data.DataLoader(testset, batch_size=100, shuffle=False, num_workers=0) # 0: single process
    else:
        print('dataset name error!')
        raise AssertionError
    # Model
    if args.resume:
        # Load checkpoint.
        print('==> Resuming from checkpoint..')
        assert os.path.isdir('checkpoint'), 'Error: no checkpoint directory found!'
        checkpoint = torch.load('./checkpoint/ckpt.t7' + args.name + '_' + str(args.seed))
        net = checkpoint['net']
        best_acc = checkpoint['acc']
        start_epoch = checkpoint['epoch'] + 1
        rng_state = checkpoint['rng_state']
        torch.set_rng_state(rng_state)
    else:
        print('==> Building model..')
        net = models.__dict__[args.model](num_classes=CLASSES)

    if not os.path.isdir('results'):
        os.mkdir('results')
    logname = ('results/log_' + net.__class__.__name__ + '_' + args.name + '_' + str(args.seed) + '.csv')

    net.to(device)
    net = torch.nn.DataParallel(net)
    # print(torch.cuda.device_count())
    cudnn.benchmark = True
    if torch.cuda.is_available():
        print('Using CUDA..')

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(net.parameters(), lr=args.lr, momentum=0.9, weight_decay=args.decay)

    if not os.path.exists(logname):
        with open(logname, 'w') as logfile:
            logwriter = csv.writer(logfile, delimiter=',')
            logwriter.writerow(['epoch', 'train loss', 'reg loss', 'train acc', 'test loss', 'test acc'])

    for epoch in range(start_epoch, args.epoch):
        train_loss, reg_loss, train_acc = train(epoch)
        test_loss, test_acc = test_model(epoch)
        adjust_learning_rate(optimizer, epoch)
        # with open(args.method+'.txt', 'a+') as file:
        #     file.write(str(epoch)+','+str(test_acc)+','+(str(int(time.time())))+'\n')
        with open(logname, 'a') as logfile:
            logwriter = csv.writer(logfile, delimiter=',')
            logwriter.writerow([epoch, train_loss, reg_loss, train_acc, test_loss, test_acc])
