import torch
import torch.nn.functional as F
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
import numpy as np

def l2_norm(x, axis=None):
    square_sum = torch.sum(torch.mul(x, x), dim=axis, keepdim=True)
    square_sum = torch.max(square_sum, torch.FloatTensor([1e-7]).to(device).expand_as(square_sum))
    norm = torch.sqrt(square_sum)
    return norm

def pairwise_cosine_sim(A_B):
    A, B = A_B
    A_mag = l2_norm(A, axis=2) # (32, 784, 1) cancel channel
    B_mag = l2_norm(B, axis=2)
    num = torch.bmm(A, B.permute(0, 2, 1)) # (32, 784, 784) vector product
    den = A_mag * B_mag.permute(0, 2, 1) # divide corresponding l2_norm
    dist_mat = num / den
    return dist_mat

def _Compute_patch(x, patch_size, C, deconv=False):
    if patch_size == 1:
        return x
    w = np.identity(C * patch_size * patch_size).astype(np.float32)
    w = np.reshape(w, [C * patch_size * patch_size, C, patch_size, patch_size])
    #w = np.transpose(w, [0,3,1,2])
    w = torch.from_numpy(w).to(device)
    w.requires_grad = False
    if deconv:
        # x = tf.nn.conv2d_transpose(x, w, output_shape=shape, strides=[1, patch_size, patch_size, 1], padding='SAME')
        x = F.conv_transpose2d(x, w, stride=patch_size)
    else:
        # x = tf.nn.conv2d(x, w, strides=[1, patch_size, patch_size, 1], padding='SAME')
        x = F.conv2d(x, w, stride=patch_size) # default: valid
    return x

def VAT_patch(h, y, pars, index_bound):
    INDEX_H,ALPHA,PSIZE,KPIX,index,lam,_,device,eta,exp_=pars
    alpha=ALPHA[index_bound-1]
    patch_size=PSIZE[index_bound-1]
    K_pixel=KPIX[index_bound-1]
    lam=lam**alpha
    K_=list(index.shape)[1]
    idxs = index.reshape([-1])

    N, C, H, W = list(h.shape) # (N, C, H, W) / (5, 3, 32, 32)
    # (1) compute patch
    H_, W_, C_ = int(H / patch_size + 1e-3), int(W / patch_size + 1e-3), C * patch_size * patch_size
    H_ = H_ + 1 if H % patch_size > 0 else H_
    W_ = W_ + 1 if W % patch_size > 0 else W_
    # padding = same (equivalent to tensorflow)
    if H % patch_size > 0:
        p_size = patch_size - H % patch_size
        h = F.pad(h, (0, p_size, 0, p_size))
    net_patch = _Compute_patch(h, patch_size, C)  # (N,H,W,F) -> (N,H_,W_,F_)
    net_patch = net_patch.reshape(N, C_, H_ * W_) # (5,27,10,10)
    net_patch=net_patch.permute(0,2,1)
    y_patch=y.unsqueeze(1).expand(-1,H_*W_,-1)
    # (2) index image-level neighbors with patches for each image
    x_neighbors = net_patch[idxs,:,:]  # (batch, K_, H_*W_, F_)
    y_neighbors=y_patch[idxs,:,:]
    x_neighbors_pixel = x_neighbors.reshape(N, K_ * H_ * W_, C_)  # (128, 1024*K_, F)
    y_neighbors_pixel=y_neighbors.reshape(N,K_*H_*W_,-1)
    # (3) obtain index of knn patches in K_ images
    cos_dists_pixel = pairwise_cosine_sim([net_patch, x_neighbors_pixel])
    _, idxs_pixel = torch.topk(cos_dists_pixel, K_pixel, largest=True) # (batch, H_*W_, k_pixel), k_pixel in (0,H_*W_*K_)
    # (4) index knn patches
    index1 = torch.t(torch.arange(N).unsqueeze(0).expand(H_ * W_ * K_pixel, N))
    idxs_pixel = idxs_pixel.reshape(N, H_ * W_ * K_pixel)
    pixel_neighbors = x_neighbors_pixel[index1, idxs_pixel] # (N, K_pixel*H_*W_, C_)
    target_neighbors=y_neighbors_pixel[index1, idxs_pixel]
    pixel_neighbors = pixel_neighbors.reshape(N, H_ * W_, K_pixel, C_)
    target_neighbors=target_neighbors.reshape(N, H_ * W_, K_pixel, -1)
    # (5) combination
    if exp_>=0.0:
        d=np.random.rand(N, H_ * W_, K_pixel,1)**exp_
    else:
        d=np.random.rand(N, H_ * W_, K_pixel,1)
        d_mask=np.random.rand(N, H_ * W_, K_pixel,1)
        d=d*(d_mask<(-exp_))
    d=d/(1e-6+np.mean(np.sum(d,axis=2,keepdims=True),axis=1,keepdims=True))*(1.0-lam)
    d=torch.from_numpy(d).float().to(device)
    #h=(1.0-eta+eta*lam)*net_patch+torch.sum(eta*d*pixel_neighbors,dim=2)
    h=(1.0-torch.sum(eta*d,dim=2))*net_patch+torch.sum(eta*d*pixel_neighbors,dim=2) # self: lambda, neighbors: 1 - lambda
    #print(y_patch.shape,d.shape,target_neighbors.shape)
    y=lam*y+torch.mean(torch.sum(d*target_neighbors,dim=2),dim=1)
    
    
    
    h = h.permute(0,2,1).reshape(N, C_,H_, W_) # (N, H_*W_, 1, C_) -> (N, H_*W_, C_)
    # (6) deconv to original size  -> (N, H, W, F)
    h = _Compute_patch(h, patch_size, C, deconv=True)
    if H%patch_size>0:
        h=h[:,0:H,0:W,:]
    return h, y