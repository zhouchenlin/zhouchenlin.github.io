1.Pani VAT(tensorflow)
(1)cd patch_vat
(2)python train_semisup.py --dataset=cifar10 --method=peerent --n 10 --k 50 --index_h 0 --alpha 1.0 --patch 3 --epsilon=3.0 --gpu 4 

2.Pani MixUp(pytorch)
(1)cd patch_mixup
(2)python train.py --dataset CIFAR10 --batch-size 128 --method peer --patch 8 --lam_min 0.0 --betaalpha 2.5 --exp -0.4 --alpha 1.0 --k 1 --model ResNet18

Note: best parameters should be referred to the paper.