import tensorflow as tf
import numpy
import sys, os
import layers as L
from keras import backend as K
import numpy as np

FLAGS = tf.app.flags.FLAGS
tf.app.flags.DEFINE_float('keep_prob_hidden', 0.5, "dropout rate")
tf.app.flags.DEFINE_float('lrelu_a', 0.1, "lrelu slope")
tf.app.flags.DEFINE_boolean('top_bn', False, "")


def l2_norm(x, axis=None):
    square_sum = K.sum(K.square(x), axis=axis, keepdims=True)
    norm = K.sqrt(K.maximum(square_sum, K.epsilon()))
    return norm


def pairwise_cosine_sim(A_B):
    A, B = A_B
    A_mag = l2_norm(A, axis=2)
    B_mag = l2_norm(B, axis=2)
    num = K.batch_dot(A, K.permute_dimensions(B, (0, 2, 1)))
    den = (A_mag * K.permute_dimensions(B_mag, (0, 2, 1)))
    dist_mat = num / den
    print(num, den, dist_mat)
    return dist_mat


def _Compute_patch(x, patch_size, F, deconv=False, shape=None):
    if patch_size == 1:
        return x
    w = np.identity(F * patch_size * patch_size).astype(np.float32)
    w = np.reshape(w, [F * patch_size * patch_size, patch_size, patch_size, F])
    w = np.transpose(w, [1, 2, 3, 0])
    w = tf.constant(w)
    if deconv:
        # N, H_, W_, _ = x.get_shape().as_list()
        # H, W = H_*patch_size, W_*patch_size
        x = tf.nn.conv2d_transpose(x, w, output_shape=shape, strides=[1, patch_size, patch_size, 1], padding='SAME')
    else:
        x = tf.nn.conv2d(x, w, strides=[1, patch_size, patch_size, 1], padding='SAME')
    return x


def VAT_patch(h, pars, index_bound):
    compute_nei, d, idxs_list, K_, K_pixel, index_h, patch_size, bound, alpha = pars
    print(compute_nei, K_, K_pixel)
    idxs = idxs_list[0]
    idxs_list = idxs_list[1]
    if compute_nei == 1:
        idxs_pixel = idxs_list[index_bound - 1]
    patch_size = patch_size[index_bound - 1]
    alpha = alpha[index_bound - 1]
    K_pixel = K_pixel[index_bound - 1]
    N, H, W, F = h.get_shape().as_list()
    # (1) compute hidden neighbors
    # net = K.reshape(h, [N, H * W, F])
    H_, W_, F_ = int(H / patch_size + 1e-3), int(W / patch_size + 1e-3), F * patch_size * patch_size
    if H % patch_size > 0:
        H_ += 1
    if W % patch_size > 0:
        W_ += 1
    if patch_size > 1:
        net_patch = _Compute_patch(h, patch_size, F)  # (N,H,W,F) -> (N,H_,W_,F_)
    else:
        net_patch = h
    net_patch = tf.reshape(net_patch, [N, H_ * W_, F_])
    x_neighbors = tf.gather(net_patch, idxs)
    # x_neighbors = tf.gather(net, idxs)  # (128, 32*32, F)+(128, 10) -> (128, 10, 32*32, F)
    # (2) get patches via conv：(N*K_,H,W,F)->(N*K_,H_,W_,F_)
    # x_neighbors = _Compute_patch(tf.reshape(x_neighbors, [N * K_, H, W, F]), patch_size=patch_size, F=F)
    # (3) compute patch-level knn
    x_neighbors_pixel = K.reshape(x_neighbors, [N, H_ * W_ * K_, F_])  # (128, 1024*K_, F)
    # net_patch = _Compute_patch(h, patch_size, F) # (N,H,W,F) -> (N,H_,W_,F_)
    # net_patch = tf.reshape(net_patch, [N, H_ * W_, F_])
    if compute_nei == 0:
        cos_dists_pixel = pairwise_cosine_sim([net_patch, x_neighbors_pixel])
        _, idxs_pixel = tf.nn.top_k(cos_dists_pixel, K_pixel)
    temp0 = K.tile(K.expand_dims(K.arange(N), 0), [H_ * W_ * K_pixel, 1])
    temp = K.stack([K.transpose(temp0), K.reshape(idxs_pixel, [N, H_ * W_ * K_pixel])], 2)
    pixel_neighbors = tf.gather_nd(K.reshape(x_neighbors_pixel, [N, H_ * W_ * K_, F_]), temp)  # N, HWK_pixel, F
    pixel_neighbors = K.permute_dimensions(K.reshape(pixel_neighbors, [N, H_ * W_, K_pixel, F_]), (0, 2, 1, 3))
    # (4) combination-
    d_pert = d[:, bound[index_bound - 1]:bound[index_bound], :]
    d_pert = tf.reshape(d_pert, [N, K_pixel, -1, 1])
    # print(d_pert , pixel_neighbors,tf.expand_dims(net_patch,axis=1))
    r_adv = alpha * d_pert * (
    pixel_neighbors - tf.expand_dims(net_patch, axis=1))  # (N, K_pixel, H_*W_, 1)*(N,K_pixel,H_*W_,F_)
    if (N > 100) and (compute_nei == 1):
        tf.add_to_collection(name='pert_norm', value=alpha * tf.reduce_mean(tf.abs(d_pert)))
    r_adv = tf.reshape(tf.reduce_sum(r_adv, 1), [N, H_, W_, F_])  # (N, 1, H_*W_, F_) -> (N,H_,W_,F_)
    # (5) deconv to original size  -> (N, H, W, F)
    if patch_size > 1:
        r_adv = _Compute_patch(r_adv, patch_size, F, deconv=True, shape=[N, H, W, F])
    h = h + r_adv
    return h, idxs_pixel


# conv-large
def logit(x, is_training=True, update_batch_stats=True, stochastic=True, seed=1234, pars=None):
    index_h = []  # default index_h
    N = x.get_shape().as_list()[0]
    if pars is not None:
        compute_nei, _, idxs_list, _, _, index_h, _, _, alpha = pars
        idxs = idxs_list[0]
        idxs_list = idxs_list[1]
        if idxs_list is None:
            idxs_list = []
    index_bound = 1
    h = x
    # (0) VAT on input layer 0: (N, 32, 32, 3)

    if 0 in index_h:
        if compute_nei == 0:
            h, idxs_pixel = VAT_patch(h, pars, index_bound)
            idxs_list.append(idxs_pixel)
            index_bound += 1
        if pars[0] == 1:
            h, _ = VAT_patch(h, pars, index_bound)
            index_bound += 1

    rng = numpy.random.RandomState(seed)
    h = L.conv(h, ksize=3, stride=1, f_in=3, f_out=128, seed=rng.randint(123456), name='c1')
    h = L.lrelu(L.bn(h, 128, is_training=is_training, update_batch_stats=update_batch_stats, name='b1'), FLAGS.lrelu_a)
    h = L.conv(h, ksize=3, stride=1, f_in=128, f_out=128, seed=rng.randint(123456), name='c2')
    h = L.lrelu(L.bn(h, 128, is_training=is_training, update_batch_stats=update_batch_stats, name='b2'), FLAGS.lrelu_a)
    h = L.conv(h, ksize=3, stride=1, f_in=128, f_out=128, seed=rng.randint(123456), name='c3')
    h = L.lrelu(L.bn(h, 128, is_training=is_training, update_batch_stats=update_batch_stats, name='b3'), FLAGS.lrelu_a)

    h = L.max_pool(h, ksize=2, stride=2)
    h = tf.nn.dropout(h, keep_prob=FLAGS.keep_prob_hidden, seed=rng.randint(123456)) if stochastic else h

    # (1) VAT on hidden layer 2: (N, 16, 16, 128)

    if 1 in index_h:
        if compute_nei == 0:
            h, idxs_pixel = VAT_patch(h, pars, index_bound)
            idxs_list.append(idxs_pixel)
            index_bound += 1
        if pars[0] == 1:
            h, _ = VAT_patch(h, pars, index_bound)
            index_bound += 1

    h = L.conv(h, ksize=3, stride=1, f_in=128, f_out=256, seed=rng.randint(123456), name='c4')
    h = L.lrelu(L.bn(h, 256, is_training=is_training, update_batch_stats=update_batch_stats, name='b4'), FLAGS.lrelu_a)
    h = L.conv(h, ksize=3, stride=1, f_in=256, f_out=256, seed=rng.randint(123456), name='c5')
    h = L.lrelu(L.bn(h, 256, is_training=is_training, update_batch_stats=update_batch_stats, name='b5'), FLAGS.lrelu_a)
    h = L.conv(h, ksize=3, stride=1, f_in=256, f_out=256, seed=rng.randint(123456), name='c6')
    h = L.lrelu(L.bn(h, 256, is_training=is_training, update_batch_stats=update_batch_stats, name='b6'), FLAGS.lrelu_a)

    h = L.max_pool(h, ksize=2, stride=2)
    h = tf.nn.dropout(h, keep_prob=FLAGS.keep_prob_hidden, seed=rng.randint(123456)) if stochastic else h
    # (2) VAT on hidden layer 3: (N, 8, 8, 256)
    if 2 in index_h:
        if compute_nei == 0:
            h, idxs_pixel = VAT_patch(h, pars, index_bound)
            idxs_list.append(idxs_pixel)
            index_bound += 1
        if pars[0] == 1:
            h, _ = VAT_patch(h, pars, index_bound)
            index_bound += 1

    h = L.conv(h, ksize=3, stride=1, f_in=256, f_out=512, seed=rng.randint(123456), padding="VALID",
               name='c7')  # -3+0/1 + 1: 8-6
    h = L.lrelu(L.bn(h, 512, is_training=is_training, update_batch_stats=update_batch_stats, name='b7'), FLAGS.lrelu_a)
    h = L.conv(h, ksize=1, stride=1, f_in=512, f_out=256, seed=rng.randint(123456), name='c8')  # 6
    h = L.lrelu(L.bn(h, 256, is_training=is_training, update_batch_stats=update_batch_stats, name='b8'), FLAGS.lrelu_a)
    h = L.conv(h, ksize=1, stride=1, f_in=256, f_out=128, seed=rng.randint(123456), name='c9')  # 6
    h = L.lrelu(L.bn(h, 128, is_training=is_training, update_batch_stats=update_batch_stats, name='b9'), FLAGS.lrelu_a)

    h = tf.reduce_mean(h, reduction_indices=[1, 2])  # Global average pooling
    h1 = h
    h = L.fc(h, 128, 10, seed=rng.randint(123456), name='fc')

    if FLAGS.top_bn:
        h = L.bn(h, 10, is_training=is_training, update_batch_stats=update_batch_stats, name='bfc')
    if pars == None:
        return h, h1
    elif pars[0] == 0:
        print(idxs_list)
        return h, idxs_list
    else:
        print(idxs_list)
        return h, None
