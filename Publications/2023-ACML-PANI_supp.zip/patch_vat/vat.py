import tensorflow as tf
import layers as L
import cnn
from keras import backend as K
import numpy as np

tf.app.flags.DEFINE_float('epsilon', 10.0, "norm length for (virtual) adversarial training ")
tf.app.flags.DEFINE_integer('num_power_iterations', 1, "the number of power iterations")
tf.app.flags.DEFINE_float('xi', 1e-6, "small constant for finite difference")

FLAGS = tf.app.flags.FLAGS


def logit(x, is_training=True, update_batch_stats=True, stochastic=True, seed=1234, pars=None):
    return cnn.logit(x, is_training=is_training, update_batch_stats=update_batch_stats, stochastic=stochastic,
                     seed=seed, pars=pars)


def forward(x, is_training=True, update_batch_stats=True, seed=1234, pars=None):
    if is_training:
        return logit(x, is_training=True, update_batch_stats=update_batch_stats, stochastic=True, seed=seed, pars=pars)
    else:
        return logit(x, is_training=False, update_batch_stats=update_batch_stats, stochastic=False, seed=seed,
                     pars=pars)


def l2_norm(x, axis=None):
    square_sum = K.sum(K.square(x), axis=axis, keepdims=True)
    norm = K.sqrt(K.maximum(square_sum, K.epsilon()))
    return norm


def pairwise_cosine_sim_logits(A_B):
    A, B = A_B
    A_mag = l2_norm(A, axis=1)
    B_mag = l2_norm(B, axis=1)
    num = K.dot(A, K.transpose(B))
    den = A_mag * K.transpose(B_mag)
    dist_mat = num / den
    return dist_mat


def get_normalized_vector(d):
    d /= (1e-12 + tf.reduce_max(tf.abs(d), list(range(1, len(d.get_shape()))),
                                keepdims=True))  # (128, 32, 32, 3), range(1, 4)=1,2,3
    d /= tf.sqrt(1e-6 + tf.reduce_sum(tf.pow(d, 2.0), list(range(1, len(d.get_shape()))), keepdims=True))
    return d


def virtual_adversarial_loss_graph_h(x, logit, feature, random_graph, K_=5, K_pixel=[20], index_h=1, patch_size=[2],
                                     alpha=[1.0], dist='l2', is_training=True, name="vat_loss_graph"):
    N, H, W, F = x.get_shape().as_list()
    print(random_graph, '___________________________________________________')
    if random_graph:
        a = np.zeros([N - 1, N], dtype=np.int32)
        for i in range(N):
            for j in range(N - 1):
                if j < i:
                    a[j, i] = j
                else:
                    a[j, i] = j + 1
        a = tf.constant(a)
        b = tf.random_shuffle(a)
        idxs = b[0:K_, :]
        idxs = tf.transpose(idxs, [1, 0])
    else:
        cos_dists = pairwise_cosine_sim_logits([feature, feature])  # (128(batch), 128(dim))
        _, idxs = tf.nn.top_k(cos_dists, K_)
        idxs = K.reshape(idxs, [N, K_])
    print('patch_size:', patch_size, 'alpha:', alpha)
    size = {}
    j = 0
    for i in range(3):
        if i in index_h:
            H_, W_ = int(H / patch_size[j] + 1e-3), int(W / patch_size[j] + 1e-3)
            if H % patch_size[j] > 0:
                H_ += 1
            if W % patch_size[j] > 0:
                W_ += 1
            size[j] = H_ * W_ * K_pixel[j]
            j += 1
        Hnew = int(H / 2 + 1e-3)
        Wnew = int(W / 2 + 1e-3)
        if H % 2 > 0:
            Hnew += 1
        if W % 2 > 0:
            Wnew += 1
        H = Hnew
        W = Wnew
    # (1) define d into network by tf.concat, bound: recode the position to help segmentation in network
    # H_, W_ = int(H/patch_size), int(W/patch_size)
    # size = {0:H_*W_, 1:int(H_*W_/4), 2:int(H_*W_/16)}
    bound = [0]
    s = 0
    for i in range(len(index_h)):
        s += size[i]
        bound.append(s)
    d = tf.random_normal(shape=(N, s, 1))
    # (2) VAT
    d = FLAGS.xi * get_normalized_vector(d)
    # print(idxs)
    for _ in range(FLAGS.num_power_iterations):
        logit_p = logit
        logit_m, idxs_pixel = forward(x, update_batch_stats=False, is_training=is_training,
                                      pars=[0, d, [idxs, None], K_, K_pixel, index_h, patch_size, bound, alpha])
        dist = L.kl_divergence_with_logit(logit_p, logit_m)
        grad = tf.gradients(dist, [d], aggregation_method=2)[0]
        d = tf.stop_gradient(grad)
        d = get_normalized_vector(d)
    d = FLAGS.epsilon * d
    logit = tf.stop_gradient(logit)
    logit_p = logit
    logit_m, _ = forward(x, update_batch_stats=False, is_training=is_training,
                         pars=[1, d, [idxs, idxs_pixel], K_, K_pixel, index_h, patch_size, bound, alpha])
    loss = L.kl_divergence_with_logit(logit_p, logit_m)
    return tf.identity(loss, name=name)
