# RMSProp Script
python -m torch.distributed.launch --nproc_per_node=8 --master_port=2347 train.py --config exp_results/res50-rmsprop/lr1e-4/args.yaml
# RMSProp with Momentum Script
python -m torch.distributed.launch --nproc_per_node=8 --master_port=2347 train.py --config exp_results/res50-rmsprop-0.9mom/lr1e-4/args.yaml