## Code Organization
There are 3 main folders in this repository, `cifar`, `ImageNet`, and `language_tasks`, which contain the code for the experiments on CIFAR-100, ImageNet, and GPT-2, respectively. For each task, we have wrapped the entry commands in the file `run.sh`. You can easily reproduce the results by running them. 
