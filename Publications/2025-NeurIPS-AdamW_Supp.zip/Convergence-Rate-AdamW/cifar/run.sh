python train.py \
    -dataset CIFAR100 \
    -net resnet50 \
    -b 128 \
    -opt adamw \
    -lr 0.003 \
    -wd 0.1 