## Env:

### Hardware Configuration

Ubuntu 16.04.3 LTS operating system with 2 * Intel Xeon E5-2660 v3 @ 2.60GHz CPU (40 CPU cores, 10 cores per physical CPU, 2 threads per core), 256 GB of RAM, and 4 * GeForce GTX TITAN X GPU with 12GB of VRAM.

### Software Configuration

```shell
conda create -n cfr-df python=3.8
conda activate cfr-df
pip install numpy==1.24.2, pandas==2.0.0, torch==2.0.0
```

## Run files:

```shell
python simulation.py
python cfr_df.py
```

## Public Data:

[AIDS](https://scikit-survival.readthedocs.io/)
[JOBS](http://www.fredjo.com/)
[TWINS](https://www.nber.org/research/data/linked-birthinfant-death-cohort-data/)
