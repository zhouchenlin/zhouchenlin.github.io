clear all
clc

%%%add functions
%%%for LPDE
addpath('.\PDE_functions\');

InImage = dir('.\data\input\*.bmp');
testImage = dir('.\data\input\*.bmp');
%%set parameters
glo={};
glo.lamta=20;
glo.dt=0.05;
glo.M=60;
glo.eps=0.01*glo.M/(255*255);
glo.width=154;
glo.height=154;
glo.gapWidth=2;
glo.maxIter=20;
glo.selfInit=1;
glo.INV=69;


%%text parameter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Uinv=zeros(glo.width,glo.height,3,glo.M);
Uout=zeros(glo.width,glo.height,3,glo.M);

% Ind=randperm(length(InImage));

for l=1:1
%     glo.M= 20+20*t;
      glo.dt=0.05;
    for s=1:glo.M
        tempin_path=['.\data\input\' InImage(s).name];
        temp_inImage=imread(tempin_path);
        Uinv_temp=temp_inImage;
        Uinv_temp=im2double(Uinv_temp);
        Uinv(3:glo.width-2,3:glo.height-2,:,s)= Uinv_temp;
%         Uinv(3:glo.width-2,3:glo.height-2,2,s)= Uinv_temp;
        
        tempout_path=['.\data\output\' InImage(s).name];
        temp_outImage=imread(tempout_path);
        temp_outImage=im2double(temp_outImage);
        Uout(3:glo.width-2,3:glo.height-2,:,s)=temp_outImage;
    end
    
    tic
    [a,b,Err]=train_auto(Uinv,Uout,glo);
    toc
    %%%test
    T=size(a,3);
    
    Uinv_test=zeros(glo.width,glo.height,3);
   for s=1:length(testImage)
    %    for s=1:60
        tempin_path=['.\data\input\' testImage(s).name];
        temp_inImage=imread(tempin_path);
        Uinv_temp=temp_inImage;
        Uinv_temp=im2double(Uinv_temp);
        Uinv_test(3:glo.width-2,3:glo.height-2,:)= Uinv_temp;
   
        U=Uinv_test;
%         temp1=myRGB2Lab(Uinv_test);
%         V=temp1(:,:,1);
 %       V=rgb2gray(Uinv_test);
       V=0.299*Uinv_test(:,:,1)+0.587*Uinv_test(:,:,2)+0.114*Uinv_test(:,:,3);
        for t=1:T
            Inv=geneInv_auto(U,glo,V);
            if t<T
                    U=pdeStep_auto(U,Inv,a(:,:,t),glo);
%                 U(1:2:149,2:2:150,1)=Uinv_test(1:2:149,2:2:150,1);
%                 U(1:2:149,1:2:149,2)=Uinv_test(1:2:149,1:2:149,2);
%                 U(2:2:150,2:2:150,2)=Uinv_test(2:2:150,2:2:150,2);
%                 U(2:2:150,1:2:149,3)=Uinv_test(2:2:150,1:2:149,3);
                V=pdeStep_auto(V,Inv,b(:,t),glo);
            else
                for k=1:3
                    U(:,:,k)=pdeStep_auto(U(:,:,k),Inv,a(:,k,t),glo);
                end
%                 U(1:2:149,2:2:150,1)=Uinv_test(1:2:149,2:2:150,1);
%                 U(1:2:149,1:2:149,2)=Uinv_test(1:2:149,1:2:149,2);
%                 U(2:2:150,2:2:150,2)=Uinv_test(2:2:150,2:2:150,2);
%                 U(2:2:150,1:2:149,3)=Uinv_test(2:2:150,1:2:149,3);
            end

        end
        
        
        temp=U(3:glo.width-2,3:glo.height-2,:);
        temp=255*temp;
        temp(find(temp<0))=0;
        temp(find(temp>255))=255;
        temp=uint8(temp);
        tempresult_path=['.\data\result\' testImage(s).name];
        imwrite(temp,tempresult_path,'bmp');

    end
end
