function [mse,psnr] = psnr_mse(image,image_prime)
    % convert to doubles
  %  if max(max(image))>20
        image=double(image);
        image_prime=double(image_prime);
  %  else
  %      image=255*double(image);
   %     image_prime=255*double(image_prime);
  %  end
    [M,N]=size(image);

    % avoid divide by zero nastiness
    if ((sum(sum((image-image_prime).^2))) == 0)    
       % error('Input vectors must not be identical')
        mse=0;
        psnr=60;
    else
        mse=sum(sum((image-image_prime).^2))/(M*N);        
        psnr=10*log10(255^2/mse);                           
    end
return