function sigma=geneSigmaO(Uin,a,p,q,glo,Index,V)
% //************************************************************************
% //*  Function Name: geneSigmaO
% //*  Function Description: 
% //*      generate Sigma for O
% //*  Arguments: 
% //*      [IN] : Uin
% //*      [IN] : psi
% //*      [OUT] : sigma
% //*      [IN] : a
% //*      [IN] : p
% //*      [IN] : q
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2013-11-25 23:35:25 by Zhenyu Zhao
% //***********************************************************************
% *

if nargin == 6
    ll=size(Uin,3);
    for i=1:ll
        Dif_v(:,:,:,i)=DifImage(Uin(:,:,i));
    end
else if nargin == 7
        l1=size(Uin,3);
        l2=size(V,3);
        ll=l1+l2;
        for i=1:l1
        Dif_v(:,:,:,i)=DifImage(Uin(:,:,i));
        end
        for i=l1+1:ll
        Dif_v(:,:,:,i)=DifImage(V(:,:,i-l1));
        end
    end
end

sigma=zeros(glo.width,glo.height);

ind=invInd(p,q);
switch ind;
    case 1;
        sigma(:,:)=a(Index+1);
    case 2;
        id=1;
        for i=1:ll
            for j=i:ll
                if i==Index&&j==Index
                    sigma=sigma+a(1+ll+id)*2*Dif_v(:,:,2,i);
                else if i==Index
                        sigma=sigma+a(1+ll+id)*Dif_v(:,:,2,j);
                    else if j==Index
                            sigma=sigma+a(1+ll+id)*Dif_v(:,:,2,i);
                        end
                    end
                end
                id=id+1;
            end
        end
       id=1;
        for i=1:ll
            for j=i:ll
                for k=1:ll
                    if i==Index&&j==Index
                        sigma=sigma+a(1+2*ll+ll*(ll+1)/2+id)*(2*Dif_v(:,:,2,i).*Dif_v(:,:,4,k)+2*Dif_v(:,:,3,i).*Dif_v(:,:,5,k));
                    else if i==Index
                            sigma=sigma+a(1+2*ll+ll*(ll+1)/2+id)*(Dif_v(:,:,2,j).*Dif_v(:,:,4,k)+Dif_v(:,:,3,j).*Dif_v(:,:,5,k));
                        else if j==Index
                                sigma=sigma+a(1+2*ll+ll*(ll+1)/2+id)*(Dif_v(:,:,2,i).*Dif_v(:,:,4,k)+Dif_v(:,:,3,i).*Dif_v(:,:,5,k));
                            end
                        end
                    end
                    id=id+1;
                end
            end
        end
    case 3;
        id=1;
        for i=1:ll
            for j=i:ll
                if i==Index&&j==Index
                    sigma=sigma+a(1+ll+id)*2*Dif_v(:,:,3,i);
                else if i==Index
                        sigma=sigma+a(1+ll+id)*Dif_v(:,:,3,j);
                    else if j==Index
                            sigma=sigma+a(1+ll+id)*Dif_v(:,:,3,i);
                        end
                    end
                end
                id=id+1;
            end
        end
        id=1;
        for i=1:ll
            for j=i:ll
                for k=1:ll
                    if i==Index&&j==Index
                        sigma=sigma+a(1+2*ll+ll*(ll+1)/2+id)*(2*Dif_v(:,:,3,i).*Dif_v(:,:,6,k)+2*Dif_v(:,:,2,i).*Dif_v(:,:,5,k));
                    else if i==Index
                            sigma=sigma+a(1+2*ll+ll*(ll+1)/2+id)*(Dif_v(:,:,3,j).*Dif_v(:,:,6,k)+Dif_v(:,:,2,j).*Dif_v(:,:,5,k));
                        else if j==Index
                                sigma=sigma+a(1+2*ll+ll*(ll+1)/2+id)*(Dif_v(:,:,3,i).*Dif_v(:,:,6,k)+Dif_v(:,:,2,i).*Dif_v(:,:,5,k));
                            end
                        end
                    end
                    id=id+1;
                end
            end
        end
    case 4;
        sigma=sigma+a(1+ll+ll*(ll+1)/2+Index);
        id=1;
        for i=1:ll
            for j=i:ll
                for k=1:ll
                    if k==Index
                        sigma=sigma+a(1+2*ll+ll*(ll+1)/2+id)*Dif_v(:,:,2,i).*Dif_v(:,:,2,j);
                    end
                id=id+1;
                end
            end
        end
        id=1;
        for i=1:ll
            for j=i:ll
                if i==Index&&j==Index
                    sigma=sigma+a(1+2*ll+ll*(ll+1)/2+ll*ll*(ll+1)/2+id)*2*Dif_v(:,:,4,i);
                else if i==Index
                        sigma=sigma+a(1+2*ll+ll*(ll+1)/2+ll*ll*(ll+1)/2+id)*Dif_v(:,:,4,j);
                    else if j==Index
                            sigma=sigma+a(1+2*ll+ll*(ll+1)/2+ll*ll*(ll+1)/2+id)*Dif_v(:,:,4,i);
                        end
                    end
                end
                id=id+1;
            end
        end
    case 5;
          id=1;
        for i=1:ll
            for j=i:ll
                for k=1:ll
                    if k==Index
                        sigma=sigma+a(1+2*ll+ll*(ll+1)/2+id)*(Dif_v(:,:,2,i).*Dif_v(:,:,3,j)+Dif_v(:,:,3,i).*Dif_v(:,:,2,j));
                    end
                id=id+1;
                end
            end
        end
        id=1;
        for i=1:ll
            for j=i:ll
                if i==Index&&j==Index
                    sigma=sigma+a(1+2*ll+ll*(ll+1)/2+ll*ll*(ll+1)/2+id)*4*Dif_v(:,:,5,i);
                else if i==Index
                        sigma=sigma+a(1+2*ll+ll*(ll+1)/2+ll*ll*(ll+1)/2+id)*2*Dif_v(:,:,5,j);
                    else if j==Index
                            sigma=sigma+a(1+2*ll+ll*(ll+1)/2+ll*ll*(ll+1)/2+id)*2*Dif_v(:,:,5,i);
                        end
                    end
                end
                id=id+1;
            end
        end
    case 6;
        sigma=sigma+a(1+ll+ll*(ll+1)/2+Index);
        id=1;
        for i=1:ll
            for j=i:ll
                for k=1:ll
                    if k==Index
                        sigma=sigma+a(1+2*ll+ll*(ll+1)/2+id)*Dif_v(:,:,3,i).*Dif_v(:,:,3,j);
                    end
                id=id+1;
                end
            end
        end
        id=1;
        for i=1:ll
            for j=i:ll
                if i==Index&&j==Index
                    sigma=sigma+a(1+2*ll+ll*(ll+1)/2+ll*ll*(ll+1)/2+id)*2*Dif_v(:,:,6,i);
                else if i==Index
                        sigma=sigma+a(1+2*ll+ll*(ll+1)/2+ll*ll*(ll+1)/2+id)*Dif_v(:,:,6,j);
                    else if j==Index
                            sigma=sigma+a(1+2*ll+ll*(ll+1)/2+ll*ll*(ll+1)/2+id)*Dif_v(:,:,6,i);
                        end
                    end
                end
                id=id+1;
            end
        end
    otherwise
        disp('[p q] is wrong.')
end
function Ind=invInd(p,q);

if p==0&&q==0
    Ind=1;
else if p==1&&q==0
        Ind=2;
    else if p==0&&q==1
            Ind=3;
        else if p==2&&q==0
                Ind=4;
            else if p==1&&q==1
                    Ind=5;
                else
                    Ind=6;
                end
            end
        end
    end
end
