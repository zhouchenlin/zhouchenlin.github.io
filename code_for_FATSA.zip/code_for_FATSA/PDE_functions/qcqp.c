#include "mex.h"
double MIN_DOUBLE=1e-15;

double lineFunW (double *F, double *b, double c, double *a, double *d);
double funW (double *F, double *b, double c, double *a, double *d, double w);
void multiply (double *A, double *b, double *Ab, int n)
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		Ab[i] = 0.0;
		for (j = 0; j < n; j++)
		{
			Ab[i] = Ab[i] + A[i * n + j] * b[j];
		}
	}
	return;
}


double innerProduct (double *a, double *b, int n)
{
	int i;
	double sum;
	sum = 0.0;
	for (i = 0; i < n; i++)
	{
		sum = sum + a[i] * b[i];
	}
	return sum;
}

void qcqp (double *F, double *b, double c, double *a)
{
	int i;
    double g[69], p[69], d[69];
	double r = 1e-6;
	int counter = 0;
	double beta, phi;
	double eps = 1e-6;
	double lastPhi = eps + 1.0;

	for (i = 0; i < 69; i++)
	{
		a[i] = 0;
	}


	while (lastPhi > eps)
	{
		//compute gradient
		//cout<<"###grad"<<endl;
		multiply(F, a, g, 69);
		for (i = 0; i < 69; i++)
		{
			g[i] = g[i] - b[i];
		}


		if (counter == 0)
		{
			for (i = 0; i < 69; i++)
			{
				d[i] = -g[i];
			}
		}
		else
		{
			beta = 0.0;
			for (i = 0; i < 69; i++)
			{
				beta = beta + g[i] * (g[i] + p[i]);
			}
			beta = beta / innerProduct(p, p, 69);
			beta = (beta > 0) ? beta : 0;
			for (i = 0; i < 69; i++)
			{
				d[i] = - g[i] + beta * d[i];
			}
		}
		for (i = 0; i < 69; i++)
		{
			p[i] = - g[i];
		}

		//line minimization and update solution
		phi = lineFunW(F, b, c, a, d);

		if (fabs(lastPhi - phi) < 1e-6 * phi)
		{
			break;
		}
		lastPhi = phi;

		//cout<<phi<<endl;

		counter++;
	}


	return;
}


//************************************************************************
//*  Function Name: lineFunW 
//*  Function Description: 
//*      
//*  Arguments: 
//*      [IN] : double *F
//*      [IN] : double *b
//*      [IN] : double c
//*      [IN] : double *a
//*      [IN] : double *d
//* 
//*  Return Value: double search direction weight
//*      none.
//* 
//*  Last Modified on: 2009-8-9 13:16:13 by Risheng Liu
//************************************************************************

double lineFunW (double *F, double *b, double c, double *a, double *d)
{
	int i;
	double w[4], wn, lim, p[4], ene, weps;

	/*weps = 0.0;
	for (i = 0; i < aLength; i++)
	{
		if (fabs(d[i]) > weps)
		{
			weps = fabs(d[i]);
		}
	}*/
	weps = 1.0e-5 / (innerProduct(d, d, 69) + MIN_DOUBLE);

	//bracket

	w[0] = 0.0;
	p[0] = funW (F, b, c, a, d, w[0]);
	w[1] = weps;   // intial bracket for bracket search
	p[1] = funW (F, b, c, a, d, w[1]);
	if (p[0] < p[1])
	{
		wn = w[0];
		w[0] = w[1];
		w[1] = wn;
	}
	w[2] = w[1] + 1.618 * (w[1] - w[0]);
	p[2] = funW (F, b, c, a, d, w[2]);
	while (p[1] > p[2] && w[1] != w[2] && fabs(w[2]) < 1e5)
	{
		w[3] = 0.5 * ((w[1] * w[1] - w[2] * w[2]) * p[0] + (w[2] * w[2] - w[0] * w[0]) * p[1]
			+ (w[0] * w[0] - w[1] * w[1]) * p[2]) /
			((w[1] - w[2]) * p[0] + (w[2] - w[0]) * p[1] + (w[0] - w[1]) * p[2] + MIN_DOUBLE);
		lim = w[1] + 1000 * (w[2] - w[1]);
		//cout<<"-----------exterpolation: "<<w[0]<<" "<<w[1]<<" "<<w[2]<<" "<<w[3]<<endl;
		if ((w[3] - w[2]) * (w[1] - w[3]) > 0)    //w[3] is between w[1] and w[2]
		{
			p[3] = funW (F, b, c, a, d, w[3]);
			//cout<<"-----------exterpolation: "<<p[2]<<" "<<p[3]<<"w: "<<w[2]<<w[3]<<endl;
			if (p[3] < p[2])                      //get a minimum between w[1] and w[2]
			{
				w[0] = w[1];
				break;
			}
			else if (p[3] > p[1])                 //get a minimum between w[0] and w[3]
			{
				w[2] = w[3];
				break;
			}
			w[3] = w[2] + 1.618 * (w[2] - w[1]);
			p[3] = funW (F, b, c, a, d, w[3]);
		}
		else if ((w[2] - w[3]) * (w[3] - lim) > 0) //w[3] is between w[2] and lim
		{
			p[3] = funW (F, b, c, a, d, w[3]);
			if (p[3] < p[2])
			{
				w[1] = w[2];
				p[1] = p[2];
				w[2] = w[3];
				p[2] = p[3];
				w[3] = w[2] + 1.618 * (w[2] - w[1]);
				p[3] = funW (F, b, c, a, d, w[3]);
			}
		}
		else if ((w[3] - lim) * (lim - w[2]) >= 0)
		{
			w[3] = lim;
			p[3] = funW (F, b, c, a, d, w[3]);
		}
		else
		{
			w[3] = w[2] + 1.618 * (w[2] - w[1]);
			p[3] = funW (F, b, c, a, d, w[3]);
		}
		w[0] = w[1];
		p[0] = p[1];
		w[1] = w[2];
		p[1] = p[2];
		w[2] = w[3];
		p[2] = p[3];
	}
	//output bracket (w[0], w[2])

	//search
	//cout<<"@@@search"<<endl;
	w[3] = w[2];              //bracket (w[0], w[3])
	w[1] = w[3] - 0.618 * (w[3] - w[0]);
	w[2] = w[0] + 0.618 * (w[3] - w[0]);
	p[1] = funW (F, b, c, a, d, w[1]);
	p[2] = funW (F, b, c, a, d, w[2]);
	while(fabs(w[3] - w[0]) > 0.01 * (weps + fabs(w[1]) + fabs(w[2]))) //0.001 * (fabs(w[1]) + fabs(w[2]) + 0.1))
	{
		//cout<<"***********golden section: "<<w[0]<<" "<<w[3]<<endl;
		//cout<<p[1]<<" "<<p[2]<<endl;
		if (p[1] > p[2])
		{
			w[0] = w[1];
			w[1] = w[2];
			w[2] = w[0] + 0.618 * (w[3] - w[0]);
			p[1] = p[2];
			p[2] = funW (F, b, c, a, d, w[2]);
		}
		else //if (p[1] < p[2])
		{
			w[3] = w[2];
			w[2] = w[1];
			w[1] = w[3] - 0.618 * (w[3] - w[0]);
			p[2] = p[1];
			p[1] = funW (F, b, c, a, d, w[1]);
		}
	}
	p[0] = funW (F, b, c, a, d, w[0]);
	p[3] = funW (F, b, c, a, d, w[3]);
	wn = w[0];
	ene = p[0];
	for (i = 1; i <= 3; i++)
	{
		if (p[i] < ene)
		{
			wn = w[i];
			ene = p[i];
		}
	}

	for (i = 0; i < 69; i++)
	{
		a[i] = a[i] + wn * d[i];
	}

	return ene;
}



//************************************************************************
//*  Function Name: funW 
//*  Function Description: 
//*      
//*  Arguments: 
//*      [IN] : double *F
//*      [IN] : double *b
//*      [IN] : double c
//*      [IN] : double *a
//*      [IN] : double *d
//*      [IN] : double w
//* 
//*  Return Value: double function value
//*      none.
//* 
//*  Last Modified on: 2009-8-9 13:14:30 by Risheng Liu
//************************************************************************

double funW (double *F, double *b, double c, double *a, double *d, double w)
{
	int i;
	double phi;
	double r = 1e-6;

	double aTmp[69], p[69];
	for (i = 0; i < 69; i++)
	{
		aTmp[i] = a[i] + w * d[i];
	}

	multiply(F, aTmp, p, 69);

	phi = (innerProduct(aTmp, p, 69) + c) / 2 - innerProduct(aTmp, b, 69);

	return phi;
}

void mexFunction(int nlhs, mxArray *plhs[],int nrhs,const mxArray *prhs[])
{
 double *inMatrix;
 double *inVector;
 double *outMatrix;
 double ncols;
 inMatrix=mxGetPr(prhs[0]);
 inVector=mxGetPr(prhs[1]);
 ncols=mxGetScalar(prhs[2]);
 plhs[0]=mxCreateDoubleMatrix(69,1,mxREAL);
 outMatrix=mxGetPr(plhs[0]);
 qcqp(inMatrix,inVector,ncols,outMatrix);
}