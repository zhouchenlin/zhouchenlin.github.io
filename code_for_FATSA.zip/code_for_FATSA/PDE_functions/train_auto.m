function [a,b,Err]=train_auto(U,Uout,glo)

% 
% //************************************************************************
% //*  Function Name: train 
% //*  Function Description: 
% //*      learn coefficient function from image pairs
% //*  Arguments: 
% //*      [IN] : string inFilePath
% //*      [IN] : string outFilePath
% //*      [OUT] : double *a
% //*      [IN] : globalParam
% //* 
% //*  Return Value: a
% //*      none.
% //* 
% //*  Last Modified on: 2014-04-03 10:47:48 by Zhenyu Zhao
% //************************************************************************

U_last=U;
V_last(:,:,:)=0.299*U(:,:,1,:)+0.587*U(:,:,2,:)+0.114*U(:,:,3,:);
Err=[];
b(:,1)=zeros(glo.INV,1);
%     for k=1:3
%         [a(:,k,1),phi]=stepa_split(U_last,U,V_last,Uout,b(:,1),glo,k);
%     end
[a(:,:,1),phi]=stepa(U,V_last,Uout,glo);
for s=1:glo.M
    Inv=geneInv_auto(U_last(:,:,:,s),glo,V_last(:,:,s));
        U(:,:,:,s)=pdeStep_auto(U_last(:,:,:,s),Inv,a(:,:,1),glo);
%     U(1:2:149,2:2:150,1,s)=U_last(1:2:149,2:2:150,1,s);
%     U(1:2:149,1:2:149,2,s)=U_last(1:2:149,1:2:149,2,s);
%     U(2:2:150,2:2:150,2,s)=U_last(2:2:150,2:2:150,2,s);
%     U(2:2:150,1:2:149,3,s)=U_last(2:2:150,1:2:149,3,s);
end
Err=[Err phi]
V=V_last;
MaxDerr=phi;
t=2;
while MaxDerr>glo.eps&&t<20
    b(:,t-1)=zeros(glo.INV,1);
    counter=1;
    MaxDb=glo.eps+1;
  %  tic
    while MaxDb>glo.eps&&counter<5
        [a(:,:,t),err(1)]=stepa(U,V,Uout,glo);
        %             err(counter,1)
      [tempb,err(2),U_next,V]=stepb(U_last,U,V_last,Uout,a(:,:,t),b(:,t-1),glo);
%                                tempb=zeros(glo.INV,1);
%                                err(2)=err(1);
                     err(2)
        MaxDb=max(abs(tempb-b(:,t-1)));
        b(:,t-1)= tempb;
        counter=counter+1;
        if abs(err(1)-err(2))<glo.eps
            break;
        end
    end
  %  MaxDerr=abs(err(2)-phi);
    MaxDerr=phi-err(2);
    phi=err(2);
    Err=[Err phi]
 %   toc
  V_last=V;
 U_last=U;
 U=U_next;
%     if mod(t,5)==0
%          U(find( U<-0.1))=-0.1;
%          U(find( U>1.1))=1.1;
%     end
    
    t=t+1;
end


