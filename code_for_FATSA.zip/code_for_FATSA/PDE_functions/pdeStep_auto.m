function U_next=pdeStep_auto(U,Inv,a,glo)
% //************************************************************************
% //*  Function Name: pdeStep
% //*  Function Description: 
% //*      solve the pde step by step
% //*  Arguments: 
% //*      [IN] :U_temp
% //*      [IN] : U
% //*      [OUT] : DifImage_T U_next
% //*      [IN] : a_temp
% //*      [IN] : glo
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2014-3-10 21:25:52 by Zhenyu Zhao
% //************************************************************************
NN=size(U,3);
if NN>1
    temp=zeros(glo.width,glo.height,3);
    
    for i=1:glo.INV
        temp(:,:,1)=temp(:,:,1)+a(i,1)*Inv((i-1)*glo.width+1:i*glo.width,:);
        temp(:,:,2)=temp(:,:,2)+a(i,2)*Inv((i-1)*glo.width+1:i*glo.width,:);
        temp(:,:,3)=temp(:,:,3)+a(i,3)*Inv((i-1)*glo.width+1:i*glo.width,:);
    end
    U_next=U+glo.dt*temp;
    U_next(1,:,:)=0;
    U_next(glo.width,:,:)=0;
    U_next(:,1,:)=0;
    U_next(:,glo.height,:)=0;
else
    temp=zeros(glo.width,glo.height);
    
    for i=1:glo.INV
        temp(:,:)=temp(:,:)+a(i)*Inv((i-1)*glo.width+1:i*glo.width,:);
    end
    U_next=U+glo.dt*temp;
    U_next(1,:)=0;
    U_next(glo.width,:)=0;
    U_next(:,1)=0;
    U_next(:,glo.height)=0;
end