function [a,phi]=stepa(U,V,O,glo)
% //************************************************************************
% //*  Function Name: stepInit 
% //*  Function Description: 
% //*      
% //*  Arguments: 
% //*      [IN] : DifImage_T *pGen
% //*      [IN] : DifImage_T *pIdc
% //*      [IN] : DifImage_T *outImage
% //*      [OUT] : double *a
% //*      [IN] : int t
% //*      [IN] : GlobalParam_T &globalParam
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2014-3-10 22:10:11 by Zhenyu Zhao
% //************************************************************************
       n=glo.width*glo.height;
       c=zeros(3,1);
       g=zeros(glo.INV,3);
       G=zeros(glo.INV,glo.INV);
       for s=1:glo.M 
           d_temp=(O(:,:,:,s)-U(:,:,:,s))/glo.dt;
           Inv=geneInv_auto(U(:,:,:,s),glo,V(:,:,s));
           for k=1:3
               c(k)=c(k)+trace(d_temp(:,:,k)'*d_temp(:,:,k));
               for i=1:glo.INV
                   g(i,k)=g(i,k)+sum(sum(Inv((i-1)*glo.width+1:i*glo.width,:).*d_temp(:,:,k)));
                   if k==1
                       for j=i:glo.INV
                           G(i,j)=G(i,j)+sum(sum(Inv((i-1)*glo.width+1:i*glo.width,:).*Inv((j-1)*glo.width+1:j*glo.width,:)));
                       end
                   end
               end
           end
       end
       
       G=G+G'-diag(diag(G));
       c=c/n;
       g=g/n;
       G=G/n;
     %  G=G/(glo.width*glo.height)+glo.lamta*eye(glo.INV);
       %  a=pinv(G+glo.lamta*eye(glo.INV))*g;
%        G=reshape(G,glo.INV*glo.INV,1);
%        a=qcqp(G,g,c);
       
%%%trust region
C=G^(1/2);
C=real(C);
lb=-glo.lamta*ones(glo.INV,1);
ub=glo.lamta*ones(glo.INV,1);
G=reshape(G,glo.INV*glo.INV,1);
for k=1:3
    d=pinv(C)*g(:,k);
    X0=qcqp(G,g(:,k),c(k));
    G=reshape(G,glo.INV,glo.INV);
    OPTIONS.TolFun=glo.eps;
    OPTIONS.MaxIter=20;
    a(:,k)=lsqlin(C,d,[],[],[],[],lb,ub,X0,OPTIONS);
    phi1(k)=c(k)/2-g(:,k)'*a(:,k)+a(:,k)'*G*a(:,k)/2;
end
 phi=sum(phi1)*glo.dt*glo.dt;
% phi1=sum(c)*glo.dt*glo.dt/2;
 
         