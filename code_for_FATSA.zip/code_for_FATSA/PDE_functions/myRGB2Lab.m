function [L,a,b] = myRGB2Lab(R,G,B)

%%%��L,a,b��һ��

if nargin == 1
  B = double(R(:,:,3));
  G = double(R(:,:,2));
  R = double(R(:,:,1));
end

[L1,a1,b1]=RGB2Lab(R,G,B);
L=L1/100;
a=(a1+110)/220;
b=(b1+110)/220;
if nargout < 2
  L = cat(3,L,a,b);
end