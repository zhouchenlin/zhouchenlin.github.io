function [b,phi,U_next,V]=stepb(U_last,U,V_last,Uout,a,b,glo)
% //************************************************************************
% //*  Function Name: stepInit 
% //*  Function Description: 
% //*      
% //*  Arguments: 
% //*      [IN] : DifImage_T *pGen
% //*      [IN] : DifImage_T *pIdc
% //*      [IN] : DifImage_T *outImage
% //*      [OUT] : double *a
% //*      [IN] : int t
% //*      [IN] : GlobalParam_T &globalParam
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2014-3-10 22:10:11 by Zhenyu Zhao
% //************************************************************************  
       n=glo.width*glo.height;
       c=0.0;
       g=zeros(glo.INV,1);
       G=zeros(glo.INV,glo.INV);
       for s=1:glo.M
           Inv_last(:,:,s)=geneInv_auto(U_last(:,:,:,s),glo,V_last(:,:,s));
           V(:,:,s)=pdeStep_auto(V_last(:,:,s),Inv_last(:,:,s),b,glo);
           Inv=geneInv_auto(U(:,:,:,s),glo,V(:,:,s));
           U_next=pdeStep_auto(U(:,:,:,s),Inv,a(:,:),glo);
           for k=1:3
               h=(Uout(:,:,k,s)-U_next(:,:,k))/glo.dt;
               L=zeros(glo.width,glo.height,glo.INV);
               for i=1:6
                   [p,q]=invInd(i);
   %                sigma1=geneSigmaO_auto(U(:,:,s),a,p,q,glo,V(:,:,s));
                   sigma=geneSigmaO(U(:,:,:,s),a(:,k),p,q,glo,4,V(:,:,s));
                   for j=1:glo.INV
                       d_tmp=DifImage_single1(Inv_last((j-1)*glo.width+1:j*glo.width,:,s),p,q);
                       L(:,:,j)=L(:,:,j)-sigma.*d_tmp;
                   end
               end
               for j=1:glo.INV
                   d_temp=h-b(j)*L(:,:,j);
               end
               c=c+trace(d_temp'*d_temp);
               for i=1:glo.INV
                   g(i)=g(i)+sum(sum(L(:,:,i).*d_temp));
                   for j=i:glo.INV
                       G(i,j)=G(i,j)+sum(sum(L(:,:,i).*L(:,:,j)));
                   end
               end
           end
       end
           
       G=G+G'-diag(diag(G));
      
           
       c=c/(glo.width*glo.height);
       g=-g/(glo.width*glo.height);
       G=G/(glo.width*glo.height);
       
       C=G^(1/2);
       C=real(C);
       d=pinv(C)*g;
       lb=-glo.lamta*ones(glo.INV,1);
       ub=glo.lamta*ones(glo.INV,1);
       
%        G=reshape(G,glo.INV*glo.INV,1);
%        X0=qcqp(G,g,c);
%        G=reshape(G,glo.INV,glo.INV);
       
X0=zeros(glo.INV,1);
    OPTIONS.TolFun=glo.eps;
    OPTIONS.MaxIter=20;
b=lsqlin(C,d,[],[],[],[],lb,ub,X0,OPTIONS);
% c/2*glo.dt*glo.dt
%          phi=c/2-g'*b+b'*G*b/2;
%          phi=phi*glo.dt*glo.dt;
phi=0;
for s=1:glo.M
    %           Inv=geneInv_auto(U_last(:,:,:,s),glo,V_last(:,:,s));
    V(:,:,s)=pdeStep_auto(V_last(:,:,s),Inv_last(:,:,s),b,glo);
    Inv=geneInv_auto(U(:,:,:,s),glo,V(:,:,s));
    U_next(:,:,:,s)=pdeStep_auto(U(:,:,:,s),Inv,a(:,:),glo);
for k=1:3
     phi=phi+sum(sum((Uout(:,:,k,s)-U_next(:,:,k,s)).*(Uout(:,:,k,s)-U_next(:,:,k,s))));
end
end
       phi=phi/(2*n)
     %  phi=phi/n+glo.lamta*sum(a.*a)+glo.lamta*sum(b.*b);
       
       
function [p,q]=invInd(i)

if i==1
    p=0;q=0;
else if i==2
        p=1;q=0;
    else if i==3
            p=0;q=1;
        else if i==4
                p=2;q=0;
            else if i==5
                    p=1;q=1;
                else
                    p=0;q=2;
                end
            end
        end
    end
end

       
    

