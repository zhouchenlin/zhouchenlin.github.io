function inv=geneInv_auto(Uin,glo,V)
% //************************************************************************
% //*  Function Name: geneInv
% //*  Function Description: 
% //*      computes invariant bases inv_i(t).
% //*  Arguments: 
% //*      [IN] : DifImage_T &idc
% //*      [IN] : DifImage_T &gen
% //*      [OUT] : double *invBase
% //* 
% //*  Return Value: void 
% //*      none.
% //* 
% //*  Last Modified on: 2013-11-24 13:46:52 by Zhenyu Zhao
% //************************************************************************
if nargin == 2
    ll=size(Uin,3);
    for i=1:ll
        Dif_v(:,:,:,i)=DifImage1(Uin(:,:,i));
    end
else if nargin == 3
        l1=size(Uin,3);
        l2=size(V,3);
        ll=l1+l2;
        for k=1:l1
        Dif_v(:,:,:,k)=DifImage1(Uin(:,:,k));
        end
        for k=l1+1:ll
        Dif_v(:,:,:,k)=DifImage1(V(:,:,k-l1));
        end
    end
end

%%%inv
inv=ones(glo.width,glo.height);

for i=1:ll
    temp=Dif_v(:,:,1,i);
    inv=[inv; temp];
end

for i=1:ll
    for j=i:ll
        temp=Dif_v(:,:,2,i).*Dif_v(:,:,2,j)+Dif_v(:,:,3,i).*Dif_v(:,:,3,j);
        inv=[inv; temp];
    end
end
    
for i=1:ll
    temp=Dif_v(:,:,4,i)+Dif_v(:,:,6,i);
    inv=[inv; temp];
end

for i=1:ll
    for j=i:ll
        for k=1:ll
            temp=(Dif_v(:,:,2,i).*Dif_v(:,:,4,k)+Dif_v(:,:,3,i).*Dif_v(:,:,5,k)).*Dif_v(:,:,2,j)...
                +(Dif_v(:,:,2,i).*Dif_v(:,:,5,k)+Dif_v(:,:,3,i).*Dif_v(:,:,6,k)).*Dif_v(:,:,3,j);
            inv=[inv; temp];
        end
    end
end

for i=1:ll
    for j=i:ll
        temp=Dif_v(:,:,4,i).*Dif_v(:,:,4,j)+2*Dif_v(:,:,5,i).*Dif_v(:,:,5,j)+Dif_v(:,:,6,i).*Dif_v(:,:,6,j);
        inv=[inv; temp];
    end
end
