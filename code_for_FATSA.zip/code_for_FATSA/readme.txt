﻿The code is for paper "A fast alternating time-splitting approach
for learning partial differential equations" 
by  Zhenyu Zhao,  Zhouchen Lin, Yi Wu.
to appear in Neurocomputing(2016).http://dx.doi.org/10.1016/j.neucom.2015.10.126
written by Zhenyu Zhao.
Email: dwightzzy@gmail.com
******************************************************************************************************************
The code is tested on Windows 8 with MATLAB R2013b.
******************************************************************************************************************
Usage:
>run 'main.m'

