#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
import re

def main(argv):
    rsrcmgr = PDFResourceManager()
    outfp = file(argv[1][0:-4] + '.out', 'w')
    codec = 'utf-8'
    laparams = LAParams()
    device = TextConverter(rsrcmgr, outfp, codec=codec, laparams=laparams)
    fp = file(argv[1], 'rb')
    interpreter = PDFPageInterpreter(rsrcmgr, device)
    for page in PDFPage.get_pages(fp):
        interpreter.process_page(page)
    fp.close()
    device.close()
    outfp.close()

    checkfile = argv[1][0:-4] + '.out'
    resultfile = argv[1][0:-4] + '_check_result.out'

    f1 = open(checkfile, 'r')
    f2 = open(resultfile, 'w')
    checklist = f1.readlines()

    f2.write('*** Use passive tense as few as possible. ***\n')
    f2.write('\n* There are some irregular past participles, please check them. *\n\n')
    f3 = open('past_participle.txt', 'r')
    plist = f3.readlines()
    a = 1
    for line in checklist:
        b = 1
        for word in plist:
            rule = r"^.*\b" + word.strip() + r"\b.*$"
            if line != '\n' and re.match(rule, line):
                f2.write(str(a) + ' ' + line),
                break
            b+=1
        a+=1
    f3.close()
    
    f2.write('\n* There may be some past participles end with "-ed", please check them. *\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*ed\b.*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** When using an acronym, give its full name when it first appears (except in title), e.g., "Principal Component Analysis (PCA)." ***\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*\b[A-Z]{2,}\b.*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** Make clear the usage of "a" and "an". ***\n\n')
    f_a = open('a_.txt', 'r')
    f_an = open('an_.txt', 'r')
    check_a = f_a.readlines()
    check_an = f_an.readlines()

    rule = r"((^(A|.*\W A|.*\ba)\b (?!(one"

    for line in check_a:
        rule += "|" + line.strip() + "\W"

    rule += "))([aeiou]"

    for line in check_an:
        rule += "|" + line.strip()

    rule += r"))|(^(An|.*\W An|.*\ban)\b (?!(hour"

    for line in check_an:
        rule += "|" + line.strip() + "\W"

    rule += "))([b-df-hj-np-tv-z]"

    for line in check_a:
        rule += "|" + line.strip()

    rule += r"))).*$"

    a = 1
    for line in checklist:
        if line != '\n' and re.match(rule, line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** If there are only two objects, A and B, write "A and B". Do not write "A, B". ***\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*\b\w*\b, \b[^(etc)(respectively)]\w*\b\..*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** If there are more than two objects, A, B, ..., Y, and Z, normally you can write both "A, B, ..., Y, and Z" and "A, B, ..., Y and Z". However, the former is recommended. ***\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*\b\w*\b, \b\w*\b and \b\w*\b.*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** Do not write "A, B, and C, etc." Write "A, B, C, etc." instead. ***\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*\b, and \b\w*\b, etc\..*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** Do not write "isn\'t", "aren\'t", "don\'t", "doesn\'t", etc. Those are for spoken communication. Write "is not", "are not", "do not", "does not", etc., instead. ***\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*n\’t.*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** Do not write "can not". Write "cannot" instead. ***\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*can not.*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** Notice the correct dots in "e.g.", "etc.", "et al.", etc. ***\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*\be\.g\b[^\.].*$', line) \
                        or re.match(r'^.*\be[^\.]?g\b.*$', line) \
                        or re.match(r'^.*\betc\b[^\.].*$', line) \
                        or re.match(r'^.*\bet\.?al\b.*$', line) \
                        or re.match(r'^.*\bet al\b[^\.].*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** Put a comma before "respectively". ***\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*[^,] respectively.*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** Leave a space between texts and left parenthesis, left bracket, or citation. Also leave a space between comma or period and the successive texts. ***\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*((\S(\(|\[))|((,|\.)\w)).*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** If you refer to multiple figures or tables simultaneously, write "Figures A and B" or "Tables A and B", rather than "Figure A and Figure B" or "Table A and Table B." ***\n\n')
    a = 1
    for line in checklist:
        if line != '\n' and re.match(r'^.*((Figure \b\w*\b,? )+and Figure \b\w*\b)|((Table \b\w*\b,? )+and Table \b\w*\b).*$', line):
            f2.write(str(a) + ' ' + line)
        a+=1

    f2.write('\n*** Every reference must be cited in the body text. ***\n\n')
    f3 = open(checkfile, 'r')
    p = f3.read()
    divide = p.find("REFERENCES")
    if divide == -1:
        f2.write("No reference found in this paper.\n")
    else:
        num = p[divide:].count("[")
        flag = 1
        for x in range(num):
            x += 1
            if p[:divide].find("[" + str(x) + "]") < 0:
                flag = 0
                f2.write("The reference [" + str(x) + "] is not cited in the body text.\n")
        if flag == 1:
            f2.write("All the references are cited in the body text.\n")
    f3.close()

    f1.close()
    f2.close()

    return

if __name__ == '__main__': sys.exit(main(sys.argv))