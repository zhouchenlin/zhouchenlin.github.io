#!/usr/bin/env python
__version__ = '20140328'

if __name__ == '__main__':
    print (__version__)
