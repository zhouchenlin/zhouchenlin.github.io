import os
import logging

channel = 10
stage_num = 3
depth = 7 # >=3
use_se = True 
uint = 'GRU' # ['Conv', 'RNN', 'GRU', 'LSTM']
frame = 'Full' # ['Add', 'Full']
inner_stage = 3

aug_data = False # Set as False for fair comparison

batch_size = 2
patch_size = 512
lr = 1e-3
pixel_max = 4257
pixel_min = -534
pixel_25 = 31.0
pixel_75 = 982.3
pixel_range = 4.37
pixel_MAX = 4.5

data_dirs = {
    'train': '/data/3mm/useful_data/60/2/train/',
    'valid': '/data/3mm/useful_data/60/2/test/',
    'test': '/data/3mm/useful_data/60/2/test/'
}

log_dir = '../logdir'
show_dir = '../showdir'
model_dir = '../models'

log_level = 'info'
model_path = os.path.join(model_dir, 'latest')
save_steps = 400

num_workers = 16
num_GPU = 1
device_id = 2

logger = logging.getLogger('train')
logger.setLevel(logging.INFO)

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)

formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)

############################ DD_NET #################################
base_channel = 16 



