import os
import sys
import cv2
import argparse
import numpy as np
import pdb

import torch
from torch import nn
from torch.nn import MSELoss
from torch.optim import Adam
from torch.optim.lr_scheduler import MultiStepLR
from torch.autograd import Variable
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter

import settings
from dataset import TestDataset
from model import R2
from cal_ssim import SSIM

logger = settings.logger
torch.cuda.manual_seed_all(66)
torch.manual_seed(66)
torch.cuda.set_device(settings.device_id)


def ensure_dir(dir_path):
    if not os.path.isdir(dir_path):
        os.makedirs(dir_path)
        

class Session:
    def __init__(self):
        self.log_dir = settings.log_dir
        self.model_dir = settings.model_dir
        ensure_dir(settings.log_dir)
        ensure_dir(settings.model_dir)
        logger.info('set log dir as %s' % settings.log_dir)
        logger.info('set model dir as %s' % settings.model_dir)

        self.net = R2().cuda()
        self.crit = MSELoss().cuda()
        self.ssim = SSIM().cuda()
        self.dataloaders = {}

    def get_dataloader(self, dataset_name):
        dataset = TestDataset(dataset_name)
        if not dataset_name in self.dataloaders:
            self.dataloaders[dataset_name] = \
                    DataLoader(dataset, batch_size=1, 
                            shuffle=False, num_workers=1, drop_last=False)
        return self.dataloaders[dataset_name]

    def load_checkpoints(self, name):
        ckp_path = os.path.join(self.model_dir, name)
        try:
            obj = torch.load(ckp_path)
            logger.info('Load checkpoint %s' % ckp_path)
        except FileNotFoundError:
            logger.info('No checkpoint %s!!' % ckp_path)
            return
        self.net.load_state_dict(obj['net'])

    def inf_batch(self, name, step, batch):
        X, Y = batch['X'].cuda(), batch['Y'].cuda()
        X, Y = Variable(X, requires_grad=False), Variable(Y, requires_grad=False)
        R = X - Y

        with torch.no_grad():
            X_Rs = self.net(X)
        loss_list = [self.crit(X_R, R) for X_R in X_Rs]
        ssim_list = [self.ssim(X - X_R, X - R) for X_R in X_Rs]
        psnr_list = [10*torch.log10(settings.pixel_MAX/loss) for loss in loss_list]        
        
        # pdb.set_trace()
        
        max_value = X[0].max().cpu().data.numpy()
        min_value = X[0].min().cpu().data.numpy()
        inp = X[0].cpu().data.numpy()
        for i in range(settings.stage_num):
            # inp = X[0].cpu().data.numpy()
            res =  X_Rs[i][0].cpu().data.numpy()
            pred =  inp - res
           
            gt = (X-R)[0].cpu().data.numpy()
            inp_toDraw = 255*(inp-min_value)/(max_value-min_value)
            res_toDraw = 255*(res-res.min())/(res.max()-res.min())
            pred_toDraw = 255*(pred-gt.min())/(gt.max()-gt.min())
            gt_toDraw = gt
            
            inp_toDraw = np.transpose(inp_toDraw, (1, 2, 0))
            res_toDraw = np.transpose(res_toDraw, (1, 2, 0))
            pred_toDraw = np.transpose(pred_toDraw, (1, 2, 0))
            gt_toDraw = np.transpose(gt_toDraw, (1, 2, 0))
#            pdb.set_trace()
            inp_file = os.path.join(self.log_dir, '%s_%d_%s_%d.jpg' % (name, step, "inp", i))
            cv2.imwrite(inp_file, inp_toDraw)
            res_file = os.path.join(self.log_dir, '%s_%d_%s_%d.jpg' % (name, step, "res", i))
            cv2.imwrite(res_file, res_toDraw)
            pred_file = os.path.join(self.log_dir, '%s_%d_%s_%d.jpg' % (name, step, "pred", i))
            cv2.imwrite(pred_file, pred_toDraw)
            gt_file = os.path.join(self.log_dir, '%s_%d_%s_%d.jpg' % (name, step, "gt", i))
            cv2.imwrite(gt_file, gt_toDraw) 

            inp = X[0].cpu().data.numpy()
        
#        for i in range(settings.stage_num-1):
#            res_diff = (X_Rs[i+1]-X_Rs[i])[0].cpu().data.numpy()
#            res_diff_toDraw = 255*(res_diff-res_diff.min())/(res_diff.max()-res_diff.min())
#            res_diff_toDraw = np.transpose(res_diff_toDraw, (1, 2, 0))
#            res_diff_file = os.path.join(self.log_dir, '%s_%d_%s_%d.jpg' % (name, step, "res_diff", i))
#            cv2.imwrite(res_diff_file, res_diff_toDraw)

        losses = {
            'loss%d' % i: loss.item()
            for i, loss in enumerate(loss_list)
        }
        ssimes = {
            'ssim%d' % i: ssim.item()
            for i, ssim in enumerate(ssim_list)
        }
        losses.update(ssimes)
        psnrs = {
            'psnr%d' % i: psnr.item()                                                                                                                  
            for i, psnr in enumerate(psnr_list)
        }
        losses.update(psnrs)

        return losses


def run_test(ckp_name):
    sess = Session()
    sess.net.eval()
    sess.load_checkpoints(ckp_name)
    dt = sess.get_dataloader('test')

    all_num = 0
    all_losses = {}
    for i, batch in enumerate(dt):
        losses = sess.inf_batch('test', i, batch)
        batch_size = batch['X'].size(0)
        all_num += batch_size
        for key, val in losses.items():
            if i == 0:
                all_losses[key] = 0.
            all_losses[key] += val * batch_size
            logger.info('batch %d mse %s: %f' % (i, key, val))

    for key, val in all_losses.items():
        logger.info('total mse %s: %f' % (key, val / all_num))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-m', '--model', default='latest')

    args = parser.parse_args(sys.argv[1:])
    run_test(args.model)

