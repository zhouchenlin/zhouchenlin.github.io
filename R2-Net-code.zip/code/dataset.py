import os
import cv2
import numpy as np
from scipy import io as scio
from numpy.random import RandomState
from torch.utils.data import Dataset

import settings 


class TrainValDataset(Dataset):
    def __init__(self, name='train'):
        super().__init__()
        self.rand_state = RandomState(66)

        self.root_dir = settings.data_dirs[name]
        self.x_dir = os.path.join(self.root_dir, '60')
        self.y_dir = os.path.join(self.root_dir, '720')

        self.patch_size = settings.patch_size
        self.x_names = sorted(os.listdir(self.x_dir))
        self.y_names = sorted(os.listdir(self.y_dir))
        self.file_num = len(self.x_names)

    def __len__(self):
        return self.file_num * 100

    def __getitem__(self, idx):
        x_name = self.x_names[idx % self.file_num]
        x_path = os.path.join(self.x_dir, x_name)
        X = ((np.load(x_path) - settings.pixel_25)/ (settings.pixel_75 - settings.pixel_25)).astype(np.float32)  # np.load(x_path) / settings.pixel_75
        
#         print(self.file_num, idx, len(self.y_names))
        y_name = self.y_names[idx % self.file_num]
        y_path = os.path.join(self.y_dir, y_name)
        Y = ((np.load(y_path) - settings.pixel_25)/ (settings.pixel_75 - settings.pixel_25)).astype(np.float32)

        if settings.aug_data:
            X, Y = self.crop(X, Y, aug=True)
            X, Y = self.flip(X, Y)
            X, Y = self.rotate(X, Y)
        else:
            X, Y = self.crop(X, Y, aug=False)

        X = X[np.newaxis, :]
        Y = Y[np.newaxis, :]
        sample = {'X': X, 'Y': Y}

        return sample

    def crop(self, X, Y, aug):
        patch_size = settings.patch_size
        if aug:
            mini = - 1 / 4 * self.patch_size
            maxi =   1 / 4 * self.patch_size + 1
            p_h = patch_size + self.rand_state.randint(mini, maxi)
            p_w = patch_size + self.rand_state.randint(mini, maxi)
        else:
            p_h, p_w = patch_size, patch_size

        # h, w = X.shape
        # r = self.rand_state.randint(0, h - p_h)
        # c = self.rand_state.randint(0, w - p_w)
        X = X[0: p_h, 0: p_w]
        Y = Y[0: p_h, 0: p_w]

        if aug:
            X = cv2.resize(X, (patch_size, patch_size))
            Y = cv2.resize(Y, (patch_size, patch_size))

        return X, Y

    def flip(self, X, Y):
        if self.rand_state.rand() > 0.5:
            X = np.flip(X, axis=1)
            Y = np.flip(Y, axis=1)
        return X, Y

    def rotate(self, X, Y):
        angle = self.rand_state.randint(-30, 30)
        patch_size = self.patch_size
        center = (int(patch_size / 2), int(patch_size / 2))
        M = cv2.getRotationMatrix2D(center, angle, 1)
        X = cv2.warpAffine(X, M, (patch_size, patch_size))
        Y = cv2.warpAffine(Y, M, (patch_size, patch_size))
        return X, Y


class TestDataset(Dataset):
    def __init__(self, name='valid'):
        super().__init__()
        self.rand_state = RandomState(66)

        self.root_dir = settings.data_dirs[name]
        self.x_dir = os.path.join(self.root_dir, '60')
        self.y_dir = os.path.join(self.root_dir, '720')

        self.patch_size = settings.patch_size
        self.x_names = sorted(os.listdir(self.x_dir))
        self.y_names = sorted(os.listdir(self.y_dir))
        self.file_num = len(self.x_names)

    def __len__(self):
        return self.file_num

    def __getitem__(self, idx):
        x_name = self.x_names[idx % self.file_num]
        x_path = os.path.join(self.x_dir, x_name)
        X = ((np.load(x_path) - settings.pixel_25)/ (settings.pixel_75 - settings.pixel_25)).astype(np.float32)  # np.load(x_path) / settings.pixel_75
        X = X[np.newaxis, :]

        y_name = self.y_names[idx % self.file_num]
        y_path = os.path.join(self.y_dir, y_name)
        Y = ((np.load(y_path) - settings.pixel_25)/ (settings.pixel_75 - settings.pixel_25)).astype(np.float32)
        Y = Y[np.newaxis, :]

        sample = {'X': X, 'Y': Y}
        return sample


class ShowDataset(Dataset):
    def __init__(self, name='val'):
        super().__init__()
        self.rand_state = RandomState(66)

        self.root_dir = settings.data_dirs[name]
        self.x_dir = os.path.join(self.root_dir, '60')

        self.patch_size = settings.patch_size
        self.x_names = sorted(os.listdir(self.x_dir))
        self.file_num = len(self.x_names)

    def __len__(self):
        return self.file_num

    def __getitem__(self, idx):
        x_name = self.x_names[idx % self.file_num]
        x_path = os.path.join(self.x_dir, x_name)
        X = ((np.load(x_path) - settings.pixel_25)/ (settings.pixel_75 - settings.pixel_25)).astype(np.float32)  # np.load(x_path) / settings.pixel_75
        X = X[np.newaxis, :]

        sample = {'X': X}
        return sample


if __name__ == '__main__':
    dt = TrainValDataset('train')
    print('TrainValDataset')
    for i in range(10):
        smp = dt[i]
        for k, v in smp.items():
            print(k, v.shape, v.dtype, v.mean(), v.max(), v.min())
        print()

    print()
    dt = TestDataset('valid')
    print('TestDataset')
    for i in range(10):
        smp = dt[i]
        for k, v in smp.items():
            print(k, v.shape, v.dtype, v.mean(), v.max(), v.min())
        print()

    print()
    print('ShowDataset')
    dt = ShowDataset('valid')
    for i in range(10):
        smp = dt[i]
        for k, v in smp.items():
            print(k, v.shape, v.dtype, v.mean(), v.max(), v.min())
        print()

