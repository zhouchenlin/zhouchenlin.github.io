%% constructed quad_x from quadratic monomials of all elements in xi. 
function [quad_x] = quad_vec(x)

n = length(x);
quad_x = zeros(1,n*(n+1)/2);
ind = 1;
for i = 1:n
    for j = 1:i
		if i == j
			quad_x(ind) = x(i)*x(j);
		else
			quad_x(ind) = sqrt(2)*x(i)*x(j);
		end
        ind = ind + 1;
    end
end

end

