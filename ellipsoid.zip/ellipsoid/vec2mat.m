%% convert the m*(m+1)/2 dimension vector a to m-by-m symmetry matrix A
%%   so that norm(a,2) = norm(A,'fro').

function [A] = vec2mat(a,p)

A = zeros(p,p);
ind = 1;

for i = 1:p
    for j = 1:i
        if i == j
            A(i,j) = a(ind);
        else
            A(i,j) = a(ind)/sqrt(2);
            A(j,i) = a(ind)/sqrt(2);
        end
        ind = ind + 1;
    end
end

end

