%% convert the symmetry matrix to vector.

function [a] = mat2vec(A)

n = length(A);
a = zeros(n*(n+1)/2,1);

ind = 1;
for i = 1:n
    for j = 1:i
        if i == j
            a(ind) = A(i,j);
        else
            a(ind) = A(i,j)*sqrt(2);
        end
        ind = ind + 1;
    end
end

end

