function [residual_L1, residual_L2, residual_Linf] = cal_error(X, Q)

n = size(X,1);
residual_L2 = 0;
residual_L1 = 0;
residual_Linf = 0;
for i = 1:n
    residual_L2 = residual_L2 + (X(i,:) * Q * X(i,:)')^2;
    residual_L1 = residual_L1 + abs(X(i,:) * Q * X(i,:)');
    residual_Linf = max(abs(X(i,:) * Q * X(i,:)'), residual_Linf);
end
residual_L2 = residual_L2 /n;
residual_L1 = residual_L1 /n;


end

