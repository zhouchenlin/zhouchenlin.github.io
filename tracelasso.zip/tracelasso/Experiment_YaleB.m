% Experiment_YaleB

clear ;
close all;
addpath( genpath(cd)) ;

%% Data YaleB
load YaleB  % YaleB dataset
nCluster = 5 ;          % number of subspace
num = nCluster * 64 ;   % number of data used for subspace segmentation
start = 0 ;
fea = fea(:,start+1:start+num) ;
gnd = gnd(:,start+1:start+num) ;

%% Projection
% PCA
[ eigvector , eigvalue ] = PCA( fea ) ;
maxDim = length(eigvalue)
fea = eigvector' * fea ;
% fea = [fea ; ones(1,size(fea,2)) ] ;
 for i = 1 : num
   fea(:,i) = fea(:,i) / norm(fea(:,i)) ; 
end
d = 30 ;
X = fea(1:d,:) ;
L = solve_tl( X ) ;

L = Selection( L , 5 ) ;


% Z = rpcapsd(L,-0.9);
% % refining Z
% [U,S,V] = svd(Z);
% S = diag(S);
% r = min(4*nCluster+1,sum(S>1e-3*S(1)));
% S = S(1:r);
% U = U(:,1:r)*diag(sqrt(S));
%     U = normr(U);
% for kk = 1 : size(U,1)
%     U(kk,:) = U(kk,:)/norm(U(kk,:)) ;
% end
% Z = U*U';Z=abs(Z);
% L = Z.^8;
% Z = L ;



Z = ( abs(L) + abs(L') ) / 2 ;

idx = clu_ncut(Z,nCluster) ;
acc = compacc(idx,gnd)


