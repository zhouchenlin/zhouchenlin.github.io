function [U,S,V,bnd,j] = lansvd(varargin)

%This code is an optimized version of Larsen's PROPACK, 
%by Zhouchen Lin and Guangluan Zhao. Its usage is identical 
%to that of PROPACK.
%
%Bug report: zclin2000@hotmail.com
%
%LANSVD  Compute a few singular values and singular vectors.
%   LANSVD computes singular triplets (u,v,sigma) such that
%   A*u = sigma*v and  A'*v = sigma*u. Only a few singular values
%   and singular vectors are computed  using the Lanczos
%   bidiagonalization algorithm with partial reorthogonalization (BPRO).
%
%   S = LANSVD(A)
%   S = LANSVD('Afun','Atransfun',M,N)
%
%   The first input argument is either a  matrix or a
%   string containing the name of an M-file which applies a linear
%   operator to the columns of a given matrix.  In the latter case,
%   the second input must be the name of an M-file which applies the
%   transpose of the same operator to the columns of a given matrix,
%   and the third and fourth arguments must be M and N, the dimensions
%   of the problem.
%
%   [U,S,V] = LANSVD(A,K,'L',...) computes the K largest singular values.
%
%   [U,S,V] = LANSVD(A,K,'S',...) computes the K smallest singular values.
%
%   The full calling sequence is
%
%   [U,S,V] = LANSVD(A,K,SIGMA,OPTIONS)
%   [U,S,V] = LANSVD('Afun','Atransfun',M,N,K,SIGMA,OPTIONS)
%
%   where K is the number of singular values desired and
%   SIGMA is 'L' or 'S'.
%
%   The OPTIONS structure specifies certain parameters in the algorithm.
%    Field name      Parameter                              Default
%
%    OPTIONS.tol     Convergence tolerance                  16*eps
%    OPTIONS.lanmax  Dimension of the Lanczos basis.
%    OPTIONS.p0      Starting vector for the Lanczos        rand(n,1)-0.5
%                    iteration.
%    OPTIONS.delta   Level of orthogonality among the       sqrt(eps/K)
%                    Lanczos vectors.
%    OPTIONS.eta     Level of orthogonality after           10*eps^(3/4)
%                    reorthogonalization.
%    OPTIONS.elr     If equal to 1 then extended local      1
%                    reorthogonalization is enforced.
%
%   See also LANBPRO, SVDS, SVD

% References:
% R.M. Larsen, Ph.D. Thesis, Aarhus University, 1998.
%
% B. N. Parlett, ``The Symmetric Eigenvalue Problem'',
% Prentice-Hall, Englewood Cliffs, NJ, 1980.
%
% H. D. Simon, ``The Lanczos algorithm with partial reorthogonalization'',
% Math. Comp. 42 (1984), no. 165, 115--142.
%
% Rasmus Munk Larsen, DAIMI, 1998


%%%%%%%%%%%%%%%%%%%%% Parse and check input arguments. %%%%%%%%%%%%%%%%%%%%%%

if nargin<2 || length(varargin)<2
    error('PROPACK:lansvd', 'Not enough input arguments.');
end

A = varargin{1};
if ~ischar(A)
    if ~isreal(A)
        error('PROPACK:lansvd', 'A must be real');
    end
    [m n] = size(A);
    k = varargin{2};
    if length(varargin)<3, sigma='L'; else sigma=varargin{3}; end
    if length(varargin)<4, options=struct(); else options=varargin{4}; end
else
    if length(varargin)<5
        error('PROPACK:lansvd', 'Not enough input arguments.');
    end
    Atrans = varargin{2};
    if ~ischar(Atrans)
        error('PROPACK:lansvd', 'Atransfunc must be the name of a function');
    end
    m = varargin{3};
    n = varargin{4};
    k = varargin{5};
    if length(varargin)<6, sigma='L'; else sigma=varargin{6}; end
    if length(varargin)<7, options=struct(); else options=varargin{7}; end
end

% Check sigma value
if ~ischar(sigma)
    error('PROPACK:lansvd', 'Sigma must be ''S'' or ''L''.');
end
if length(sigma) > 1
    error('PROPACK:lansvd', 'Sigma must be ''S'' or ''L''.');
end
if ~strcmp(sigma,'S') && ~strcmp(sigma,'L')
    error('PROPACK:lansvd', 'Sigma must be ''S'' or ''L''.');
end
sigmaS = strcmp(sigma,'S');

if ~isnumeric(n) || real(abs(fix(n)))~=n || ...
   ~isnumeric(m) || real(abs(fix(m)))~=m || ...
   ~isnumeric(k) || real(abs(fix(k)))~=k
    error('PROPACK:lansvd', 'M, N and K must be positive integers.');
end

if k > min(m,n)
    error('PROPACK:lansvd', 'K must satisfy K <= min(M,N).');
end

% Quick return for min(m,n) equal to 0 or 1 or for zero A.
if min(n,m)<1 || k<1
    if nargout<3
        U = zeros(k,1);
    else
        U = eye(m,k); S = zeros(k,k);  V = eye(n,k);  bnd = zeros(k,1);
    end
    return;
elseif min(n,m)==1 && k>0
    if ischar(A)
        % Extract the single column or row of A
        if n==1
            A = feval(A,1);
        else
            A = feval(Atrans,1)';
        end
    end
    if nargout==1
        U = norm(A);
    else
        [U,S,V] = svd(full(A));
        bnd = 0;
    end
    return;
end
% A is the matrix of all zeros (not detectable if A is defined by an m-file)
if isnumeric(A)
    if nnz(A) == 0
        if nargout<3
            U = zeros(k,1);
        else
            U = eye(m,k); S = zeros(k,k);  V = eye(n,k);  bnd = zeros(k,1);
        end
        return
    end
end

% Parse options struct
p = rand(m,1) - 0.5;
tol = 16*eps;
lanmax = min(m,n);
if isstruct(options)
    if isfield(options,'p0')
        p = options.p0;
    end
    if isfield(options,'tol')
        tol = options.tol;
    end
    if isfield(options,'lanmax')
        lanmax = options.lanmax;
    end
else
    warning('PROPACK:lansvd', 'options should be a struct.');
end
% Protect against absurd options.
p = p(:);
if ~isreal(p) || length(p)~=m
    warning('PROPACK:lansvd', 'p0 should be a vector of length m.');
    p = [];
end
if isempty(p)
    p = rand(m,1) - 0.5;
end
lanmax = min(min(m,n),ceil(lanmax));
if k > lanmax
  error('PROPACK:lansvd', 'K must satisfy  K <= LANMAX <= MIN(M,N).');
end
tol = max(tol,eps);

%%%%%%%%%%%%%%%%%%%%% Here begins the computation  %%%%%%%%%%%%%%%%%%%%%%

if sigmaS
    if ischar(A)
        error('PROPACK:lansvd', ['Shift-and-invert works only when the' ...
            ' matrix A is given explicitly.']);
    else
        As = A;
        A = struct();
        % Prepare for shift-and-invert Lanczos.
        if issparse(As)
            pmmd = colmmd(As);
            A.A = As(:,pmmd);
        else
            A.A = As;
        end
        if m>=n
            if issparse(A.A)
                A.R = qr(A.A,0);
                A.Rt = A.R';
                p = A.Rt\(A.A'*p); % project starting vector on span(Q1)
            else
                [A.Q,A.R] = qr(A.A,0);
                A.Rt = A.R';
                p = A.Q'*p; % project starting vector on span(Q1)
            end
        else
            error('PROPACK:lansvd', ['Sorry, shift-and-invert for' ...
                ' m<n not implemented yet!']);
        end
        condR = condest(A.R);
        if condR > 1/eps
            error('PROPACK:lansvd', ['A is rank deficient or too ' ...
                ' ill-conditioned to do shift-and-invert.']);
        end
    end
end

ksave = k;
neig = 0;
nrestart = -1;
j = min(k+max(8,k)+1, lanmax);
U = []; V = []; B = [];
anorm = [];
work = zeros(2,2);
options.At = A';

while neig < k
    %%%%%%%%%%%%%%%%%%%%% Compute Lanczos bidiagonalization %%%%%%%%%%%%%%%%%
    if ~ischar(A)
        [U B V p ierr w] = lanbpro(A,j,p,options,U,B,V,anorm);
    else
        [U B V p ierr w] = lanbpro(A,Atrans,m,n,j,p,options,U,B,V,anorm);
    end
    work= work + w;
    
    if ierr<0 % Invariant subspace of dimension -ierr found.
        j = -ierr;
    end
    
    %%%%%%%%%%%%%%%%%% Compute singular values and error bounds %%%%%%%%%%%%%%%%
    % Analyze B
    resnrm = norm(p);
    [P S Q] = bdsqr(B,resnrm);
    bot = P(end,1:j)';
    
    % Use Largest Ritz value to estimate ||||A||||_2. This might save some
    % reorth. in case of restart.
    anorm=S(1);
    
    % Set simple error bounds
    bnd = resnrm * abs(bot);
    
    % Examine gap structure and refine error bounds
    bnd = refinebounds(S.^2, bnd, n*eps*anorm);
    
    %%%%%%%%%%%%%%%%%%% Check convergence criterion %%%%%%%%%%%%%%%%%%%%
    i=1;
    neig = 0;
    while i<=min(j,k)
        if (bnd(i) <= tol*abs(S(i)))
            neig = neig + 1;
            i = i+1;
        else
            i = min(j,k)+1;
        end
    end
    
    %%%%%%%%%% Check whether to stop or to extend the Krylov basis? %%%%%%%%%%
    if ierr < 0
        % Invariant subspace found
        if j < k
            warning('PROPACK:lansvd', ['Invariant subspace of dimension ' ...
                num2str(j-1) ' found.']);
        end
        j = j-1;
        break;
    end
    if j>=lanmax % Maximal dimension of Krylov subspace reached. Bail out
        if j>=min(m,n)
            % neig = ksave;
            break;
        end
        if neig<ksave
            warning('PROPACK:lansvd', ['Maximum dimension of Krylov',...
                ' subspace exceeded prior to convergence.']);
        end
        break;
    end
    
    % Increase dimension of Krylov subspace
    if neig>0
        % increase j by approx. half the average number of steps pr. converged
        % singular value (j/neig) times the number of remaining ones (k-neig).
        j = j + min(100, max( 2, 0.5*(k-neig)*j/(neig+1) ));
    else
        % As long a very few singular values have converged, increase j rapidly.
        % j = j + ceil(min(100,max(8,2^nrestart*k)));
        j = max(1.5*j, j+10);
    end
    j = ceil( min(j+1,lanmax) );
    nrestart = nrestart + 1;
end

%%%%%%%%%%%%%%%% Lanczos converged (or failed). Prepare output %%%%%%%%%%%%%%%
k = min(ksave, j);
S = S(1:k);
bnd = bnd(1:k);

if nargout < 3
    % Only return singular values
    if sigmaS
        [S] = sort(-1./S);
        S = -S;
    end
    U = S;
else
    % Compute singular vectors
    j = size(B,2);
    Q = Q(:,1:k);
    V = V * Q;
    P = P(:,1:k);
    % Compute and normalize Ritz vectors (overwrites U and V to save memory).
    if resnrm ~= 0
        U = U*P(1:j,:) + (p/resnrm)*P(j+1,:);
    else
        U = U*P(1:j,:);
    end
    for i = 1:k
        nq = norm(V(:,i));
        if isfinite(nq) && nq~=0 && nq~=1
            V(:,i) = V(:,i) / nq;
        end
        nq = norm(U(:,i));
        if isfinite(nq) && nq~=0 && nq~=1
            U(:,i) = U(:,i) / nq;
        end
    end
    if sigmaS
        [S,p] = sort(-1./S);
        S = -S;
        if issparse(A.A)
            U = A.A*(A.R\U(:,p));
            V(pmmd,:) = V(:,p);
        else
            U = A.Q(:,1:min(m,n))*U(:,p);
            V = V(:,p);
        end
    end
    S = diag(S);
end
