function [U,B_k,V,p,ierr,work] = lanbpro(varargin)

%This code is an optimized version of Larsen's PROPACK, 
%by Zhouchen Lin and Guangluan Zhao. Its usage is identical 
%to that of PROPACK.
%
%Bug report: zclin2000@hotmail.com
%
%LANBPRO Lanczos bidiagonalization with partial reorthogonalization.
%   LANBPRO computes the Lanczos bidiagonalization of a real
%   matrix using the  with partial reorthogonalization.
%
%   [U_k,B_k,V_k,R,ierr,work] = LANBPRO(A,K,R0,OPTIONS,U_old,B_old,V_old)
%   [U_k,B_k,V_k,R,ierr,work] = LANBPRO('Afun','Atransfun',M,N,K,R0, ...
%                                       OPTIONS,U_old,B_old,V_old)
%
%  The OPTIONS structure is used to control the reorthogonalization:
%   OPTIONS.delta: Desired level of orthogonality
%           (default = sqrt(eps/K)).
%   OPTIONS.eta : Level of orthogonality after reorthogonalization
%           (default = eps^(3/4)/sqrt(K)).
%   OPTIONS.elr : If OPTIONS.elr = 1 (default) then extended local
%           reorthogonalization is enforced.
%   OPTIONS.onesided
%         : If OPTIONS.onesided = 0 (default) then both the left
%           (U) and right (V) Lanczos vectors are kept
%           semiorthogonal.
%           OPTIONS.onesided = 1 then only the columns of U are
%           are reorthogonalized.
%           OPTIONS.onesided = -1 then only the columns of V are
%           are reorthogonalized.
%

narg = length(varargin);
if nargin<1 || narg<2
    error('PROPACK:lanbpro', 'Not enough input arguments.');
end

A = varargin{1};
if ~ischar(A)
    if isnumeric(A)
        if ~isreal(A)
            error('PROPACK:lanbpro', 'A must be real.');
        end
        [m n] = size(A);
        Afunc = @(u) A*u;
    elseif isstruct(A)
        [m n] = size(A.R);
        Afunc = @(u) A.Rt\u;
        Atfunc = @(u) A.R\u;
    else
        error('PROPACK:lanbpro', 'A must be real or char.');
    end
    k = varargin{2};
    if narg >= 3 && ~isempty(varargin{3})
        p = varargin{3};
    else
        p = rand(m,1) - 0.5;
    end
    if narg < 4, options = struct(); else options = varargin{4}; end
    if narg > 4
        if narg < 7
            error('PROPACK:lanbpro', ['All or none of U_old, B_old' ...
                ' and V_old must be provided.']);
        else
            U = varargin{5};
            B_k = varargin{6};
            V = varargin{7};
        end
    else
        U = []; B_k = []; V = [];
    end
    if narg > 7, anorm = varargin{8}; else anorm = []; end
else
    if narg<5
        error('PROPACK:lanbpro', 'Not enough input arguments.');
    end
    Atrans = varargin{2};
    if ~ischar(Atrans)
        error('PROPACK:lanbpro', ['Afunc and Atransfunc must be' ...
            ' names of m-files.']);
    end
    Afunc = str2func(A);
    Atfunc = str2func(Atrans);
    m = varargin{3};
    n = varargin{4};
    k = varargin{5};
    if narg >= 6 && ~isempty(varargin{6})
        p = varargin{6};
    else
        p = rand(m,1) - 0.5;
    end
    if narg < 7, options = struct(); else options = varargin{7}; end
    if narg > 7
        if narg < 10
            error('PROPACK:lanbpro', ['All or none of U_old, B_old' ...
                ' and V_old must be provided.']);
        else
            U = varargin{8};
            B_k = varargin{9};
            V = varargin{10};
        end
    else
        U = []; B_k = []; V = [];
    end
    if narg > 10, anorm = varargin{11}; else anorm = []; end
end

if ~isnumeric(n) || length(n)~=1 || ...
        ~isnumeric(m) || length(m)~=1 || ...
        ~isnumeric(k) || length(k)~=1
    error('PROPACK:lanbpro', 'M, N and K must be positive integers.');
end
if real(abs(fix(n)))~=n || ...
        real(abs(fix(m)))~=m || ...
        real(abs(fix(k)))~=k
    error('PROPACK:lanbpro', 'M, N and K must be positive integers.');
end
if k > min(m,n)
    error('PROPACK:lanbpro', 'K must satisfy K <= min(M,N).');
end

% Quick return for min(m,n) equal to 0 or 1.
if min(m,n) == 0
    U = []; B_k = []; V = []; p = []; ierr = 0; work = zeros(2,2);
    return;
elseif min(m,n) == 1
    if isnumeric(A)
        U = 1; B_k = A; V = 1; p = 0; ierr = 0; work = zeros(2,2);
    else
        U = 1; B_k = feval(A,1); V = 1; p = 0; ierr = 0; work = zeros(2,2);
    end
    if nargout < 3
        U = B_k;
    end
    return;
end

% Set options.
m2eps = 3/2*eps;
n2eps = 3/2*eps;

% Parse options struct
delta = sqrt(eps/k);     % Desired level of orthogonality.
eta = eps^(3/4)/sqrt(k); % Level of orth. after reorthogonalization.
elr = true;              % Flag for switching extended local reorthogonalization on and off.
gamma = 1/sqrt(2);       % Tolerance for iterated Gram-Schmidt.
onesided = 0;
At = [];
if isstruct(options)
    if isfield(options,'delta'), delta = options.delta; end
    if isfield(options,'eta'), eta = options.eta; end
    if isfield(options,'elr'), elr = options.elr; end
    if isfield(options,'gamma'), gamma = options.gamma; end
    if isfield(options,'onesided'), onesided = options.onesided; end
    if isfield(options,'At'), At = options.At; end
else
    warning('PROPACK:lanbpro', 'Options should be a struct.');
end

if isnumeric(A)
    if ~isnumeric(At)
        At = [];
    end
    if size(At,1)~=n || size(At,2)~=m
        At = [];
    end
    if isempty(At)
        At = A';
    end
    Atfunc = @(u) At*u;
end

if isempty(anorm)
    anorm = [];
    est_anorm=1;
else
    est_anorm=0;
end

% Conservative statistical estimate on the size of round-off terms.
% Notice that {\bf u} == eps/2.
FUDGE = 1.01; % Fudge factor for ||||A||||_2 estimate.

npu = 0; npv = 0; ierr = 0;
p = p(:);

if delta==0
    fro = 1; % The user has requested full reorthogonalization.
else
    fro = 0;
end

funcStop = false;

% Prepare for Lanczos iteration.
if isempty(U)
    V = zeros(n,k);
    U = zeros(m,k);
    beta = zeros(k+1,1);
    alpha = zeros(k,1);
    beta(1) = norm(p,2);
    % Initialize MU/NU-recurrences for monitoring loss of orthogonality.
    nu = zeros(k,1);
    mu = zeros(k+1,1);
    mu(1) = 1;
    nu(1) = 1;
    numax = zeros(k,1);
    mumax = zeros(k,1);
    force_reorth = false;
    nreorthu = 0;
    nreorthv = 0;
    
    if beta(1) ~= 0
        U(:,1) = p(:,1) / beta(1);
    else
        U(:,1) = p(:,1);
    end
    r(:,1) = Atfunc(U(:,1));
    alpha(1) = norm(r(:,1),2);
    if est_anorm
        anorm = FUDGE * alpha(1);
    end
    
    % Check for convergence or failure to maintain semiorthogonality
    if alpha(1) < max(n,m)*anorm*eps
        alpha(1) = 0;
        bailout = true;
        for attempt = 1:3
            r(:,1) = rand(m,1) - 0.5;
            r(:,1) = Atfunc(r(:,1));
            nrmnew = norm(r(:,1));
            if nrmnew > 0
                bailout = false;
                break;
            end
        end
        if bailout
            ierr = -1;
            funcStop = true;
        else
            r(:,1) = r(:,1) / nrmnew;
            force_reorth = true;
        end
    elseif 1<k && ~fro && anorm*eps > delta*alpha(1)
        ierr = 1;
    end
    
    if alpha(1) ~= 0
        V(:,1) = r(:,1) / alpha(1);
    else
        V(:,1) = r(:,1);
    end
    
    %%%%%%%%%% Lanczos step to generate u_{j+1}. %%%%%%%%%%%%%
    p(:,1) = Afunc(V(:,1)) - alpha(1)*U(:,1);
    beta(1+1) = norm(p(:,1),2);
    
    % Extended local reorthogonalization
    if beta(2)<gamma*alpha(1) && elr && ~fro
        normold = beta(2);
        stop = 0;
        while ~stop
            t = U(:,1)' * p(:,1);
            p(:,1) = p(:,1) - U(:,1)*t;
            beta(2) = norm(p(:,1),2);
            if alpha(1) ~= 0
                alpha(1) = alpha(1) + t;
            end
            if beta(2) >= gamma*normold
                stop = 1;
            else
                normold = beta(2);
            end
        end
    end
    
    if est_anorm
        % We should update estimate of ||||A||||  before updating mu - especially
        % important in the first step for problems with large norm since alpha(1)
        % may be a severe underestimate!
        anorm = max(anorm,FUDGE*pythag(alpha(1),beta(2)));
    end
    
    if ~fro && beta(2) ~= 0
        % Update estimates of the level of orthogonality for the columns of V.
        T = 100*eps/2*(pythag(alpha(1),beta(2)) + pythag(alpha(1),beta(1)));
        mu(1) = (T + 100*eps/2*anorm) / beta(2);
        mu(2) = 1;
        mumax(1) = max( abs(mu(1)) );
        clear T;
    end
    
    if elr
        mu(1) = m2eps;
    end
    
    % IF level of orthogonality is worse than delta THEN
    %    Reorthogonalize u_{j+1} against some previous  u_i's, 0<=i<=j.
    if onesided~=1 && (fro || mumax(1)>delta || force_reorth) && beta(2)~=0
        int = 1;
        simple = true;
        % Reorthogonalize u_{j+1}
        [p(:,1),beta(1+1),rr] = reorth(U, p, int, gamma, simple);
        npu = npu + rr * int;
        nreorthu = nreorthu + 1;
        % Reset mu to epsilon.
        mu(1) = m2eps;
        force_reorth = ~force_reorth;
    end
    
    % Check for convergence or failure to maintain semiorthogonality
    if beta(2) < max(m,n)*anorm*eps
        beta(2) = 0;
        bailout = true;
        for attempt = 1:3
            p(:,1) = rand(n,1) - 0.5;
            p(:,1) = Afunc(p(:,1));
            int = 1;
            simple = true;
            [p(:,1),nrmnew,rr] = reorth(U, p, int, gamma, simple);
            npu = npu + rr;
            nreorthu = nreorthu + 1;
            mu(1) = m2eps;
            if nrmnew > 0
                bailout = false;
                break;
            end
        end
        if bailout
            ierr = -1;
            funcStop = true;
        else
            p(:,1) = p(:,1) / nrmnew; % Continue with new normalized p as starting vector.
            force_reorth = true;
        end
    elseif  ~fro && anorm*eps > delta*beta(1+1)
        ierr = 1;
    end
    
    j0 = 2;
else
    j = size(U,2); % Size of existing factorization
    % Allocate space for Lanczos vectors
    U = [U, zeros(m,k-j)];
    V = [V, zeros(n,k-j)];
    alpha = zeros(k+1,1);
    beta = zeros(k+1,1);
    alpha(1:j) = diag(B_k);
    if j > 1
        beta(2:j) = diag(B_k,-1);
    end
    beta(j+1) = norm(p,2);
    % Reorthogonalize p.
    if j<k && beta(j+1)*delta < anorm*eps
        % fro = 1;
        ierr = j;
    end
    int = j;
    simple = true;
    [p,beta(j+1),rr] = reorth(U, p, int, gamma, simple);
    npu = rr * j;
    
    % Compute Gerscgorin bound on ||||B_k||||_2
    if est_anorm
        anorm = FUDGE * sqrt(norm(B_k'*B_k,1));
    end
    mu = m2eps*ones(k+1,1); nu = zeros(k,1);
    numax = zeros(k,1); mumax = zeros(k,1);
    force_reorth = true;  nreorthu = 0; nreorthv = 0;
    j0 = j+1;
end

if funcStop
    if j0 < k
        k = j0;
    end
    
    B_k = spdiags([alpha(1:k) [beta(2:k);0]],[0 -1],k,k);
    if nargout == 1
        U = B_k;
    elseif k~=size(U,2) || k~=size(V,2)
        U = U(:,1:k);
        V = V(:,1:k);
    end
    if nargout > 5
        work = [[nreorthu,npu];[nreorthv,npv]];
    end
    return;
end

% Perform Lanczos bidiagonalization with partial reorthogonalization.
for j = j0:k
    
    if beta(j) ~= 0
        U(:,j) = p(:,1) / beta(j);
    else
        U(:,j) = p(:,1);
    end
    
    % Replace norm estimate with largest Ritz value.
    if j == 6
        B = [ diag(alpha(1:j-1))+diag(beta(2:j-1),-1); ...
            [zeros(1,j-2),beta(j)] ];
        anorm = FUDGE * norm(B,2);
        est_anorm = 0;
    end
    
    %%%%%%%%%% Lanczos step to generate v_j. %%%%%%%%%%%%%
    r(:,1) = Atfunc(U(:,j)) - beta(j)*V(:,j-1);
    alpha(j) = norm(r(:,1),2);
    % Extended local reorthogonalization
    if alpha(j)<gamma*beta(j) && elr && ~fro
        normold = alpha(j);
        stop = false;
        while ~stop
            t = V(:,j-1)'*r(:,1);
            r(:,1) = r(:,1) - V(:,j-1)*t;
            alpha(j) = norm(r(:,1),2);
            if beta(j) ~= 0
                beta(j) = beta(j) + t;
            end
            if alpha(j) >= gamma*normold
                stop = true;
            else
                normold = alpha(j);
            end
        end
    end
    
    if est_anorm
        if j==2
            anorm = max(anorm,FUDGE*sqrt(alpha(1)^2+beta(2)^2+alpha(2)*beta(2)));
        else
            anorm = max(anorm,FUDGE*sqrt(alpha(j-1)^2+beta(j)^2+alpha(j-1)* ...
                beta(j-1) + alpha(j)*beta(j)));
        end
    end
    
    if ~fro && alpha(j) ~= 0
        % Update estimates of the level of orthogonality for the
        %  columns 1 through j-1 in V.
        nu(:,1) = update_nu(nu(:,1), mu(:,1), j, alpha, beta, anorm);
        numax(j) = max( abs(nu(1:j-1)) );
    end
    
    if elr
        nu(j-1) = n2eps;
    end
    
    % IF level of orthogonality is worse than delta THEN
    %    Reorthogonalize v_j against some previous  v_i's, 0<=i<j.
    if onesided~=-1 && ( fro || numax(j) > delta || force_reorth ) && alpha(j)~=0
        % Decide which vectors to orthogonalize against:
        if fro || eta==0
            int = j-1;
            simple = true;
        elseif ~force_reorth
            [int simple] = compute_int(nu, j-1, delta, eta);
        end
        % Else use int from last reorth. to avoid spillover from mu_{j-1}
        % to nu_j.
        
        % Reorthogonalize v_j
        [r(:,1),alpha(j),rr] = reorth(V, r, int, gamma, simple);
        if simple
            npv = npv + rr * int; % number of inner products.
            nu(1:int) = n2eps;  % Reset nu for orthogonalized vectors.
        else
            npv = npv + rr * length(int); % number of inner products.
            nu(int) = n2eps;  % Reset nu for orthogonalized vectors.
        end
        
        % If necessary force reorthogonalization of u_{j+1}
        % to avoid spillover
        force_reorth = ~force_reorth;
        nreorthv = nreorthv + 1;
    end
    
    % Check for convergence or failure to maintain semiorthogonality
    if alpha(j) < max(n,m)*anorm*eps && j<k
        % If alpha is "small" we deflate by setting it
        % to 0 and attempt to restart with a basis for a new
        % invariant subspace by replacing r with a random starting vector:
        %j
        %disp('restarting, alpha = 0')
        alpha(j) = 0;
        bailout = true;
        for attempt = 1:3
            r(:,1) = rand(m,1) - 0.5;
            r(:,1) = Atfunc(r(:,1));
            int = j-1;
            simple = true;
            [r(:,1),nrmnew,rr] = reorth(V, r, int, gamma, simple);
            npv = npv + rr * int;
            nreorthv = nreorthv + 1;
            nu(1:int) = n2eps;
            if nrmnew > 0
                % A vector numerically orthogonal to span(Q_k(:,1:j)) was found.
                % Continue iteration.
                bailout = false;
                break;
            end
        end
        if bailout
            j = j-1;
            ierr = -j;
            break;
        else
            r(:,1) = r(:,1) / nrmnew; % Continue with new normalized r as starting vector.
            force_reorth = true;
            if delta > 0
                fro = 0;    % Turn off full reorthogonalization.
            end
        end
    elseif j<k && ~fro && anorm*eps > delta*alpha(j)
        % fro = 1;
        ierr = j;
    end
    
    if alpha(j) ~= 0
        V(:,j) = r(:,1) / alpha(j);
    else
        V(:,j) = r(:,1);
    end
    
    %%%%%%%%%% Lanczos step to generate u_{j+1}. %%%%%%%%%%%%%
    p(:,1) = Afunc(V(:,j)) - alpha(j)*U(:,j);
    beta(j+1) = norm(p(:,1),2);
    
    % Extended local reorthogonalization
    if beta(j+1)<gamma*alpha(j) && elr && ~fro
        normold = beta(j+1);
        stop = false;
        while ~stop
            t = U(:,j)'*p(:,1);
            p(:,1) = p(:,1) - U(:,j)*t;
            beta(j+1) = norm(p(:,1),2);
            if alpha(j) ~= 0
                alpha(j) = alpha(j) + t;
            end
            if beta(j+1) >= gamma*normold
                stop = true;
            else
                normold = beta(j+1);
            end
        end
    end
    
    if est_anorm
        % We should update estimate of ||||A||||  before updating mu - especially
        % important in the first step for problems with large norm since alpha(1)
        % may be a severe underestimate!
        if j==1
            anorm = max(anorm,FUDGE*pythag(alpha(1),beta(2)));
        else
            anorm = max(anorm,FUDGE*sqrt(alpha(j)^2+beta(j+1)^2 + alpha(j)*beta(j)));
        end
    end
    
    if ~fro && beta(j+1) ~= 0
        % Update estimates of the level of orthogonality for the columns of V.
        mu(:,1) = update_mu(mu(:,1), nu(:,1), j, alpha, beta, anorm);
        mumax(j) = max( abs(mu(1:j)) );
    end
    
    if elr
        mu(j) = m2eps;
    end
    
    % IF level of orthogonality is worse than delta THEN
    %    Reorthogonalize u_{j+1} against some previous  u_i's, 0<=i<=j.
    if onesided~=1 && (fro || mumax(j)>delta || force_reorth) && beta(j+1)~=0
        % Decide which vectors to orthogonalize against.
        if fro || eta==0
            int = j;
            simple = true;
        elseif ~force_reorth
            [int simple] = compute_int(mu,j,delta,eta);
        else
            if simple
                int = int + 1;
            else
                int = [int max(int)+1];
            end
        end
        % Else use int from last reorth. to avoid spillover from nu to mu.
        
        % Reorthogonalize u_{j+1}
        [p(:,1),beta(j+1),rr] = reorth(U, p, int, gamma, simple);
        if simple
            npu = npu + rr * int;
            nreorthu = nreorthu + 1;
            % Reset mu to epsilon.
            mu(1:int) = m2eps;
        else
            npu = npu + rr * length(int);
            nreorthu = nreorthu + 1;
            % Reset mu to epsilon.
            mu(int) = m2eps;
        end
        
        force_reorth = ~force_reorth;
    end
    
    % Check for convergence or failure to maintain semiorthogonality
    if beta(j+1) < max(m,n)*anorm*eps && j<k
        % If beta is "small" we deflate by setting it
        % to 0 and attempt to restart with a basis for a new
        % invariant subspace by replacing p with a random starting vector:
        %j
        %disp('restarting, beta = 0')
        beta(j+1) = 0;
        bailout = true;
        for attempt = 1:3
            p(:,1) = rand(n,1) - 0.5;
            p(:,1) = Afunc(p(:,1));
            int = j;
            simple = true;
            [p(:,1),nrmnew,rr] = reorth(U, p, int, gamma, simple);
            npu = npu + rr * int;
            nreorthu = nreorthu + 1;
            mu(1:int) = m2eps;
            if nrmnew > 0
                % A vector numerically orthogonal to span(Q_k(:,1:j)) was found.
                % Continue iteration.
                bailout = false;
                break;
            end
        end
        if bailout
            ierr = -j;
            break;
        else
            p(:,1) = p(:,1) / nrmnew; % Continue with new normalized p as starting vector.
            force_reorth = true;
            if delta > 0
                fro = 0;    % Turn off full reorthogonalization.
            end
        end
    elseif  j<k && ~fro && anorm*eps > delta*beta(j+1)
        % fro = 1;
        ierr = j;
    end
    
end

if j < k
    k = j;
end

B_k = spdiags([alpha(1:k) [beta(2:k);0]],[0 -1],k,k);
if nargout == 1
    U = B_k;
elseif k~=size(U,2) || k~=size(V,2)
    U = U(:,1:k);
    V = V(:,1:k);
end
if nargout > 5
    work = [[nreorthu,npu];[nreorthv,npv]];
end

end

function mu = update_mu(mu,nu,j,alpha,beta,anorm)

% UPDATE_MU:  Update the mu-recurrence for the u-vectors.
%
%   mu_new = update_mu(mu,nu,j,alpha,beta,anorm)

%  Rasmus Munk Larsen, DAIMI, 1998.

% mu(:) = muold;
eps1 = 100*eps/2;
mu(1) = alpha(1)*nu(1) - alpha(j)*mu(1);
T = eps1*(sqrt(alpha(j).^2+beta(j+1).^2) + sqrt(alpha(1).^2+beta(1).^2));
T = T + eps1*anorm;
mu(1) = (mu(1) + sign(mu(1))*T) / beta(j+1);
% Vectorized version of loop:
if j>2
    k = 2:(j-1);
    mu(k) = alpha(k).*nu(k) + beta(k).*nu(k-1) - alpha(j)*mu(k);
    T = eps1*(sqrt(alpha(j).^2+beta(j+1).^2) + sqrt(alpha(k).^2+beta(k).^2));
    T = T + eps1*anorm;
    mu(k) = (1/beta(j+1))*(mu(k) + sign(mu(k)).*T);
end
T = eps1*(sqrt(alpha(j).^2+beta(j+1).^2) + sqrt(alpha(j).^2+beta(j).^2));
T = T + eps1*anorm;
mu(j) = beta(j)*nu(j-1);
mu(j) = (mu(j) + sign(mu(j))*T) / beta(j+1);
mu(j+1) = 1;

end

function nu = update_nu(nu,mu,j,alpha,beta,anorm)

% UPDATE_MU:  Update the nu-recurrence for the v-vectors.
%  nu_new = update_nu(nu,mu,j,alpha,beta,anorm)

%  Rasmus Munk Larsen, DAIMI, 1998.

% nu = nuold;
eps1 = 100*eps/2;
k = 1:(j-1);
% T = eps1*(pythag(alpha(k),beta(k+1)) + pythag(alpha(j),beta(j)));
T = eps1*(sqrt(alpha(k).^2+beta(k+1).^2) + sqrt(alpha(j).^2+beta(j).^2));
T = T + eps1*anorm;
nu(k) = beta(k+1).*mu(k+1) + alpha(k).*mu(k) - beta(j)*nu(k);
nu(k) = (1/alpha(j)) * (nu(k) + sign(nu(k)).*T);
nu(j) = 1;

end

function x = pythag(y,z)
%PYTHAG Computes sqrt( y^2 + z^2 ).

rmax = max(abs([y;z]));
if rmax == 0
    x = 0;
else
    x = rmax.*sqrt((y./rmax).^2 + (z./rmax).^2);
end

end