% clear all;
% m = 1000;
% A = rand(m) - 0.5;
% p0 = rand(1,m) - 0.5;
% S0 = svd(A);

% tic;
% [U S V bnd j] = lansvd(A, m*0.1);
% toc;

% B = U'*A*V - S;
% disp(['Maxium error of Ut*A*V: ' num2str( max(max(abs(B))) )]);
% B = S0(1:length(S)) - diag(S);
% disp(['Maxium error of singular values S: ' num2str(max(abs(B))) ]);
% B = U'*U - eye(size(U,2));
% disp(['Maxium error of singular vector U: ' num2str( max( max(abs(B))) )]);
% B = V'*V - eye(size(V,2));
% disp(['Maxium error of singular vector V: ' num2str( max( max(abs(B))) )]);

% global time;
% time = 0;
%
% time = 0;
% for i = 1:5
%     tic;
%     [U,S,V,pM,ierrM,workM] = lanbpro(A, 800, p0);
%     ti = toc;
%     time = time + ti;
% end
% time = time / i;
%
% B = U'*U - eye(size(U,2));
% disp(['Maxium error of singular vector U: ' num2str( max( max(abs(B))) )]);
% B = V'*V - eye(size(V,2));
% disp(['Maxium error of singular vector V: ' num2str( max( max(abs(B))) )]);
% B = U'*A*V;

% time;

% options = struct();
% options.cgs = 1;
% options.p0 = p0;
% options.lanmax = 500;
% options.tol = 32*eps;
% tic;[U S V bnd j] = lansvd(A, 100, 'S');toc;

% clear all;
% clear global;
% global A Sparse_Z;
% 
% m = 200;
% n = 150;
% p0 = rand(1,m);
% Sparse_Z = sparse(randi([1,m],[1,n]),1:n,rand(1,n),m,n);
% A = struct();
% A.U = rand(m, 1);
% A.V = rand(n, 1);

% tic;
% [U S V] = lanbpro('Axz', 'Atxz', m, n, 150, p0);
% toc;
% B = U'*U - eye(size(U,2));
% disp(['Maxium error of singular vector U: ' num2str( max( max(abs(B))) )]);
% B = V'*V - eye(size(V,2));
% disp(['Maxium error of singular vector V: ' num2str( max( max(abs(B))) )]);
% B = U'*(A.U*A.V'+Sparse_Z)*V;
% B(abs(B)<10e-13) = 0;
% nnz(B) - size(B,2)*2

% clear all
% clear global
% 
% global stat cur;
% stat = zeros(100,10);
% cur = 0;
% 
% radio = [0.01 0.02 0.05 0.08 0.1 0.15 0.2 0.25];
% 
% testLansvd(100, radio);
% testLansvd(200, radio);
% testLansvd(500, radio);
% testLansvd(800, radio);
% testLansvd(1000, radio);
% testLansvd(1500, radio);
% testLansvd(2000, radio);
% testLansvd(2500, radio);
% testLansvd(3000, radio);
% dlmwrite('D:\\test.txt', stat,'newline','pc','precision','%e');







