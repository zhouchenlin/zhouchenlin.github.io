function [U Sigma V] = bdsqr(R,res)

B = full([R;[zeros(1,size(R,2)-1),res]]);
[U S V] = svd(B, 0);
Sigma = diag(S);

end

